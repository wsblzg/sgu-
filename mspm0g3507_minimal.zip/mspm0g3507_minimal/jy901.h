#ifndef JY901_H_
#define JY901_H_

#include "app_types.h"

typedef struct {
    uint8_t bytes[11];
    uint8_t index;
} jy901_parser_t;

void jy901_parser_init(jy901_parser_t *parser);
void jy901_parser_feed(jy901_parser_t *parser, uint8_t byte, imu_state_t *imu_state);

#endif /* JY901_H_ */
