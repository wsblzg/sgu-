#ifndef GIMBAL_SERVO_H_
#define GIMBAL_SERVO_H_

#include "app_types.h"

void gimbal_servo_init(void);
void gimbal_servo_set_enabled(bool enabled);
void gimbal_servo_center(void);
void gimbal_servo_set_target(int32_t pan_us, int32_t tilt_us);
void gimbal_servo_sync_position(int32_t pan_us, int32_t tilt_us);
void gimbal_servo_set_angle(int32_t pan_deg, int32_t tilt_deg);
void gimbal_servo_sync_angle(int32_t pan_deg, int32_t tilt_deg);
void gimbal_servo_offset(int16_t pan_delta_us, int16_t tilt_delta_us);
void gimbal_servo_service_200hz(void);
void gimbal_servo_get_state(gimbal_state_t *state);

#endif /* GIMBAL_SERVO_H_ */
