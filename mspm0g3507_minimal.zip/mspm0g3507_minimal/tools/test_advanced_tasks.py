from pathlib import Path
import importlib.util


ROOT = Path(__file__).resolve().parents[1]
CAR_APP = ROOT / "car_app.c"
BOARD = ROOT / "board.c"
BOARD_H = ROOT / "board.h"
BOARD_CONFIG = ROOT / "board_config.h"
OLED_C = ROOT / "oled.c"
OLED_H = ROOT / "oled.h"
PIN_DOC = ROOT / "引脚分配表.md"
K230_MAIN = Path(r"C:\Users\DAS\AppData\Local\Temp\k230_mtp_work\main.py")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load_k230_main():
    spec = importlib.util.spec_from_file_location("k230_main_under_test", K230_MAIN)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_advanced_mode_entries_exist():
    text = read(CAR_APP)
    assert "CAR,MODE,4" in text
    assert "CONTEST_TASK_ADV_ECG" in text
    assert "CONTEST_TASK_ADV_ROUTE2_AIM" in text
    assert "CONTEST_TASK_ADV_ROUTE3_AIM" in text
    assert "value == 4" in text
    assert "value == 5" in text
    assert "value == 6" in text
    assert "BUTTON_LONG_PRESS_TICKS" in text
    assert "car_app_handle_mode_button_holds" in text


def test_physical_mode_buttons_1_and_2_are_swapped():
    app = read(CAR_APP)

    selection_body = app.split("static void car_app_handle_selection_buttons", 1)[1].split("static void car_app_handle_mode_button_holds", 1)[0]
    button1_body = selection_body.split("if ((pressed_mask & BUTTON_MODE_1) != 0U)", 1)[1].split("if ((pressed_mask & BUTTON_MODE_2) != 0U)", 1)[0]
    button2_body = selection_body.split("if ((pressed_mask & BUTTON_MODE_2) != 0U)", 1)[1].split("if ((pressed_mask & BUTTON_MODE_3) != 0U)", 1)[0]
    assert "car_app_select_task(app, CONTEST_TASK_BASIC_2);" in button1_body
    assert "car_app_select_task(app, CONTEST_TASK_BASIC_1);" in button2_body

    hold_body = app.split("static void car_app_handle_mode_button_holds", 1)[1].split("static void car_app_print_button_event", 1)[0]
    assert "static const uint32_t masks[3] = { BUTTON_MODE_1, BUTTON_MODE_2, BUTTON_MODE_3 };" in hold_body
    assert "CONTEST_TASK_ADV_ROUTE2_AIM,\n        CONTEST_TASK_ADV_ECG,\n        CONTEST_TASK_ADV_ROUTE3_AIM" in hold_body


def test_k230_and_laser_are_linked_to_advanced_tasks():
    text = read(CAR_APP)
    assert "#define SERIAL_K230_MODE_OUTPUT_ENABLED 1U" in text
    assert "board_set_laser_power(app->laser_power_on);" in text
    assert "car_app_task_uses_laser" in text
    assert "gimbal_servo_set_enabled(car_app_task_uses_laser(app));" in text
    assert "K230_MODE_ECG" in text
    assert "K230_MODE_AIM" in text


def test_ecg_state_machine_is_nonblocking():
    text = read(CAR_APP)
    assert "#define ECG_CYCLE_COUNT 3U" in text
    assert "#define ECG_TOTAL_TIME_MS 15000U" in text
    assert "#define ECG_UPDATE_TICKS" in text
    assert "#define ECG_LEFT_PAN_US 1540U" in text
    assert "#define ECG_RIGHT_PAN_US 1460U" in text
    assert "#define ECG_SMALL_TILT_US 1520U" in text
    assert "#define ECG_BIG_TILT_US 1565U" in text
    assert "#define ECG_VALLEY_TILT_US 1460U" in text
    assert "static void car_app_update_ecg_task" in text
    assert "gimbal_servo_set_target(pan_target_us, tilt_target_us);" in text
    ecg_body = text.split("static void car_app_update_ecg_task", 1)[1].split("static void", 1)[0]
    assert "board_delay" not in ecg_body


def test_ecg_uses_k230_frame_center_as_draw_origin():
    app = read(CAR_APP)
    types = read(ROOT / "app_types.h")
    protocol = read(ROOT / "k230_protocol.c")
    assert "#define ECG_START_LEFT_OFFSET_PX" in app
    assert "ECG_LOCATE_TIMEOUT_MS" not in app
    assert "#define ECG_LOCATE_MAX_STEP_US 10" in app
    assert "#define ECG_LOCATE_PAN_REVERSE 0U" in app
    assert "#define ECG_LOCATE_CONFIRM_UPDATES" in app
    assert "ECG_STAGE_LOCATE" in app
    assert "ECG_STAGE_DRAW" in app
    assert "ecg_origin_pan_us" in app
    assert "ecg_origin_tilt_us" in app
    assert "car_app_update_ecg_locate" in app
    ecg_body = app.split("static void car_app_update_ecg_task", 1)[1].split("static void", 1)[0]
    first_start = ecg_body.split("if (!app->ecg_active)", 1)[1].split("return;", 1)[0]
    assert "#define ECG_MOUNT_PAN_US" in app
    assert "#define ECG_MOUNT_TILT_US" in app
    assert "gimbal_servo_sync_position(ECG_MOUNT_PAN_US, ECG_MOUNT_TILT_US);" in first_start
    assert "app->ecg_stage = ECG_STAGE_LOCATE;" in first_start
    assert "app->ecg_stage = ECG_STAGE_DRAW;" not in first_start
    locate_stage = ecg_body.split("if (app->ecg_stage == ECG_STAGE_LOCATE)", 1)[1].split("if (app->ecg_elapsed_ticks < settle_ticks)", 1)[0]
    assert "return;" in locate_stage
    assert "ECG_LOCATE_TIMEOUT_MS" not in locate_stage
    assert "app->ecg_stage = ECG_STAGE_DRAW;" not in locate_stage
    assert "desired_x = app->vision_state.frame_center_x - ECG_START_LEFT_OFFSET_PX;" in app
    assert '"ECGLOC,fx=%d,fy=%d,lx=%d,ly=%d,dx=%d,dy=%d,ex=%d,ey=%d,pan=%d,tilt=%d\\r\\n"' in app
    assert "if (ECG_LOCATE_PAN_REVERSE != 0U)" in app
    assert "pan_target_us = app->ecg_origin_pan_us + ecg_pan_delta_at_x(total_x);" in app
    assert "tilt_target_us = app->ecg_origin_tilt_us + ecg_tilt_delta_at_cycle_x(cycle_x);" in app
    assert "frame_center_x" in types
    assert "laser_center_x" in types
    assert "target_update_count" in types
    assert '"VDIAG,"' in protocol
    assert '"TCENTER,"' in protocol


def test_advanced_tasks_sync_gimbal_to_ecg_mount_on_every_start():
    app = read(CAR_APP)

    assert "#define ECG_MOUNT_TILT_US 1550U" in app
    start_body = app.rsplit("static void car_app_start", 1)[1].split("static void car_app_stop", 1)[0]
    assert "gimbal_servo_set_enabled(car_app_task_uses_laser(app));" in start_body
    assert "if (car_app_task_uses_laser(app))" in start_body
    assert "gimbal_servo_sync_position(ECG_MOUNT_PAN_US, ECG_MOUNT_TILT_US);" in start_body
    assert start_body.find("gimbal_servo_set_enabled(car_app_task_uses_laser(app));") < \
        start_body.find("gimbal_servo_sync_position(ECG_MOUNT_PAN_US, ECG_MOUNT_TILT_US);")

    reset_body = app.split("static void car_app_reset_gimbal_aim_pid", 1)[1].split("static void car_app_reset_angle_pids", 1)[0]
    assert "app->aim_last_seen_valid = false;" in reset_body


def test_advanced_route2_and_route3_have_slower_chassis_speeds():
    app = read(CAR_APP)

    assert "#define ADV_ROUTE2_BASE_SPEED_PPS 950" in app
    assert "#define ADV_ROUTE3_BASE_SPEED_PPS 850" in app
    reset_logic = app.split("static void car_app_reset_runtime_tuning", 1)[1]
    reset_logic = reset_logic.split("static void car_app_queue_beep", 1)[0]

    mode2_branch = reset_logic.split("if ((app->contest_task == CONTEST_TASK_BASIC_1) ||", 1)[1]
    mode2_branch = mode2_branch.split("if ((app->contest_task == CONTEST_TASK_BASIC_3) ||", 1)[0]
    assert "if (app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM)" in mode2_branch
    assert "app->tuning.base_speed_mode_2 = ADV_ROUTE2_BASE_SPEED_PPS;" in mode2_branch

    mode3_branch = reset_logic.split("if ((app->contest_task == CONTEST_TASK_BASIC_3) ||", 1)[1]
    mode3_branch = mode3_branch.split("car_app_sync_legacy_tuning_fields(app);", 1)[0]
    assert "if (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM)" in mode3_branch
    assert "app->tuning.base_speed_mode_3 = ADV_ROUTE3_BASE_SPEED_PPS;" in mode3_branch


def test_gimbal_does_not_center_on_power_up():
    gimbal = read(ROOT / "gimbal_servo.c")
    gimbal_h = read(ROOT / "gimbal_servo.h")
    board = read(BOARD)
    init_body = gimbal.split("void gimbal_servo_init(void)", 1)[1].split("void gimbal_servo_set_enabled", 1)[0]
    board_init_body = board.split("bool board_servo_gimbal_init(void)", 1)[1].split("static void board_motor_direction", 1)[0]
    assert "#define GIMBAL_SERVO_MIN_US         (600)" in gimbal
    assert "#define GIMBAL_SERVO_MAX_US         (2400)" in gimbal
    assert "g_gimbal.enabled = false;" in init_body
    assert "board_servo_gimbal_init();" not in init_body
    assert "board_servo_gimbal_set_us(1500U, 1500U)" not in board_init_body
    assert "return true;" in board_init_body
    assert "void gimbal_servo_sync_position(int32_t pan_us, int32_t tilt_us);" in gimbal_h
    assert "void gimbal_servo_sync_position(int32_t pan_us, int32_t tilt_us)" in gimbal
    sync_body = gimbal.split("void gimbal_servo_sync_position(int32_t pan_us, int32_t tilt_us)", 1)[1].split("void", 1)[0]
    assert "g_gimbal.pan_position_us = g_gimbal.pan_target_us;" in sync_body
    assert "g_gimbal.tilt_position_us = g_gimbal.tilt_target_us;" in sync_body


def test_gimbal_accepts_wheeltec_angle_commands():
    gimbal = read(ROOT / "gimbal_servo.c")
    gimbal_h = read(ROOT / "gimbal_servo.h")
    protocol = read(ROOT / "k230_protocol.c")

    assert "#define GIMBAL_PAN_MAX_DEG       (270)" in gimbal
    assert "#define GIMBAL_TILT_MAX_DEG      (180)" in gimbal
    assert "#define GIMBAL_SERVO_US_AT_0_DEG (500)" in gimbal
    assert "#define GIMBAL_SERVO_US_SPAN     (2000)" in gimbal
    assert "static int32_t gimbal_angle_to_us(int32_t angle_deg, int32_t max_deg)" in gimbal
    assert "GIMBAL_SERVO_US_AT_0_DEG + ((angle_deg * GIMBAL_SERVO_US_SPAN) / max_deg)" in gimbal
    assert "void gimbal_servo_set_angle(int32_t pan_deg, int32_t tilt_deg);" in gimbal_h
    assert "void gimbal_servo_sync_angle(int32_t pan_deg, int32_t tilt_deg);" in gimbal_h
    assert "void gimbal_servo_set_angle(int32_t pan_deg, int32_t tilt_deg)" in gimbal
    assert "void gimbal_servo_sync_angle(int32_t pan_deg, int32_t tilt_deg)" in gimbal
    assert 'strncmp(line, "GIMBALA,", 8U) == 0' in protocol
    assert "gimbal_servo_set_angle(first, second);" in protocol


def test_gimbal_pid_controls_ecg_and_aim_paths():
    app = read(CAR_APP)
    k230 = read(K230_MAIN)
    protocol = read(ROOT / "k230_protocol.c")
    gimbal = read(ROOT / "gimbal_servo.c")

    assert "ECG_LOCATE_PID_KP_NUM" not in app
    assert "ECG_LOCATE_PID_KD_NUM" not in app
    assert "#define GIMBAL_AIM_PID_KP_NUM 1" in app
    assert "#define GIMBAL_AIM_PID_KP_DEN 5" in app
    assert "#define GIMBAL_AIM_PID_KP_NUM" in app
    assert "#define GIMBAL_AIM_PID_KD_NUM" in app
    assert "#define GIMBAL_AIM_MAX_STEP_US 14" in app
    assert "#define GIMBAL_SERVO_MAX_US_PER_TICK (16)" in gimbal
    assert "#define ECG_LOCATE_PAN_REVERSE 0U" in app
    assert "#define GIMBAL_AIM_PAN_REVERSE 0U" in app
    assert "#define GIMBAL_AIM_TILT_REVERSE" in app
    assert "#define ECG_START_LEFT_OFFSET_PX 120" in app
    assert "#define ECG_BASELINE_Y_OFFSET_PX 0" in app
    assert "car_app_ecg_locate_pid_step" in app
    ecg_pid_body = app.split("static int16_t car_app_ecg_locate_pid_step", 1)[1].split("static int16_t car_app_gimbal_aim_pid_step", 1)[0]
    assert "GIMBAL_AIM_PID_KP_NUM" in ecg_pid_body
    assert "GIMBAL_AIM_PID_KD_NUM" in ecg_pid_body
    assert "GIMBAL_AIM_MAX_STEP_US" in ecg_pid_body
    assert "car_app_gimbal_aim_pid_step" in app
    assert "car_app_update_aim_gimbal_pid" in app
    assert "app->ecg_locate_pid" in app
    assert "app->gimbal_aim_pid" in app
    assert "gimbal_servo_offset(pan_delta, tilt_delta);" in app
    assert "AIM_PID_" not in k230
    assert "format_gimbal_pid_delta" not in k230
    assert "send_packet(uart, format_gimbal" not in k230
    assert "AIM_STATUS_INTERVAL_MS" in k230
    assert "state.last_aim_status_ms" in k230
    assert 'if state.mode == "AIM" and ticks_diff(now, state.last_aim_status_ms) >= AIM_STATUS_INTERVAL_MS:' in k230
    assert "send_packet(uart, vstat)" in k230
    assert "send_packet(uart, format_vdiag" in k230
    assert "desired_x = app->vision_state.frame_center_x - ECG_START_LEFT_OFFSET_PX;" in app
    assert "desired_y = app->vision_state.frame_center_y + ECG_BASELINE_Y_OFFSET_PX;" in app
    assert "if (ECG_LOCATE_PAN_REVERSE != 0U)" in app
    assert "vision_status_code == VISION_STATUS_TRACKING" in protocol
    assert "vision_status_code == VISION_STATUS_LOCKED" in protocol
    assert "g_vision_status.target_update_count++;" in protocol.split('if (strncmp(line, "VSTAT,", 6U) == 0)', 1)[1].split('if (strncmp(line, "VDIAG,", 6U) == 0)', 1)[0]


def test_aim_gimbal_searches_when_target_is_lost():
    app = read(CAR_APP)

    assert "#define GIMBAL_AIM_SEARCH_START_TICKS" in app
    assert "#define GIMBAL_AIM_SEARCH_UPDATE_TICKS" in app
    assert "#define GIMBAL_AIM_SEARCH_PAN_STEP_US" in app
    assert "#define GIMBAL_AIM_SEARCH_TILT_STEP_US" in app
    assert "#define GIMBAL_AIM_SEARCH_PAN_LIMIT_US" in app
    assert "#define GIMBAL_AIM_SEARCH_TILT_LIMIT_US" in app
    assert "aim_lost_ticks" in app
    assert "aim_search_update_ticks" in app
    assert "aim_search_pan_dir" in app
    assert "aim_search_tilt_dir" in app
    assert "aim_search_pan_offset_us" in app
    assert "aim_search_tilt_offset_us" in app
    assert "aim_last_seen_pan_us" in app
    assert "aim_last_seen_tilt_us" in app
    assert "aim_last_seen_valid" in app
    assert "car_app_reset_gimbal_aim_search" in app
    assert "car_app_update_aim_gimbal_search" in app
    assert "car_app_remember_aim_seen_pose" in app
    search_body = app.split("static void car_app_update_aim_gimbal_search", 1)[1].split("static void car_app_update_aim_gimbal_pid", 1)[0]
    assert "GIMBAL_AIM_SEARCH_START_TICKS" in search_body
    assert "GIMBAL_AIM_SEARCH_UPDATE_TICKS" in search_body
    assert "GIMBAL_AIM_SEARCH_PAN_STEP_US" in search_body
    assert "GIMBAL_AIM_SEARCH_TILT_STEP_US" in search_body
    assert "app->tuning.aim_pred_window_pan_us" in search_body
    assert "app->tuning.aim_pred_window_tilt_us" in search_body
    assert "app->aim_last_seen_valid" in search_body
    assert "gimbal_servo_set_target(" in search_body
    assert "anchor_pan_us + app->aim_search_pan_offset_us" in search_body
    assert "anchor_tilt_us + app->aim_search_tilt_offset_us" in search_body
    assert "gimbal_servo_offset(pan_delta, tilt_delta);" not in search_body
    aim_body = app.rsplit("static void car_app_update_aim_gimbal_pid", 1)[1].split("static void car_app_update_ecg_task", 1)[0]
    assert "if (!app->vision_state.frame_valid)" in aim_body
    assert "car_app_reset_gimbal_aim_search(app);" in aim_body
    assert "car_app_remember_aim_seen_pose(app);" in aim_body
    assert "(!app->vision_state.laser_valid)" in aim_body
    assert aim_body.find("if (!app->vision_state.frame_valid)") < aim_body.find("(!app->vision_state.laser_valid)")


def test_aim_lost_target_search_uses_route_prediction_window():
    app = read(CAR_APP)

    assert "#define GIMBAL_AIM_PRED_PAN_GAIN_US_PER_DEG_X10" in app
    assert "#define GIMBAL_AIM_PRED_BLEND_PERCENT" in app
    assert "#define GIMBAL_AIM_ROUTE2_AB_START_X10" in app
    assert "#define GIMBAL_AIM_ROUTE3_BD_END_X10" in app
    assert "aim_pred_blend_percent" in app
    assert "aim_pred_window_pan_us" in app
    assert "aim_pred_window_tilt_us" in app
    assert "car_app_predict_aim_anchor" in app
    assert "car_app_target_bearing_x10_for_leg" in app
    assert "car_app_blend_aim_anchor" in app

    search_body = app.split("static void car_app_update_aim_gimbal_search", 1)[1].split("static void car_app_update_aim_gimbal_pid", 1)[0]
    assert "car_app_predict_aim_anchor(app, &predicted_pan_us, &predicted_tilt_us)" in search_body
    assert "car_app_blend_aim_anchor(app, predicted_pan_us, predicted_tilt_us, &anchor_pan_us, &anchor_tilt_us);" in search_body
    assert "app->tuning.aim_pred_window_pan_us" in search_body
    assert "app->tuning.aim_pred_window_tilt_us" in search_body
    assert "gimbal_servo_set_target(" in search_body
    assert "anchor_pan_us + app->aim_search_pan_offset_us" in search_body
    assert "anchor_tilt_us + app->aim_search_tilt_offset_us" in search_body

    assert 'strncmp(line, "PARAM,AIMWIN,", 13U) == 0' in app
    assert 'strncmp(line, "PARAM,AIMBLEND,", 15U) == 0' in app
    assert 'strncmp(line, "PARAM,AIMGAIN,", 14U) == 0' in app
    assert 'strncmp(line, "PARAM,AIMBIAS,", 14U) == 0' in app
    assert 'car_app_param_ack("AIMWIN"' in app
    assert 'car_app_param_ack("AIMBLEND"' in app
    assert 'car_app_param_ack("AIMGAIN"' in app
    assert 'car_app_param_ack("AIMBIAS"' in app


def test_oled_can_show_advanced_task_labels():
    assert "void oled_show_task(" in read(OLED_H)
    oled = read(OLED_C)
    assert "oled_show_task(" in oled
    app = read(CAR_APP)
    assert '"A1 ECG"' in app
    assert '"A2 AIM"' in app
    assert '"A3 AIM"' in app
    assert "oled_show_task(" in app


def test_laser_relay_pin_documented_and_exported():
    assert "#define PIN_LASER_RELAY         \"PA22\"" in read(BOARD_CONFIG)
    app = read(CAR_APP)
    board = read(BOARD)
    assert '"CAR,LASER,"' in app
    assert 'car_app_control_ack(g_app.laser_power_on ? "LASER,1" : "LASER,0");' in app
    assert "#define LASER_RELAY_PORT            GPIOA" in board
    assert "#define LASER_RELAY_PIN             DL_GPIO_PIN_22" in board
    assert "#define LASER_RELAY_IOMUX           IOMUX_PINCM47" in board
    assert "#define LASER_RELAY_ACTIVE_HIGH     0U" in board
    assert "void board_set_laser_power(bool enabled)" in board
    assert "void board_set_laser_power(bool enabled);" in read(BOARD_H)
    doc = read(PIN_DOC)
    assert "`PA22` | 激光/瞄准模块继电器" in doc
    assert "`LASER_RELAY_IN`" in doc


def test_k230_local_tune_is_not_cancelled_by_periodic_mode_packets():
    k230 = load_k230_main()
    state = k230.RuntimeState()

    k230.enter_tune_mode(state, "B")
    assert state.mode == "TUNE"
    assert state.run_mode == "AIM"

    assert k230.handle_command("MODE,AIM", state)
    assert state.mode == "TUNE"
    assert state.run_mode == "AIM"

    assert k230.handle_command("MODE,STOP", state)
    assert state.mode == "TUNE"
    assert state.run_mode == "STOP"

    assert k230.handle_tune_button("return", state)
    assert state.mode == "STOP"
    assert state.view == "AIM"


def test_k230_default_black_threshold_is_field_tuned_value():
    k230 = load_k230_main()
    state = k230.RuntimeState()

    assert k230.DEFAULT_BLACK_THRESHOLD == [(65, 81)]
    assert state.black_threshold == [(65, 81)]


def test_k230_prefers_cv_lite_rectangles_with_find_rects_fallback():
    k230 = read(K230_MAIN)

    assert "import cv_lite" in k230
    assert "cv_lite = None" in k230
    assert "def make_cv_lite_frame_candidate" in k230
    assert "def find_frame_by_cv_lite" in k230
    assert "cv_lite.grayscale_find_rectangles_with_corners" in k230

    find_frame_body = k230.split("def find_frame(img, state):", 1)[1]
    find_frame_body = find_frame_body.split("def find_laser", 1)[0]
    assert "cv_candidate, cv_count = find_frame_by_cv_lite(gray, state)" in find_frame_body
    assert "binary.find_rects" in find_frame_body
    assert find_frame_body.find("find_frame_by_cv_lite") < find_frame_body.find("binary.find_rects")


if __name__ == "__main__":
    test_advanced_mode_entries_exist()
    test_physical_mode_buttons_1_and_2_are_swapped()
    test_k230_and_laser_are_linked_to_advanced_tasks()
    test_ecg_state_machine_is_nonblocking()
    test_ecg_uses_k230_frame_center_as_draw_origin()
    test_advanced_tasks_sync_gimbal_to_ecg_mount_on_every_start()
    test_advanced_route2_and_route3_have_slower_chassis_speeds()
    test_gimbal_does_not_center_on_power_up()
    test_gimbal_accepts_wheeltec_angle_commands()
    test_gimbal_pid_controls_ecg_and_aim_paths()
    test_aim_gimbal_searches_when_target_is_lost()
    test_aim_lost_target_search_uses_route_prediction_window()
    test_oled_can_show_advanced_task_labels()
    test_laser_relay_pin_documented_and_exported()
    test_k230_local_tune_is_not_cancelled_by_periodic_mode_packets()
    test_k230_default_black_threshold_is_field_tuned_value()
    test_k230_prefers_cv_lite_rectangles_with_find_rects_fallback()
    print("advanced task static checks passed")
