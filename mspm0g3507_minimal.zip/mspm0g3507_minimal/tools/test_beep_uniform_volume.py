from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAR_APP = ROOT / "car_app.c"
BOARD = ROOT / "board.c"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_app_uses_one_full_volume_beep_setting():
    text = read_text(CAR_APP)
    assert "#define APP_BEEP_FULL_VOLUME_HZ 2400U" in text
    assert "app->beep_frequency_hz = APP_BEEP_FULL_VOLUME_HZ;" in text
    assert "app->beep_frequency_hz = frequency_hz;" not in text


def test_all_beep_call_sites_are_unified():
    text = read_text(CAR_APP)
    assert "car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, 45U);" in text
    assert "car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, duration_ms);" in text
    assert "car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, app->profile->start_event_beep_ms);" in text
    assert "car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, app->profile->stop_event_beep_ms);" in text
    for literal in ("1600U", "1700U", "1900U", "2100U", "2200U"):
        assert f"car_app_queue_beep(app, {literal}," not in text


def test_board_buzzer_is_full_drive_gpio():
    text = read_text(BOARD)
    assert "DL_GPIO_clearPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_BUZZER_PIN);" in text
    assert "DL_GPIO_setPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_BUZZER_PIN);" in text
    assert "(void) frequency_hz;" in text


if __name__ == "__main__":
    test_app_uses_one_full_volume_beep_setting()
    test_all_beep_call_sites_are_unified()
    test_board_buzzer_is_full_drive_gpio()
    print("beep uniform volume static checks passed")
