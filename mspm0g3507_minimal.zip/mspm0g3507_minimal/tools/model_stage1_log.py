"""
Stage-1 CARLOG model extraction.

This script does not change firmware. It parses a stage log, removes obvious
invalid samples, separates straight / arc sections, fits a few simple
relationships, and prints candidate tuning commands derived from the log.
"""

from __future__ import annotations

import argparse
import math
import statistics
from dataclasses import dataclass
from pathlib import Path


TEXT_ENCODINGS = ("utf-8", "utf-8-sig", "utf-16", "utf-16-le", "gbk")


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def parse_int(value: str) -> int:
    return int(value, 0)


def parse_pair(value: str) -> tuple[int, int]:
    left, right = value.split("/", 1)
    return parse_int(left), parse_int(right)


def parse_triplet(value: str) -> tuple[float, float, float]:
    a, b, c = value.split("/", 2)
    return float(a), float(b), float(c)


def read_text_auto(path: Path) -> str:
    raw = path.read_bytes()
    last_error = None
    for encoding in TEXT_ENCODINGS:
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError as exc:
            last_error = exc
    if last_error is not None:
        raise last_error
    return ""


@dataclass(frozen=True)
class Row:
    t_ms: int
    profile: str
    mode: int
    state: int
    phase: int
    seg_idx: int
    seg_total: int
    loop_cur: int
    loop_total: int
    last: str
    leg: str
    leg_type: str
    leg_line_tracked: int
    leg_length_mm: int
    leg_heading_start_deg_x10: int
    leg_heading_end_deg_x10: int
    leg_progress_count: int
    leg_target_count: int
    heading_target_deg_x10: int
    heading_error_deg_x10: int
    line_ok: int
    line_mask: int
    raw_line_mask: int
    lact: int
    lmax_cur: int
    lmax_total: int
    err: int
    speed_l: int
    speed_r: int
    term_bal: int
    term_steer: int
    sbias: int
    tar_l: int
    tar_r: int
    pwm_l: int
    pwm_r: int
    yaw_deg: float
    roll_deg: float
    pitch_deg: float
    gz: float
    evt: int
    hold_ms: int
    orecap: int

    @property
    def avg_speed(self) -> float:
        return (self.speed_l + self.speed_r) / 2.0

    @property
    def avg_target(self) -> float:
        return (self.tar_l + self.tar_r) / 2.0

    @property
    def avg_pwm(self) -> float:
        return (self.pwm_l + self.pwm_r) / 2.0

    @property
    def pwm_diff(self) -> float:
        return self.pwm_r - self.pwm_l

    @property
    def speed_diff(self) -> float:
        return self.speed_r - self.speed_l

    @property
    def abs_heading_error_deg(self) -> float:
        return abs(self.heading_error_deg_x10) / 10.0


def parse_line(line: str) -> Row | None:
    text = line.strip()
    if not text.startswith("CARLOG,"):
        return None

    fields: dict[str, str] = {}
    for part in text.split(",")[1:]:
        if "=" not in part:
            continue
        key, value = part.split("=", 1)
        fields[key] = value

    try:
        seg_idx, seg_total = parse_pair(fields["seg"])
        loop_cur, loop_total = parse_pair(fields["loop"])
        lhd_start, lhd_end = parse_pair(fields.get("lhd", "0/0"))
        lcnt_cur, lcnt_total = parse_pair(fields.get("lcnt", "0/0"))
        hdg_target, hdg_error = parse_pair(fields.get("hdg", "0/0"))
        lmax_cur, lmax_total = parse_pair(fields.get("lmax", "0/0"))
        spd_l, spd_r = parse_pair(fields.get("spd", "0/0"))
        term_bal, term_steer = parse_pair(fields.get("term", "0/0"))
        tar_l, tar_r = parse_pair(fields.get("tar", "0/0"))
        pwm_l, pwm_r = parse_pair(fields.get("pwm", "0/0"))
        roll_deg, pitch_deg, yaw_deg = parse_triplet(fields.get("rpy", "0/0/0"))
        return Row(
            t_ms=parse_int(fields["t_ms"]),
            profile=fields.get("profile", ""),
            mode=parse_int(fields.get("mode", "0")),
            state=parse_int(fields.get("state", "0")),
            phase=parse_int(fields.get("phase", "0")),
            seg_idx=seg_idx,
            seg_total=seg_total,
            loop_cur=loop_cur,
            loop_total=loop_total,
            last=fields.get("last", ""),
            leg=fields.get("leg", ""),
            leg_type=fields.get("ltype", ""),
            leg_line_tracked=parse_int(fields.get("lline", "0")),
            leg_length_mm=parse_int(fields.get("llen", "0")),
            leg_heading_start_deg_x10=lhd_start,
            leg_heading_end_deg_x10=lhd_end,
            leg_progress_count=lcnt_cur,
            leg_target_count=lcnt_total,
            heading_target_deg_x10=hdg_target,
            heading_error_deg_x10=hdg_error,
            line_ok=parse_int(fields.get("line_ok", "0")),
            line_mask=parse_int(fields.get("line", "0")),
            raw_line_mask=parse_int(fields.get("lraw", "0")),
            lact=parse_int(fields.get("lact", "0")),
            lmax_cur=lmax_cur,
            lmax_total=lmax_total,
            err=parse_int(fields.get("err", "0")),
            speed_l=spd_l,
            speed_r=spd_r,
            term_bal=term_bal,
            term_steer=term_steer,
            sbias=parse_int(fields.get("sbias", "0")),
            tar_l=tar_l,
            tar_r=tar_r,
            pwm_l=pwm_l,
            pwm_r=pwm_r,
            yaw_deg=yaw_deg,
            roll_deg=roll_deg,
            pitch_deg=pitch_deg,
            gz=float(fields.get("gz", "0")),
            evt=parse_int(fields.get("evt", "0")),
            hold_ms=parse_int(fields.get("hold_ms", "0")),
            orecap=parse_int(fields.get("orecap", "0")),
        )
    except (KeyError, ValueError):
        return None


def load_rows(path: Path) -> list[Row]:
    rows: list[Row] = []
    for line in read_text_auto(path).splitlines():
        row = parse_line(line)
        if row is not None:
            rows.append(row)
    return rows


def unwrap_delta_deg(current: float, previous: float) -> float:
    delta = current - previous
    while delta > 180:
        delta -= 360
    while delta < -180:
        delta += 360
    return delta


def gaussian_elimination(mat: list[list[float]], vec: list[float]) -> list[float]:
    n = len(vec)
    a = [row[:] for row in mat]
    b = vec[:]
    for i in range(n):
        pivot = max(range(i, n), key=lambda r: abs(a[r][i]))
        if abs(a[pivot][i]) < 1e-12:
            return [0.0] * n
        if pivot != i:
            a[i], a[pivot] = a[pivot], a[i]
            b[i], b[pivot] = b[pivot], b[i]
        scale = a[i][i]
        for j in range(i, n):
            a[i][j] /= scale
        b[i] /= scale
        for r in range(n):
            if r == i:
                continue
            factor = a[r][i]
            if factor == 0:
                continue
            for c in range(i, n):
                a[r][c] -= factor * a[i][c]
            b[r] -= factor * b[i]
    return b


def fit_linear(xs: list[float], ys: list[float]) -> tuple[float, float]:
    if not xs or len(xs) != len(ys):
        return 0.0, 0.0
    mx = statistics.mean(xs)
    my = statistics.mean(ys)
    den = sum((x - mx) ** 2 for x in xs)
    if abs(den) < 1e-12:
        return 0.0, my
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den
    intercept = my - slope * mx
    return slope, intercept


def fit_affine(features: list[tuple[float, ...]], ys: list[float]) -> tuple[list[float], float]:
    if not features:
        return [], 0.0
    dim = len(features[0])
    xtx = [[0.0 for _ in range(dim + 1)] for _ in range(dim + 1)]
    xty = [0.0 for _ in range(dim + 1)]
    for row, y in zip(features, ys):
        x = [1.0, *row]
        for i in range(dim + 1):
            xty[i] += x[i] * y
            for j in range(dim + 1):
                xtx[i][j] += x[i] * x[j]
    for i in range(1, dim + 1):
        xtx[i][i] += 1e-6
    coeff = gaussian_elimination(xtx, xty)
    return coeff[1:], coeff[0]


def r2_score(features: list[tuple[float, ...]], ys: list[float], coeff: list[float], intercept: float) -> float:
    if not ys:
        return 0.0
    mean_y = statistics.mean(ys)
    ss_tot = sum((y - mean_y) ** 2 for y in ys)
    if abs(ss_tot) < 1e-12:
        return 1.0
    ss_res = 0.0
    for x, y in zip(features, ys):
        pred = intercept + sum(c * v for c, v in zip(coeff, x))
        ss_res += (y - pred) ** 2
    return 1.0 - ss_res / ss_tot


def fit_sparse_model(
    feature_rows: list[tuple[float, ...]],
    ys: list[float],
    feature_names: list[str],
) -> tuple[list[str], list[float], float, float]:
    if not feature_rows:
        return [], [], 0.0, 0.0

    selected_indices: list[int] = []
    for idx in range(len(feature_names)):
        column = [row[idx] for row in feature_rows]
        if statistics.pstdev(column) > 1e-9:
            selected_indices.append(idx)
    if not selected_indices:
        selected_indices = [0]

    selected_names = [feature_names[idx] for idx in selected_indices]
    selected_features = [tuple(row[idx] for idx in selected_indices) for row in feature_rows]
    coeff, intercept = fit_affine(selected_features, ys)
    score = r2_score(selected_features, ys, coeff, intercept)
    return selected_names, coeff, intercept, score


def select_runs(rows: list[Row]) -> list[list[Row]]:
    runs: list[list[Row]] = []
    current: list[Row] = []
    prev: Row | None = None
    for row in rows:
        if row.mode != 1:
            prev = row
            continue
        if row.state == 1:
            if prev is None or prev.state != 1 or prev.mode != 1:
                if current:
                    runs.append(current)
                current = [row]
            else:
                current.append(row)
        else:
            if current:
                runs.append(current)
                current = []
        prev = row
    if current:
        runs.append(current)
    return runs


def is_likely_invalid(row: Row) -> bool:
    if row.state != 1:
        return True
    if row.hold_ms > 0:
        return True
    if row.evt < 0:
        return True
    if row.leg == "":
        return True
    return False


def select_valid_rows(rows: list[Row]) -> list[Row]:
    valid: list[Row] = []
    for row in rows:
        if is_likely_invalid(row):
            continue
        if row.tar_l == 0 and row.tar_r == 0 and row.speed_l == 0 and row.speed_r == 0:
            continue
        valid.append(row)
    return valid


def select_ab_rows(rows: list[Row]) -> list[Row]:
    return [
        row
        for row in rows
        if row.state == 1 and row.leg == "AB" and row.leg_type == "ST" and row.seg_idx == 0
    ]


def select_bc_rows(rows: list[Row]) -> list[Row]:
    return [
        row
        for row in rows
        if row.state == 1 and row.leg == "BC" and row.leg_type == "ARC" and row.seg_idx == 1
    ]


def estimate_speed_model(rows: list[Row]) -> dict[str, float]:
    candidates = select_valid_rows(rows)
    if len(candidates) < 5:
        raise RuntimeError("not enough valid rows")

    pairs: list[tuple[Row, Row]] = []
    for prev, cur in zip(candidates, candidates[1:]):
        dt = (cur.t_ms - prev.t_ms) / 1000.0
        if dt <= 0 or dt > 0.5:
            continue
        if prev.leg != cur.leg or prev.seg_idx != cur.seg_idx:
            continue
        pairs.append((prev, cur))

    if not pairs:
        raise RuntimeError("not enough adjacent valid pairs")

    ab_rows = select_ab_rows(candidates)
    bc_rows = select_bc_rows(candidates)

    ab_prev_rows = []
    ab_lcnt_rates = []
    ab_yaw_rates = []
    for prev, cur in zip(ab_rows, ab_rows[1:]):
        dt = (cur.t_ms - prev.t_ms) / 1000.0
        if dt <= 0:
            continue
        ab_prev_rows.append(prev)
        ab_lcnt_rates.append((cur.leg_progress_count - prev.leg_progress_count) / dt)
        ab_yaw_rates.append(unwrap_delta_deg(cur.yaw_deg, prev.yaw_deg) / dt)

    if not ab_prev_rows:
        raise RuntimeError("not enough AB transitions")

    speed_features: list[tuple[float, ...]] = []
    speed_targets: list[float] = []
    for prev, cur in pairs:
        dt = (cur.t_ms - prev.t_ms) / 1000.0
        if dt <= 0:
            continue
        speed_features.append((float(prev.tar_l), float(prev.pwm_l), float(prev.speed_l)))
        speed_targets.append(float(cur.speed_l))
        speed_features.append((float(prev.tar_r), float(prev.pwm_r), float(prev.speed_r)))
        speed_targets.append(float(cur.speed_r))

    speed_names, speed_coeff, speed_intercept, speed_fit_r2 = fit_sparse_model(
        speed_features,
        speed_targets,
        ["target", "pwm", "speed"],
    )

    heading_features: list[tuple[float, ...]] = []
    heading_targets: list[float] = []
    for row in ab_rows:
        if abs(row.heading_error_deg_x10) > 0:
            heading_features.append((float(row.heading_error_deg_x10), float(row.sbias), float(row.avg_speed)))
            heading_targets.append(float(row.term_steer))
    heading_names, heading_coeff, heading_intercept, heading_fit_r2 = fit_sparse_model(
        heading_features,
        heading_targets,
        ["hdg_err", "sbias", "speed"],
    )

    line_features: list[tuple[float, ...]] = []
    line_targets: list[float] = []
    for row in bc_rows:
        if abs(row.err) > 0:
            line_features.append((float(row.err), float(row.sbias), float(row.avg_speed)))
            line_targets.append(float(row.term_steer))
    line_names, line_coeff, line_intercept, line_fit_r2 = fit_sparse_model(
        line_features,
        line_targets,
        ["line_err", "sbias", "speed"],
    )

    valid_speed_samples = [row.avg_speed for row in ab_rows if row.avg_speed > 0]
    valid_pwm_samples = [max(abs(row.pwm_l), abs(row.pwm_r)) for row in ab_rows]
    valid_tar_samples = [row.avg_target for row in ab_rows]
    max_target = max(valid_tar_samples)
    avg_target = statistics.mean(valid_tar_samples)
    avg_speed = statistics.mean(valid_speed_samples)
    avg_pwm = statistics.mean(valid_pwm_samples)
    max_pwm = max(valid_pwm_samples)
    avg_heading_error = statistics.mean(abs(row.heading_error_deg_x10) for row in ab_rows) / 10.0
    ab_lcnt_rate = statistics.median([rate for rate in ab_lcnt_rates if rate > 0])

    ab_start = ab_rows[0]
    ab_end = ab_rows[-1]
    bc_start = bc_rows[0] if bc_rows else None
    bc_end = bc_rows[-1] if bc_rows else None

    return {
        "ab_count": float(len(ab_rows)),
        "bc_count": float(len(bc_rows)),
        "ab_time_ms": float(ab_end.t_ms - ab_start.t_ms),
        "bc_time_ms": float((bc_end.t_ms - bc_start.t_ms) if bc_start and bc_end else 0),
        "ab_lcnt_start": float(ab_start.leg_progress_count),
        "ab_lcnt_end": float(ab_end.leg_progress_count),
        "bc_lcnt_start": float(bc_start.leg_progress_count if bc_start else 0),
        "bc_lcnt_end": float(bc_end.leg_progress_count if bc_end else 0),
        "ab_lcnt_rate": ab_lcnt_rate,
        "avg_target": avg_target,
        "max_target": max_target,
        "avg_speed": avg_speed,
        "avg_pwm": avg_pwm,
        "max_pwm": max_pwm,
        "avg_heading_error_deg": avg_heading_error,
        "speed_coeff_0": speed_coeff[0] if len(speed_coeff) > 0 else 0.0,
        "speed_coeff_1": speed_coeff[1] if len(speed_coeff) > 1 else 0.0,
        "speed_coeff_2": speed_coeff[2] if len(speed_coeff) > 2 else 0.0,
        "speed_intercept": speed_intercept,
        "speed_r2": speed_fit_r2,
        "speed_names": ",".join(speed_names),
        "heading_coeff_0": heading_coeff[0] if len(heading_coeff) > 0 else 0.0,
        "heading_coeff_1": heading_coeff[1] if len(heading_coeff) > 1 else 0.0,
        "heading_coeff_2": heading_coeff[2] if len(heading_coeff) > 2 else 0.0,
        "heading_intercept": heading_intercept,
        "heading_r2": heading_fit_r2,
        "heading_names": ",".join(heading_names),
        "line_coeff_0": line_coeff[0] if len(line_coeff) > 0 else 0.0,
        "line_coeff_1": line_coeff[1] if len(line_coeff) > 1 else 0.0,
        "line_coeff_2": line_coeff[2] if len(line_coeff) > 2 else 0.0,
        "line_intercept": line_intercept,
        "line_r2": line_fit_r2,
        "line_names": ",".join(line_names),
        "ab_yaw_rate_mean": statistics.mean(ab_yaw_rates),
    }


def predict_speed(base_target: int, current_target: float, current_speed: float) -> int:
    ratio = base_target / max(current_target, 1.0)
    return int(round(current_speed * ratio))


def recommend_candidates(stats: dict[str, float]) -> list[dict[str, int | float]]:
    current_base = int(round(stats["avg_target"]))
    bases = sorted({
        max(650, int(round(current_base * 1.0))),
        max(700, int(round(current_base * 1.1))),
        max(750, int(round(current_base * 1.2))),
        max(800, int(round(current_base * 1.3))),
    })

    hpid_base = (67, 21, 1, 401, 9, 20)
    line_base = 28 / 25
    results = []
    for base in bases:
        scale = base / max(current_base, 1.0)
        sqrt_scale = math.sqrt(scale)
        kp_num = int(round(hpid_base[0] * sqrt_scale))
        kd_num = int(round(hpid_base[4] * sqrt_scale))
        hlim = int(round(500 * scale / 50) * 50)
        hilim = int(round(600 * scale / 50) * 50)
        line_kp = line_base * scale
        line_num = int(round(line_kp * 25))
        arcff = int(round(-120 * scale / 10) * 10)
        results.append(
            {
                "base": base,
                "hpid_kp_num": kp_num,
                "hpid_kp_den": hpid_base[1],
                "hpid_ki_num": hpid_base[2],
                "hpid_ki_den": hpid_base[3],
                "hpid_kd_num": kd_num,
                "hpid_kd_den": hpid_base[5],
                "hdb": 2,
                "hilim": hilim,
                "hlim": hlim,
                "line_num": line_num,
                "line_den": 25,
                "arcff": arcff,
            }
        )
    return results


def print_report(path: Path, stats: dict[str, float]) -> None:
    print(f"log={path}")
    print(f"ab_rows={int(stats['ab_count'])}")
    print(f"bc_rows={int(stats['bc_count'])}")
    print(
        f"ab_lcnt={int(stats['ab_lcnt_start'])}->{int(stats['ab_lcnt_end'])}, "
        f"rate={stats['ab_lcnt_rate']:.1f} cnt/s"
    )
    print(
        f"bc_lcnt={int(stats['bc_lcnt_start'])}->{int(stats['bc_lcnt_end'])}, "
        f"time={stats['bc_time_ms']:.0f} ms"
    )
    print(
        f"avg_target={stats['avg_target']:.1f}, max_target={stats['max_target']:.1f}, "
        f"avg_speed={stats['avg_speed']:.1f}, avg_pwm={stats['avg_pwm']:.1f}, max_pwm={stats['max_pwm']:.1f}"
    )
    print(f"avg_heading_error_deg={stats['avg_heading_error_deg']:.3f}")
    print(
        "speed_model="
        f"spd_next = {stats['speed_intercept']:.3f}"
        f" + {stats['speed_coeff_0']:.4f}*{stats['speed_names'].split(',')[0] if stats['speed_names'] else 'x0'}"
        f" + {stats['speed_coeff_1']:.4f}*{stats['speed_names'].split(',')[1] if stats['speed_names'] and len(stats['speed_names'].split(',')) > 1 else 'x1'}"
        f" + {stats['speed_coeff_2']:.4f}*{stats['speed_names'].split(',')[2] if stats['speed_names'] and len(stats['speed_names'].split(',')) > 2 else 'x2'}"
        f", r2={stats['speed_r2']:.3f}"
    )
    print(
        "heading_model="
        f"term = {stats['heading_intercept']:.3f}"
        f" + {stats['heading_coeff_0']:.4f}*{stats['heading_names'].split(',')[0] if stats['heading_names'] else 'x0'}"
        f" + {stats['heading_coeff_1']:.4f}*{stats['heading_names'].split(',')[1] if stats['heading_names'] and len(stats['heading_names'].split(',')) > 1 else 'x1'}"
        f" + {stats['heading_coeff_2']:.4f}*{stats['heading_names'].split(',')[2] if stats['heading_names'] and len(stats['heading_names'].split(',')) > 2 else 'x2'}"
        f", r2={stats['heading_r2']:.3f}"
    )
    print(
        "line_model="
        f"term = {stats['line_intercept']:.3f}"
        f" + {stats['line_coeff_0']:.4f}*{stats['line_names'].split(',')[0] if stats['line_names'] else 'x0'}"
        f" + {stats['line_coeff_1']:.4f}*{stats['line_names'].split(',')[1] if stats['line_names'] and len(stats['line_names'].split(',')) > 1 else 'x1'}"
        f" + {stats['line_coeff_2']:.4f}*{stats['line_names'].split(',')[2] if stats['line_names'] and len(stats['line_names'].split(',')) > 2 else 'x2'}"
        f", r2={stats['line_r2']:.3f}"
    )
    print(
        f"ab_yaw_rate_mean={stats['ab_yaw_rate_mean']:.4f} deg/s per 200ms sample"
    )
    print()
    print("candidates:")
    for cand in recommend_candidates(stats):
        print(
            "  "
            f"CFG,BASE,{cand['base']} | "
            f"CFG,ANGLE,0 | "
            f"CFG,POSPID,{cand['hpid_kp_num']},{cand['hpid_kp_den']},{cand['hpid_ki_num']},{cand['hpid_ki_den']},{cand['hpid_kd_num']},{cand['hpid_kd_den']} | "
            f"CFG,LINEPID,{cand['line_num']},{cand['line_den']},0,100,3,1 | "
            f"CFG,SPDPID,9,8,2,8,0,1 | "
            f"CFG,HDB,{cand['hdb']} | CFG,HILIM,{cand['hilim']} | CFG,HLIM,{cand['hlim']} | CFG,ARCFF,{cand['arcff']}"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "log",
        nargs="?",
        default=str(Path.home() / "Desktop" / "阶段1.txt"),
        help="Path to a CARLOG stage file.",
    )
    args = parser.parse_args()

    log_path = Path(args.log)
    rows = load_rows(log_path)
    if not rows:
        raise SystemExit("no CARLOG rows found")
    stats = estimate_speed_model(rows)
    print_report(log_path, stats)


if __name__ == "__main__":
    main()
