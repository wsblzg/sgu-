import importlib.util
import unittest
from pathlib import Path


TOOLS_DIR = Path(__file__).resolve().parent
MODULE_PATH = TOOLS_DIR / "school_track_route_logic.py"
SPEC = importlib.util.spec_from_file_location("school_track_route_logic", MODULE_PATH)
school_track_route_logic = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(school_track_route_logic)


class SchoolTrackRouteLogicTest(unittest.TestCase):
    def test_mode1_stops_at_b_then_continues_to_c(self):
        controller = school_track_route_logic.SchoolTrackRouteController(mode=1, loops=1)
        self.assertEqual(controller.current_leg_name(), "AB")
        self.assertEqual(controller.current_motion_mode(), "HEADING")

        controller.advance_distance_mm(1000.0)
        self.assertEqual(controller.phase, school_track_route_logic.PHASE_HOLD)
        self.assertEqual(controller.current_leg_name(), "BC")

        controller.tick_hold(600)
        self.assertEqual(controller.phase, school_track_route_logic.PHASE_TRACK)
        controller.advance_distance_mm(1256.6370614359173)
        self.assertEqual(controller.phase, school_track_route_logic.PHASE_FINISHED)

    def test_mode2_leg_sequence(self):
        controller = school_track_route_logic.SchoolTrackRouteController(mode=2, loops=1)
        self.assertEqual(controller.current_leg_name(), "AB")
        controller.advance_distance_mm(1000.0)
        self.assertEqual(controller.current_leg_name(), "BC")
        self.assertEqual(controller.current_motion_mode(), "LINE")
        controller.advance_distance_mm(1256.6370614359173)
        self.assertEqual(controller.current_leg_name(), "CD")
        controller.advance_distance_mm(1000.0)
        self.assertEqual(controller.current_leg_name(), "DA")

    def test_mode3_leg_sequence_and_headings(self):
        controller = school_track_route_logic.SchoolTrackRouteController(mode=3, loops=2)
        self.assertEqual(controller.current_leg_name(), "AC")
        self.assertEqual(controller.current_heading_deg_x10(), -387)
        controller.advance_distance_mm(1280.6248474865697)
        self.assertEqual(controller.current_leg_name(), "CB")
        controller.advance_distance_mm(1256.6370614359173)
        self.assertEqual(controller.current_leg_name(), "BD")
        self.assertEqual(controller.current_heading_deg_x10(), -1413)

    def test_mode3_loop_count(self):
        controller = school_track_route_logic.SchoolTrackRouteController(mode=3, loops=2)
        total = (
            2.0 * 1280.6248474865697
            + 2.0 * 1256.6370614359173
        )
        controller.advance_distance_mm(total)
        self.assertEqual(controller.completed_loops, 1)
        self.assertEqual(controller.current_leg_name(), "AC")


if __name__ == "__main__":
    unittest.main()
