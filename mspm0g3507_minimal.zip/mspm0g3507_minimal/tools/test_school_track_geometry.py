import importlib.util
import math
import unittest
from pathlib import Path


TOOLS_DIR = Path(__file__).resolve().parent
MODULE_PATH = TOOLS_DIR / "school_track_geometry.py"
SPEC = importlib.util.spec_from_file_location("school_track_geometry", MODULE_PATH)
school_track_geometry = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(school_track_geometry)


class SchoolTrackGeometryTest(unittest.TestCase):
    def test_straight_and_arc_lengths(self):
        self.assertEqual(
            school_track_geometry.build_segment("AB").length_mm,
            1000.0,
        )
        self.assertAlmostEqual(
            school_track_geometry.build_segment("CB").length_mm,
            math.pi * 400.0,
            places=6,
        )
        self.assertAlmostEqual(
            school_track_geometry.build_segment("AC").length_mm,
            math.hypot(1000.0, 800.0),
            places=6,
        )

    def test_mode2_and_mode3_route_lengths(self):
        mode2 = school_track_geometry.build_route("mode2")
        mode3 = school_track_geometry.build_route("mode3")

        self.assertAlmostEqual(mode2.total_length_mm, 2000.0 + 2.0 * math.pi * 400.0, places=6)
        self.assertAlmostEqual(
            mode3.total_length_mm,
            2.0 * math.hypot(1000.0, 800.0) + 2.0 * math.pi * 400.0,
            places=6,
        )

    def test_diagonal_headings(self):
        ac = school_track_geometry.build_segment("AC")
        bd = school_track_geometry.build_segment("BD")

        self.assertAlmostEqual(ac.start_heading_deg, -38.65980825409009, places=6)
        self.assertAlmostEqual(bd.start_heading_deg, -141.34019174590992, places=6)

    def test_required_average_speed(self):
        mode2 = school_track_geometry.build_route("mode2")
        mode3 = school_track_geometry.build_route("mode3")

        self.assertAlmostEqual(
            school_track_geometry.required_average_speed_mm_s(mode2, 30.0),
            mode2.total_length_mm / 30.0,
            places=6,
        )
        self.assertAlmostEqual(
            school_track_geometry.required_average_speed_mm_s(mode3, 40.0),
            mode3.total_length_mm / 40.0,
            places=6,
        )

    def test_sampling_reaches_route_end(self):
        route = school_track_geometry.build_route("mode3")
        poses = school_track_geometry.sample_route(route, speed_mm_s=250.0, dt_s=0.05)

        self.assertGreater(len(poses), 10)
        self.assertAlmostEqual(poses[0].x_mm, route.segments[0].start.x_mm, places=6)
        self.assertAlmostEqual(poses[-1].x_mm, route.segments[-1].end.x_mm, places=3)
        self.assertAlmostEqual(poses[-1].y_mm, route.segments[-1].end.y_mm, places=3)


if __name__ == "__main__":
    unittest.main()
