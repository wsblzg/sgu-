from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAR_APP = ROOT / "car_app.c"


def read_car_app() -> str:
    return CAR_APP.read_text(encoding="utf-8")


def test_mode3_diagonal_has_per_loop_arrays():
    text = read_car_app()
    assert "mode3_ac_heading_x10[MODE3_LOOP_MAX]" in text
    assert "mode3_bd_heading_x10[MODE3_LOOP_MAX]" in text


def test_mode3_diagonal_commands_exist():
    text = read_car_app()
    assert 'strncmp(line, "PARAM,M3AC,"' in text
    assert 'strncmp(line, "PARAM,M3BD,"' in text
    assert 'strncmp(line, "PARAM,M3DIAG,"' in text
    assert 'strcmp(line, "PARAM,M3SHOW")' in text


def test_legacy_ac_bd_commands_apply_all_loops():
    text = read_car_app()
    assert "car_app_set_mode3_ac_all" in text
    assert "car_app_set_mode3_bd_all" in text


def test_mode3_ac_loop1_default_is_current_tuned_value():
    text = read_car_app()
    assert "#define MODE3_AC_LOOP1_HEADING_X10 -415" in text
    assert "app->tuning.mode3_ac_heading_x10[0] = MODE3_AC_LOOP1_HEADING_X10;" in text


def test_mode3_bd_loop1_default_is_current_tuned_value():
    text = read_car_app()
    assert "#define MODE3_BD_LOOP1_HEADING_X10 +735" in text
    assert "app->tuning.mode3_bd_heading_x10[0] = MODE3_BD_LOOP1_HEADING_X10;" in text


def test_mode3_loop2_and_loop3_defaults_are_macro_controlled():
    text = read_car_app()
    assert "#define MODE3_AC_LOOP2_HEADING_X10 -715" in text
    assert "#define MODE3_BD_LOOP2_HEADING_X10 +740" in text
    assert "#define MODE3_AC_LOOP3_HEADING_X10 -700" in text
    assert "#define MODE3_BD_LOOP3_HEADING_X10 +745" in text
    assert "app->tuning.mode3_ac_heading_x10[1] = MODE3_AC_LOOP2_HEADING_X10;" in text
    assert "app->tuning.mode3_bd_heading_x10[1] = MODE3_BD_LOOP2_HEADING_X10;" in text
    assert "app->tuning.mode3_ac_heading_x10[2] = MODE3_AC_LOOP3_HEADING_X10;" in text
    assert "app->tuning.mode3_bd_heading_x10[2] = MODE3_BD_LOOP3_HEADING_X10;" in text


def test_mode3_cb_arc_feedforward_remains_reverse_direction():
    text = read_car_app()
    arc_logic = text.split("static int16_t car_app_arc_feedforward_pps_for_leg", 1)[1]
    arc_logic = arc_logic.split("static int32_t car_app_line_steering_term_pps", 1)[0]
    assert "leg->start_node == ROUTE_NODE_C) && (leg->end_node == ROUTE_NODE_B)" in arc_logic
    assert "return (int16_t) -app->tuning.mode1_arc_feedforward_pps;" in arc_logic


def test_mode3_uses_mode1_line_strength_defaults():
    text = read_car_app()
    reset_logic = text.split("static void car_app_reset_runtime_tuning", 1)[1]
    reset_logic = reset_logic.split("static void car_app_queue_beep", 1)[0]
    assert "CONTEST_TASK_BASIC_3" in reset_logic
    assert "app->tuning.line_pid.output_limit = LINE_TURN_OUTPUT_LIMIT_PPS;" in reset_logic


def test_advanced_route3_reuses_mode3_runtime_tuning():
    text = read_car_app()
    reset_logic = text.split("static void car_app_reset_runtime_tuning", 1)[1]
    reset_logic = reset_logic.split("static void car_app_queue_beep", 1)[0]
    assert "if ((app->contest_task == CONTEST_TASK_BASIC_3) ||" in reset_logic
    mode3_branch = reset_logic.split("if ((app->contest_task == CONTEST_TASK_BASIC_3) ||", 1)[1]
    mode3_branch = mode3_branch.split("car_app_sync_legacy_tuning_fields(app);", 1)[0]
    assert "CONTEST_TASK_ADV_ROUTE3_AIM" in mode3_branch


def test_advanced_route3_reuses_mode3_straight_heading_logic():
    text = read_car_app()
    heading_logic = text.split("static int16_t car_app_current_leg_heading_target_x10", 1)[1]
    heading_logic = heading_logic.split("static int16_t car_app_arc_feedforward_pps_for_leg", 1)[0]
    mode3_branch = heading_logic.split("leg->heading_start_deg_x10 + app->tuning.target_heading_deg_x10", 1)[0]
    mode3_branch = mode3_branch.rsplit("if (", 1)[1]
    assert "CONTEST_TASK_BASIC_3" in mode3_branch
    assert "CONTEST_TASK_ADV_ROUTE3_AIM" in mode3_branch
    assert "leg->type == SCHOOL_LEG_STRAIGHT" in mode3_branch


def test_mode3_does_not_override_straight_position_defaults():
    text = read_car_app()
    reset_logic = text.split("static void car_app_reset_runtime_tuning", 1)[1]
    reset_logic = reset_logic.split("static void car_app_queue_beep", 1)[0]
    mode3_block = reset_logic.split("if ((app->contest_task == CONTEST_TASK_BASIC_3) ||", 1)[1]
    mode3_block = mode3_block.split("car_app_sync_legacy_tuning_fields(app);", 1)[0]
    assert "app->tuning.position_pid" not in mode3_block
    assert "app->tuning.straight_bias_pps = 26;" not in mode3_block
    assert "app->tuning.base_speed_mode_3 = 900;" not in mode3_block
    assert "app->tuning.speed_pid" not in mode3_block


if __name__ == "__main__":
    test_mode3_diagonal_has_per_loop_arrays()
    test_mode3_diagonal_commands_exist()
    test_legacy_ac_bd_commands_apply_all_loops()
    test_mode3_ac_loop1_default_is_current_tuned_value()
    test_mode3_bd_loop1_default_is_current_tuned_value()
    test_mode3_loop2_and_loop3_defaults_are_macro_controlled()
    test_mode3_cb_arc_feedforward_remains_reverse_direction()
    test_mode3_uses_mode1_line_strength_defaults()
    test_advanced_route3_reuses_mode3_runtime_tuning()
    test_advanced_route3_reuses_mode3_straight_heading_logic()
    test_mode3_does_not_override_straight_position_defaults()
    print("mode3 diagonal tuning static checks passed")
