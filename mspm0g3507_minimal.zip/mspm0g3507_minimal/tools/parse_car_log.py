import argparse
import csv
from pathlib import Path


TEXT_ENCODINGS = (
    "utf-8",
    "utf-8-sig",
    "utf-16",
    "utf-16-le",
    "gbk",
)


def parse_line(line: str):
    text = line.strip()
    if not text.startswith("CARLOG,"):
        return None

    fields = {}
    for item in text.split(",")[1:]:
        if "=" not in item:
            continue
        key, value = item.split("=", 1)
        fields[key] = value

    seg_idx, seg_total = fields["seg"].split("/")
    loop_cur, loop_total = fields["loop"].split("/")
    leg_heading_start_deg_x10 = 0
    leg_heading_end_deg_x10 = 0
    leg_progress_count = 0
    leg_target_count = 0
    heading_target_deg_x10 = 0
    heading_error_deg_x10 = 0
    vision_err_x = 0
    vision_err_y = 0
    gimbal_enabled = 0
    gimbal_pan_us = 0
    gimbal_tilt_us = 0
    gimbal_pan_target_us = 0
    gimbal_tilt_target_us = 0
    spd_l, spd_r = fields["spd"].split("/")
    tar_l, tar_r = fields["tar"].split("/")
    pwm_l, pwm_r = fields["pwm"].split("/")

    if "lhd" in fields:
        leg_heading_start_text, leg_heading_end_text = fields["lhd"].split("/")
        leg_heading_start_deg_x10 = int(leg_heading_start_text)
        leg_heading_end_deg_x10 = int(leg_heading_end_text)

    if "lcnt" in fields:
        leg_progress_text, leg_target_text = fields["lcnt"].split("/")
        leg_progress_count = int(leg_progress_text)
        leg_target_count = int(leg_target_text)

    if "hdg" in fields:
        heading_target_text, heading_error_text = fields["hdg"].split("/")
        heading_target_deg_x10 = int(heading_target_text)
        heading_error_deg_x10 = int(heading_error_text)

    if "verr" in fields:
        vision_err_x_text, vision_err_y_text = fields["verr"].split("/")
        vision_err_x = int(vision_err_x_text)
        vision_err_y = int(vision_err_y_text)

    if "gim_en" in fields:
        gimbal_enabled = int(fields["gim_en"])

    if "gim_us" in fields:
        gimbal_pan_text, gimbal_tilt_text = fields["gim_us"].split("/")
        gimbal_pan_us = int(gimbal_pan_text)
        gimbal_tilt_us = int(gimbal_tilt_text)

    if "gim_tar_us" in fields:
        gimbal_pan_target_text, gimbal_tilt_target_text = fields["gim_tar_us"].split("/")
        gimbal_pan_target_us = int(gimbal_pan_target_text)
        gimbal_tilt_target_us = int(gimbal_tilt_target_text)

    return {
        "t_ms": int(fields["t_ms"]),
        "profile": fields["profile"],
        "mode": int(fields["mode"]),
        "k230_mode": fields.get("k230", ""),
        "leg": fields.get("leg", ""),
        "leg_type": fields.get("ltype", ""),
        "leg_line_tracked": int(fields.get("lline", "0")),
        "leg_length_mm": int(fields.get("llen", "0")),
        "leg_heading_start_deg_x10": leg_heading_start_deg_x10,
        "leg_heading_end_deg_x10": leg_heading_end_deg_x10,
        "leg_progress_count": leg_progress_count,
        "leg_target_count": leg_target_count,
        "heading_target_deg_x10": heading_target_deg_x10,
        "heading_error_deg_x10": heading_error_deg_x10,
        "vision_online": int(fields.get("vok", "0")),
        "vision_status": fields.get("vstat", ""),
        "vision_err_x": vision_err_x,
        "vision_err_y": vision_err_y,
        "gimbal_enabled": gimbal_enabled,
        "gimbal_pan_us": gimbal_pan_us,
        "gimbal_tilt_us": gimbal_tilt_us,
        "gimbal_pan_target_us": gimbal_pan_target_us,
        "gimbal_tilt_target_us": gimbal_tilt_target_us,
        "state": int(fields["state"]),
        "phase": int(fields["phase"]),
        "seg_idx": int(seg_idx),
        "seg_total": int(seg_total),
        "loop_cur": int(loop_cur),
        "loop_total": int(loop_total),
        "last": fields["last"],
        "evt": int(fields["evt"]),
        "hold_ms": int(fields["hold_ms"]),
        "line_ok": int(fields["line_ok"]),
        "line_mask": fields["line"],
        "err": int(fields["err"]),
        "spd_l": int(spd_l),
        "spd_r": int(spd_r),
        "tar_l": int(tar_l),
        "tar_r": int(tar_r),
        "pwm_l": int(pwm_l),
        "pwm_r": int(pwm_r),
        "yaw_deg": float(fields["yaw"]),
    }


def read_text_auto(path: Path):
    raw = path.read_bytes()
    last_error = None
    for encoding in TEXT_ENCODINGS:
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError as exc:
            last_error = exc
    if last_error is not None:
        raise last_error
    return ""


def load_rows(path: Path):
    rows = []
    for line in read_text_auto(path).splitlines():
        row = parse_line(line)
        if row is not None:
            rows.append(row)
    return rows


def write_csv(path: Path, rows):
    if not rows:
        return

    with path.open("w", encoding="utf-8", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def print_summary(rows):
    if not rows:
        print("No CARLOG lines found.")
        return

    first = rows[0]
    last = rows[-1]
    max_abs_err = max(abs(row["err"]) for row in rows)
    max_hold_ms = max(row["hold_ms"] for row in rows)
    max_evt = max(row["evt"] for row in rows)

    print(f"rows={len(rows)}")
    print(f"profile={last['profile']}")
    print(f"mode={last['mode']}")
    if last.get("k230_mode"):
        print(f"k230_mode={last['k230_mode']}")
    if last.get("leg"):
        print(
            f"leg={last['leg']} type={last['leg_type']} "
            f"line={last['leg_line_tracked']} "
            f"len_mm={last['leg_length_mm']} "
            f"head_x10={last['leg_heading_start_deg_x10']}/{last['leg_heading_end_deg_x10']} "
            f"count={last['leg_progress_count']}/{last['leg_target_count']} "
            f"hdg={last['heading_target_deg_x10']}/{last['heading_error_deg_x10']}"
        )
    if last.get("vision_status"):
        print(
            f"vision={last['vision_status']} "
            f"online={last['vision_online']} "
            f"err={last['vision_err_x']}/{last['vision_err_y']}"
        )
    if last.get("gimbal_enabled"):
        print(
            f"gimbal=enabled "
            f"us={last['gimbal_pan_us']}/{last['gimbal_tilt_us']} "
            f"target={last['gimbal_pan_target_us']}/{last['gimbal_tilt_target_us']}"
        )
    print(f"time_ms={first['t_ms']}->{last['t_ms']}")
    print(f"events={max_evt}")
    print(f"last_node={last['last']}")
    print(f"loop={last['loop_cur']}/{last['loop_total']}")
    print(f"state={last['state']}")
    print(f"phase={last['phase']}")
    print(f"max_hold_ms={max_hold_ms}")
    print(f"max_abs_err={max_abs_err}")


def main():
    parser = argparse.ArgumentParser(description="Parse CARLOG lines into CSV and summary.")
    parser.add_argument("input", type=Path, help="Input log file")
    parser.add_argument("--csv", type=Path, help="Optional CSV output path")
    args = parser.parse_args()

    rows = load_rows(args.input)
    print_summary(rows)
    if args.csv is not None:
        write_csv(args.csv, rows)
        print(f"csv={args.csv}")


if __name__ == "__main__":
    main()
