import importlib.util
import tempfile
import unittest
from pathlib import Path


TOOLS_DIR = Path(__file__).resolve().parent
MODULE_PATH = TOOLS_DIR / "calibrate_odometry.py"
SPEC = importlib.util.spec_from_file_location("calibrate_odometry", MODULE_PATH)
calibrate_odometry = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(calibrate_odometry)


SAMPLE_LOG = (
    "CARLOG,t_ms=100,profile=safe,mode=3,k230=STOP,state=1,phase=0,seg=0/4,loop=1/1,"
    "last=A,leg=AC,ltype=ST,lline=0,llen=1281,lhd=-387/-387,lcnt=320/1281,hdg=-387/-20,evt=0,hold_ms=0,"
    "line_ok=0,line=0x00,err=0,vok=0,vstat=IDLE,verr=0/0,spd=800/800,tar=900/900,pwm=2000/2000,yaw=-36.7\n"
    "CARLOG,t_ms=200,profile=safe,mode=3,k230=STOP,state=1,phase=0,seg=0/4,loop=1/1,"
    "last=A,leg=AC,ltype=ST,lline=0,llen=1281,lhd=-387/-387,lcnt=640/1281,hdg=-387/-10,evt=0,hold_ms=0,"
    "line_ok=0,line=0x00,err=0,vok=0,vstat=IDLE,verr=0/0,spd=800/800,tar=900/900,pwm=2000/2000,yaw=-37.7\n"
)


class CalibrateOdometryTest(unittest.TestCase):
    def test_counts_per_mm_x100(self):
        self.assertEqual(calibrate_odometry.counts_per_mm_x100(640, 320.0), 200)

    def test_pick_leg_count_from_log(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_path = Path(temp_dir) / "sample.log"
            log_path.write_text(SAMPLE_LOG, encoding="utf-8")

            result = calibrate_odometry.calibrate_from_log(log_path, "AC", 320.0)

            self.assertEqual(result["counts"], 640)
            self.assertEqual(result["counts_per_mm_x100"], 200)


if __name__ == "__main__":
    unittest.main()
