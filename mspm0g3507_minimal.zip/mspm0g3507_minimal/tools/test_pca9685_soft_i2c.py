from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BOARD_C = ROOT / "board.c"
BOARD_CONFIG_H = ROOT / "board_config.h"
PIN_DOC = ROOT / "引脚分配表.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_pca9685_uses_pb0_pb1_soft_i2c():
    text = read(BOARD_C)
    assert "PCA9685_SDA_PIN" in text
    assert "DL_GPIO_PIN_0" in text
    assert "PCA9685_SCL_PIN" in text
    assert "DL_GPIO_PIN_1" in text
    assert "PCA9685_SDA_IOMUX" in text
    assert "IOMUX_PINCM12" in text
    assert "PCA9685_SCL_IOMUX" in text
    assert "IOMUX_PINCM13" in text


def test_pca9685_no_longer_uses_hardware_i2c_helpers():
    text = read(BOARD_C)
    pca_section = text.split("static bool pca9685_set_pwm", 1)[0]
    pca_section += text.split("static bool pca9685_set_pwm", 1)[1].split(
        "bool board_servo_gimbal_set_channel_us", 1
    )[0]
    assert "pca9685_i2c_write_bytes" in pca_section
    assert "pca9685_i2c_read_u8" in pca_section
    assert "board_i2c_write_bytes(PCA9685_DEFAULT_ADDR" not in pca_section
    assert "board_i2c_write_u8(PCA9685_DEFAULT_ADDR" not in pca_section
    assert "board_i2c_read_u8(PCA9685_DEFAULT_ADDR" not in pca_section


def test_pin_docs_show_pca9685_separated_from_line_i2c():
    config = read(BOARD_CONFIG_H)
    doc = read(PIN_DOC)
    assert '#define PIN_PCA9685_SDA          "PB0"' in config
    assert '#define PIN_PCA9685_SCL          "PB1"' in config
    assert "`PB0` | `PCA9685_SDA`" in doc
    assert "`PB1` | `PCA9685_SCL`" in doc
    assert "`PA0` | 巡线模块 `I2C SDA`" in doc
    assert "`PA1` | 巡线模块 `I2C SCL`" in doc


if __name__ == "__main__":
    test_pca9685_uses_pb0_pb1_soft_i2c()
    test_pca9685_no_longer_uses_hardware_i2c_helpers()
    test_pin_docs_show_pca9685_separated_from_line_i2c()
    print("PCA9685 soft I2C static checks passed")
