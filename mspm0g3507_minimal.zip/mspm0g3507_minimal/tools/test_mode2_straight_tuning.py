from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAR_APP = ROOT / "car_app.c"


def read_car_app() -> str:
    return CAR_APP.read_text(encoding="utf-8")


def test_mode2_straight_has_separate_tuning_fields():
    text = read_car_app()
    assert "mode2_ab_heading_x10" in text
    assert "mode2_cd_heading_x10" in text


def test_mode2_straight_commands_exist():
    text = read_car_app()
    assert 'strncmp(line, "PARAM,M2AB,"' in text
    assert 'strncmp(line, "PARAM,M2CD,"' in text
    assert 'strncmp(line, "PARAM,M2ST,"' in text
    assert 'strcmp(line, "PARAM,M2SHOW")' in text


def test_mode2_straight_no_longer_uses_cd_macro_in_target_logic():
    text = read_car_app()
    target_logic = text.split("static int16_t car_app_current_leg_heading_target_x10", 1)[1]
    target_logic = target_logic.split("static int16_t car_app_arc_feedforward_pps_for_leg", 1)[0]
    assert "mode2_ab_heading_x10" in target_logic
    assert "mode2_cd_heading_x10" in target_logic
    assert "MODE2_CD_HEADING_TRIM_X10" not in target_logic


def test_mode2_cd_default_is_current_tuned_value():
    text = read_car_app()
    assert "#define MODE2_CD_HEADING_TRIM_X10 -330" in text


def test_advanced_route2_reuses_mode2_runtime_tuning():
    text = read_car_app()
    reset_logic = text.split("static void car_app_reset_runtime_tuning", 1)[1]
    reset_logic = reset_logic.split("static void car_app_queue_beep", 1)[0]
    mode2_branch = reset_logic.split("if ((app->contest_task == CONTEST_TASK_BASIC_1) ||", 1)[1]
    mode2_branch = mode2_branch.split("if ((app->contest_task == CONTEST_TASK_BASIC_3) ||", 1)[0]
    assert "CONTEST_TASK_BASIC_2" in mode2_branch
    assert "CONTEST_TASK_ADV_ROUTE2_AIM" in mode2_branch


def test_advanced_route2_reuses_mode2_straight_heading_logic():
    text = read_car_app()
    heading_logic = text.split("static int16_t car_app_current_leg_heading_target_x10", 1)[1]
    heading_logic = heading_logic.split("static int16_t car_app_arc_feedforward_pps_for_leg", 1)[0]
    mode2_branch = heading_logic.split("int16_t mode2_heading_x10 = app->tuning.mode2_ab_heading_x10;", 1)[0]
    mode2_branch = mode2_branch.rsplit("if (", 1)[1]
    assert "CONTEST_TASK_BASIC_2" in mode2_branch
    assert "CONTEST_TASK_ADV_ROUTE2_AIM" in mode2_branch
    assert "leg->type == SCHOOL_LEG_STRAIGHT" in mode2_branch


if __name__ == "__main__":
    test_mode2_straight_has_separate_tuning_fields()
    test_mode2_straight_commands_exist()
    test_mode2_straight_no_longer_uses_cd_macro_in_target_logic()
    test_mode2_cd_default_is_current_tuned_value()
    test_advanced_route2_reuses_mode2_runtime_tuning()
    test_advanced_route2_reuses_mode2_straight_heading_logic()
    print("mode2 straight tuning static checks passed")
