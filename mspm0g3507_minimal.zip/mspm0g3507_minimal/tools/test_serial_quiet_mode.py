from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_text(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


def test_periodic_carlog_is_disabled_by_default():
    text = read_text("car_app.c")
    assert "#define SERIAL_PERIODIC_LOG_ENABLED 0U" in text
    tick_body = text.split("void car_app_tick(void)", 1)[1]
    assert "if (SERIAL_PERIODIC_LOG_ENABLED &&" in tick_body


def test_button_event_output_is_disabled_by_default():
    text = read_text("car_app.c")
    assert "#define SERIAL_EVENT_LOG_ENABLED 0U" in text
    event_body = text.split("static void car_app_print_button_event", 1)[1]
    event_body = event_body.split("static void car_app_handle_start_button", 1)[0]
    assert "if (!SERIAL_EVENT_LOG_ENABLED)" in event_body


def test_k230_mode_output_is_change_only_for_advanced_task_switching():
    text = read_text("car_app.c")
    assert "#define SERIAL_K230_MODE_OUTPUT_ENABLED 1U" in text
    tick_body = text.split("void car_app_tick(void)", 1)[1]
    assert "if (SERIAL_K230_MODE_OUTPUT_ENABLED)" in tick_body
    k230 = read_text("k230_protocol.c")
    assert "if (g_has_last_mode && (g_last_mode == mode))" in k230


def test_command_echo_is_disabled_but_command_responses_remain():
    k230 = read_text("k230_protocol.c")
    car_app = read_text("car_app.c")

    assert "#define K230_COMMAND_ECHO_ENABLED 0U" in k230
    assert "if (!K230_COMMAND_ECHO_ENABLED)" in k230
    assert "PARAM_OK,%s=%ld" in car_app
    assert "PARAM_ERR," in car_app
    assert "CAR_OK," in car_app
    assert "CAR_ERR," in car_app


if __name__ == "__main__":
    test_periodic_carlog_is_disabled_by_default()
    test_button_event_output_is_disabled_by_default()
    test_k230_mode_output_is_change_only_for_advanced_task_switching()
    test_command_echo_is_disabled_but_command_responses_remain()
    print("serial quiet mode static checks passed")
