from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


def read_text(name):
    return (ROOT / name).read_text(encoding="utf-8")


class StageParamDisplayTest(unittest.TestCase):
    def test_mode2_cd_default_is_hardened_to_latest_tuned_value(self):
        source = read_text("car_app.c")

        self.assertIn("#define MODE2_CD_HEADING_TRIM_X10 -330", source)
        self.assertIn("app->tuning.mode2_cd_heading_x10 = MODE2_CD_HEADING_TRIM_X10;", source)

    def test_carlog_contains_stage_tuning_fields(self):
        source = read_text("car_app.c")

        self.assertIn("m2=%d/%d", source)
        self.assertIn("m3loop=%u", source)
        self.assertIn("m3ac=%d/%d/%d", source)
        self.assertIn("m3bd=%d/%d/%d", source)

    def test_oled_mode3_uses_selected_loop_count_not_remaining_loop_count(self):
        source = read_text("car_app.c")
        tick_body = source.split("void car_app_tick(void)", 1)[1]

        self.assertIn("oled_total_loops", tick_body)
        self.assertIn("g_app.mode3_loops", tick_body)
        self.assertNotIn("g_app.active_loops);", tick_body)


if __name__ == "__main__":
    unittest.main()
