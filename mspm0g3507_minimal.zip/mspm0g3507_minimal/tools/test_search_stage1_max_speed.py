import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


TOOLS_DIR = Path(__file__).resolve().parent
MODULE_PATH = TOOLS_DIR / "search_stage1_max_speed.py"
SPEC = importlib.util.spec_from_file_location("search_stage1_max_speed", MODULE_PATH)
search_stage1_max_speed = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = search_stage1_max_speed
SPEC.loader.exec_module(search_stage1_max_speed)


SAMPLE_LOG = """\
CARLOG,t_ms=0,profile=safe,mode=1,state=0,phase=2,seg=0/2,loop=1/1,last=A,leg=AB,ltype=ST,lline=0,llen=1000,lhd=0/0,lcnt=10/6600,hdg=0/0,line_ok=1,line=0x01,lraw=0xFE,lact=1,lmax=3/200,err=-600,spd=0/0,tar=0/0,pwm=0/0,rpy=0.0/0.0/0.0,gz=0.0,evt=0,hold_ms=0,sbias=20,orecap=0
CARLOG,t_ms=200,profile=safe,mode=1,state=1,phase=0,seg=0/2,loop=1/1,last=A,leg=AB,ltype=ST,lline=0,llen=1000,lhd=0/0,lcnt=1943/6600,hdg=0/0,line_ok=1,line=0x01,lraw=0xFE,lact=1,lmax=3/255,err=-600,spd=1200/1200,tar=801/799,pwm=600/600,rpy=0.5/17.4/170.8,gz=6.1,evt=0,hold_ms=0,sbias=20,orecap=19
CARLOG,t_ms=400,profile=safe,mode=1,state=1,phase=0,seg=0/2,loop=1/1,last=A,leg=AB,ltype=ST,lline=0,llen=1000,lhd=0/0,lcnt=2134/6600,hdg=0/-5,line_ok=1,line=0x01,lraw=0xFE,lact=1,lmax=3/243,err=-600,spd=800/800,tar=820/780,pwm=1841/1415,rpy=0.1/17.3/171.3,gz=7.6,evt=0,hold_ms=0,sbias=20,orecap=40
CARLOG,t_ms=600,profile=safe,mode=1,state=1,phase=0,seg=0/2,loop=1/1,last=A,leg=AB,ltype=ST,lline=0,llen=1000,lhd=0/0,lcnt=2329/6600,hdg=0/0,line_ok=1,line=0x01,lraw=0xFE,lact=1,lmax=3/255,err=-600,spd=800/800,tar=809/791,pwm=1425/1476,rpy=0.3/16.9/170.7,gz=0.3,evt=0,hold_ms=0,sbias=20,orecap=40
CARLOG,t_ms=800,profile=safe,mode=1,state=1,phase=0,seg=1/2,loop=1/1,last=B,leg=BC,ltype=ARC,lline=1,llen=1256,lhd=-900/900,lcnt=693/8200,hdg=-900/0,line_ok=1,line=0x01,lraw=0xFE,lact=1,lmax=3/255,err=-600,spd=200/1800,tar=248/1352,pwm=600/1400,rpy=-3.8/12.2/-158.3,gz=176.5,evt=1,hold_ms=0,sbias=20,orecap=0
CARLOG,t_ms=1000,profile=safe,mode=1,state=1,phase=0,seg=1/2,loop=1/1,last=B,leg=BC,ltype=ARC,lline=1,llen=1256,lhd=-900/900,lcnt=888/8200,hdg=-900/0,line_ok=1,line=0x21,lraw=0xDE,lact=2,lmax=3/196,err=-200,spd=600/1000,tar=626/974,pwm=1341/1933,rpy=-11.7/16.0/-128.3,gz=82.4,evt=1,hold_ms=0,sbias=20,orecap=0
CARLOG,t_ms=1200,profile=safe,mode=1,state=1,phase=0,seg=1/2,loop=1/1,last=B,leg=BC,ltype=ARC,lline=1,llen=1256,lhd=-900/900,lcnt=1074/8200,hdg=-900/0,line_ok=1,line=0x21,lraw=0xDE,lact=2,lmax=3/195,err=-200,spd=600/1000,tar=626/974,pwm=1377/2122,rpy=-10.5/17.0/-119.6,gz=13.6,evt=1,hold_ms=0,sbias=20,orecap=0
"""


class SearchStage1MaxSpeedTest(unittest.TestCase):
    def test_search_returns_serial_commands(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_path = Path(temp_dir) / "sample.log"
            log_path.write_text(SAMPLE_LOG, encoding="utf-8")

            rows = search_stage1_max_speed.model_stage1_log.load_rows(log_path)
            stats, pwm_fit, candidates = search_stage1_max_speed.search(rows)

            self.assertGreater(stats["ab_count"], 0)
            self.assertGreaterEqual(pwm_fit.samples, 1)
            self.assertGreaterEqual(len(candidates), 1)
            self.assertLessEqual(candidates[0].base, search_stage1_max_speed.WHEEL_SPEED_MAX_PPS)
            self.assertTrue(any(cmd.startswith("CFG,POSPID,") for cmd in candidates[0].command_lines()))


if __name__ == "__main__":
    unittest.main()
