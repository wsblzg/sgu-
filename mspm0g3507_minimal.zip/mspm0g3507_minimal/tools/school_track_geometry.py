import argparse
import math
from dataclasses import dataclass


FIELD_WIDTH_MM = 1800.0
FIELD_HEIGHT_MM = 800.0
ARC_RADIUS_MM = 400.0
HALF_STRAIGHT_MM = 500.0


@dataclass(frozen=True)
class Point:
    x_mm: float
    y_mm: float


@dataclass(frozen=True)
class Segment:
    name: str
    kind: str
    start: Point
    end: Point
    length_mm: float
    start_heading_deg: float
    end_heading_deg: float
    radius_mm: float
    line_tracked: bool


@dataclass(frozen=True)
class Route:
    name: str
    segments: tuple
    total_length_mm: float


@dataclass(frozen=True)
class Pose:
    s_mm: float
    x_mm: float
    y_mm: float
    heading_deg: float
    segment_name: str


POINTS = {
    "A": Point(-HALF_STRAIGHT_MM, ARC_RADIUS_MM),
    "B": Point(HALF_STRAIGHT_MM, ARC_RADIUS_MM),
    "C": Point(HALF_STRAIGHT_MM, -ARC_RADIUS_MM),
    "D": Point(-HALF_STRAIGHT_MM, -ARC_RADIUS_MM),
}

ARC_CENTERS = {
    "BC": Point(HALF_STRAIGHT_MM, 0.0),
    "CB": Point(HALF_STRAIGHT_MM, 0.0),
    "DA": Point(-HALF_STRAIGHT_MM, 0.0),
}

ROUTES = {
    "mode1": ("AB", "BC"),
    "mode2": ("AB", "BC", "CD", "DA"),
    "mode3": ("AC", "CB", "BD", "DA"),
}


def normalize_heading_deg(heading_deg: float):
    while heading_deg <= -180.0:
        heading_deg += 360.0
    while heading_deg > 180.0:
        heading_deg -= 360.0
    return heading_deg


def heading_between(start: Point, end: Point):
    return normalize_heading_deg(math.degrees(math.atan2(end.y_mm - start.y_mm, end.x_mm - start.x_mm)))


def build_straight(name: str, start_key: str, end_key: str):
    start = POINTS[start_key]
    end = POINTS[end_key]
    heading_deg = heading_between(start, end)
    return Segment(
        name=name,
        kind="STRAIGHT",
        start=start,
        end=end,
        length_mm=math.hypot(end.x_mm - start.x_mm, end.y_mm - start.y_mm),
        start_heading_deg=heading_deg,
        end_heading_deg=heading_deg,
        radius_mm=0.0,
        line_tracked=False,
    )


def build_arc(name: str, start_key: str, end_key: str, center: Point, direction_sign: float):
    start = POINTS[start_key]
    end = POINTS[end_key]
    start_angle = math.atan2(start.y_mm - center.y_mm, start.x_mm - center.x_mm)
    end_angle = math.atan2(end.y_mm - center.y_mm, end.x_mm - center.x_mm)
    delta_angle = end_angle - start_angle
    while delta_angle <= 0.0:
        delta_angle += 2.0 * math.pi
    while delta_angle > 2.0 * math.pi:
        delta_angle -= 2.0 * math.pi

    tangent_offset_deg = 90.0 * direction_sign
    return Segment(
        name=name,
        kind="ARC",
        start=start,
        end=end,
        length_mm=ARC_RADIUS_MM * delta_angle,
        start_heading_deg=normalize_heading_deg(math.degrees(start_angle) + tangent_offset_deg),
        end_heading_deg=normalize_heading_deg(math.degrees(end_angle) + tangent_offset_deg),
        radius_mm=ARC_RADIUS_MM,
        line_tracked=True,
    )


def build_segment(name: str):
    if name == "AB":
        return build_straight(name, "A", "B")
    if name == "BC":
        return build_arc(name, "B", "C", ARC_CENTERS["CB"], direction_sign=-1.0)
    if name == "CB":
        return build_arc(name, "C", "B", ARC_CENTERS["CB"], direction_sign=1.0)
    if name == "CD":
        return build_straight(name, "C", "D")
    if name == "DA":
        return build_arc(name, "D", "A", ARC_CENTERS["DA"], direction_sign=-1.0)
    if name == "AC":
        return build_straight(name, "A", "C")
    if name == "BD":
        return build_straight(name, "B", "D")
    raise ValueError(f"Unsupported segment {name}")


def build_route(route_name: str):
    segment_names = ROUTES[route_name]
    segments = tuple(build_segment(segment_name) for segment_name in segment_names)
    total_length_mm = sum(segment.length_mm for segment in segments)
    return Route(route_name, segments, total_length_mm)


def required_average_speed_mm_s(route: Route, time_limit_s: float):
    return route.total_length_mm / time_limit_s


def sample_segment(segment: Segment, s_mm: float):
    if segment.kind == "STRAIGHT":
        ratio = 0.0 if segment.length_mm == 0.0 else s_mm / segment.length_mm
        ratio = max(0.0, min(1.0, ratio))
        x_mm = segment.start.x_mm + (segment.end.x_mm - segment.start.x_mm) * ratio
        y_mm = segment.start.y_mm + (segment.end.y_mm - segment.start.y_mm) * ratio
        return x_mm, y_mm, segment.start_heading_deg

    center = ARC_CENTERS[segment.name]
    start_angle = math.atan2(segment.start.y_mm - center.y_mm, segment.start.x_mm - center.x_mm)
    direction_sign = 1.0 if segment.name == "CB" else -1.0
    angle = start_angle + direction_sign * (s_mm / ARC_RADIUS_MM)
    x_mm = center.x_mm + ARC_RADIUS_MM * math.cos(angle)
    y_mm = center.y_mm + ARC_RADIUS_MM * math.sin(angle)
    heading_deg = normalize_heading_deg(math.degrees(angle) + 90.0 * direction_sign)
    return x_mm, y_mm, heading_deg


def sample_route(route: Route, speed_mm_s: float, dt_s: float):
    poses = []
    s_total_mm = 0.0
    segment_index = 0
    segment_s_mm = 0.0
    segment = route.segments[0]

    while segment_index < len(route.segments):
        x_mm, y_mm, heading_deg = sample_segment(segment, segment_s_mm)
        poses.append(Pose(s_total_mm, x_mm, y_mm, heading_deg, segment.name))

        advance_mm = speed_mm_s * dt_s
        s_total_mm += advance_mm
        segment_s_mm += advance_mm

        while (segment_index < len(route.segments)) and (segment_s_mm >= segment.length_mm):
            segment_s_mm -= segment.length_mm
            segment_index += 1
            if segment_index < len(route.segments):
                segment = route.segments[segment_index]

    last_segment = route.segments[-1]
    poses.append(
        Pose(
            route.total_length_mm,
            last_segment.end.x_mm,
            last_segment.end.y_mm,
            last_segment.end_heading_deg,
            last_segment.name,
        )
    )
    return poses


def print_route_summary(route: Route, time_limit_s: float):
    print(f"route={route.name}")
    for segment in route.segments:
        print(
            f"  {segment.name}: kind={segment.kind} line={int(segment.line_tracked)} "
            f"len_mm={segment.length_mm:.3f} "
            f"head_deg={segment.start_heading_deg:.3f}->{segment.end_heading_deg:.3f}"
        )
    print(f"total_mm={route.total_length_mm:.3f}")
    print(f"avg_speed_mm_s@{time_limit_s:.1f}s={required_average_speed_mm_s(route, time_limit_s):.3f}")


def main():
    parser = argparse.ArgumentParser(description="Analyze school contest track geometry.")
    parser.add_argument("--route", choices=sorted(ROUTES.keys()), default="mode3")
    parser.add_argument("--time-limit", type=float, default=40.0)
    parser.add_argument("--sample-speed", type=float, default=250.0)
    parser.add_argument("--sample-dt", type=float, default=0.1)
    args = parser.parse_args()

    route = build_route(args.route)
    print(
        f"field_mm={FIELD_WIDTH_MM:.0f}x{FIELD_HEIGHT_MM:.0f} "
        f"radius_mm={ARC_RADIUS_MM:.0f} straight_mm={HALF_STRAIGHT_MM * 2.0:.0f}"
    )
    for name, point in POINTS.items():
        print(f"point_{name}=({point.x_mm:.1f},{point.y_mm:.1f})")
    print_route_summary(route, args.time_limit)
    poses = sample_route(route, args.sample_speed, args.sample_dt)
    print(f"samples={len(poses)}")
    print(
        f"sample_start=({poses[0].x_mm:.3f},{poses[0].y_mm:.3f},{poses[0].heading_deg:.3f}) "
        f"sample_end=({poses[-1].x_mm:.3f},{poses[-1].y_mm:.3f},{poses[-1].heading_deg:.3f})"
    )


if __name__ == "__main__":
    main()
