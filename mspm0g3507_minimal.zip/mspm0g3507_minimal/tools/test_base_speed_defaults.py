from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAR_APP = ROOT / "car_app.c"


def read_car_app() -> str:
    return CAR_APP.read_text(encoding="utf-8")


def test_heavy_gimbal_base_speed_macros_exist():
    text = read_car_app()
    assert "#define MODE1_BASE_SPEED_PPS 1450" in text
    assert "#define MODE2_BASE_SPEED_PPS 1450" in text
    assert "#define MODE3_BASE_SPEED_PPS 1200" in text
    assert "#define LINE_TRACK_BASE_SPEED_BOOST_PPS 600" in text
    assert "#define LINE_TURN_KP_NUM 56U" in text
    assert "#define LINE_TURN_KP_DEN 14U" in text
    assert "#define LINE_TURN_KD_NUM 10U" in text
    assert "#define LINE_TURN_KD_DEN 1U" in text
    assert "#define LINE_TURN_OUTPUT_LIMIT_PPS 3600" in text
    assert "#define HEAVY_GIMBAL_MIN_EFFECTIVE_PWM 1000" in text


def test_runtime_tuning_uses_heavy_gimbal_base_speed_macros():
    text = read_car_app()
    assert "app->tuning.base_speed_mode_1 = MODE1_BASE_SPEED_PPS;" in text
    assert "app->tuning.base_speed_mode_2 = MODE2_BASE_SPEED_PPS;" in text
    assert "app->tuning.base_speed_mode_3 = MODE3_BASE_SPEED_PPS;" in text
    assert "app->tuning.base_speed_mode_1 = 1280;" not in text
    assert "app->tuning.base_speed_mode_2 = 1280;" not in text


def test_line_tracked_legs_get_extra_base_speed_boost():
    text = read_car_app()
    assert "static int16_t car_app_leg_base_speed" in text
    assert "base_speed += LINE_TRACK_BASE_SPEED_BOOST_PPS;" in text
    assert "car_app_leg_base_speed(app, &leg)" in text


def test_line_turning_strength_is_raised_for_heavy_gimbal():
    text = read_car_app()
    assert "#define MODE1_ARC_FEEDFORWARD_PPS -2200" in text
    assert "#define ARC_ENTRY_STEER_LIMIT_PPS 3600" in text
    assert "#define ARC_ENTRY_TARGET_SLEW_PPS 600" in text
    assert "app->tuning.line_pid.kp_num = LINE_TURN_KP_NUM;" in text
    assert "app->tuning.line_pid.kp_den = LINE_TURN_KP_DEN;" in text
    assert "app->tuning.line_pid.kd_num = LINE_TURN_KD_NUM;" in text
    assert "app->tuning.line_pid.kd_den = LINE_TURN_KD_DEN;" in text
    assert "app->tuning.line_pid.output_limit = LINE_TURN_OUTPUT_LIMIT_PPS;" in text
    assert "app->tuning.mode1_arc_feedforward_pps = -120;" not in text
    assert "app->tuning.line_pid.output_limit = 650;" not in text
    assert "app->tuning.speed_min_effective_pwm = HEAVY_GIMBAL_MIN_EFFECTIVE_PWM;" in text


def test_line_tracking_does_not_reverse_inner_wheel():
    text = read_car_app()
    assert "min_target_pps = 0;" in text
    assert "LINE_TURN_OUTPUT_LIMIT_PPS, LINE_TURN_OUTPUT_LIMIT_PPS" in text
    assert "target_left_pps = clamp_i32(target_left_pps, min_target_pps, app->profile->wheel_speed_max_pps);" in text
    assert "target_right_pps = clamp_i32(target_right_pps, min_target_pps, app->profile->wheel_speed_max_pps);" in text
    assert "LINE_TRACK_REVERSE_LIMIT_PPS" not in text
    assert "LINE_TRACK_PIVOT_ERROR" not in text
    assert "LINE_TRACK_PIVOT_REVERSE_PPS" not in text
    assert "target_right_pps = -" not in text
    assert "target_left_pps = -" not in text
    assert "ARC_ENTRY_MIN_TARGET_PPS" not in text


if __name__ == "__main__":
    test_heavy_gimbal_base_speed_macros_exist()
    test_runtime_tuning_uses_heavy_gimbal_base_speed_macros()
    test_line_tracked_legs_get_extra_base_speed_boost()
    test_line_turning_strength_is_raised_for_heavy_gimbal()
    test_line_tracking_does_not_reverse_inner_wheel()
    print("base speed default static checks passed")
