from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


def read_text(name):
    return (ROOT / name).read_text(encoding="utf-8")


class OledModeDisplayTest(unittest.TestCase):
    def test_oled_header_exposes_mode_display_api(self):
        header = read_text("oled.h")

        self.assertIn("void oled_show_mode(", header)
        self.assertIn("void oled_show_task(", header)

    def test_car_app_tick_uses_mode_display_instead_of_yaw_display(self):
        source = read_text("car_app.c")
        tick_body = source.split("void car_app_tick(void)", 1)[1]

        self.assertIn("oled_show_task(", tick_body)
        self.assertIn("car_app_task_oled_label(&g_app)", tick_body)
        self.assertNotIn("oled_show_yaw(", tick_body)


if __name__ == "__main__":
    unittest.main()
