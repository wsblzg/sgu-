import math
from dataclasses import dataclass


APP_CONTROL_HZ = 200
PHASE_TRACK = 0
PHASE_HOLD = 1
PHASE_FINISHED = 2

LEG_ARC_MM = math.pi * 400.0
LEG_STRAIGHT_MM = 1000.0
LEG_DIAGONAL_MM = math.hypot(1000.0, 800.0)


@dataclass(frozen=True)
class Leg:
    name: str
    line_tracked: bool
    length_mm: float
    heading_deg_x10: int


LEGS = {
    "AB": Leg("AB", False, LEG_STRAIGHT_MM, 0),
    "BC": Leg("BC", True, LEG_ARC_MM, -900),
    "CB": Leg("CB", True, LEG_ARC_MM, 0),
    "CD": Leg("CD", False, LEG_STRAIGHT_MM, 1800),
    "DA": Leg("DA", True, LEG_ARC_MM, 1800),
    "AC": Leg("AC", False, LEG_DIAGONAL_MM, -387),
    "BD": Leg("BD", False, LEG_DIAGONAL_MM, -1413),
}

ROUTES = {
    1: ("AB", "BC"),
    2: ("AB", "BC", "CD", "DA"),
    3: ("AC", "CB", "BD", "DA"),
}


class SchoolTrackRouteController:
    def __init__(self, mode: int, loops: int):
        self.mode = mode
        self.target_loops = loops
        self.phase = PHASE_TRACK
        self.route_index = 0
        self.completed_loops = 0
        self.leg_progress_mm = 0.0
        self.hold_ticks_remaining = 0

    def current_leg(self):
        return LEGS[ROUTES[self.mode][self.route_index]]

    def current_leg_name(self):
        return self.current_leg().name

    def current_motion_mode(self):
        return "LINE" if self.current_leg().line_tracked else "HEADING"

    def current_heading_deg_x10(self):
        return self.current_leg().heading_deg_x10

    def _complete_current_leg(self):
        if self.mode == 1 and self.route_index == 0:
            self.route_index = 1
            self.phase = PHASE_HOLD
            self.hold_ticks_remaining = 3 * APP_CONTROL_HZ
            self.leg_progress_mm = 0.0
            return

        if self.route_index + 1 >= len(ROUTES[self.mode]):
            self.completed_loops += 1
            if self.completed_loops >= self.target_loops:
                self.phase = PHASE_FINISHED
                self.leg_progress_mm = 0.0
                return
            self.route_index = 0
            self.leg_progress_mm = 0.0
            return

        self.route_index += 1
        self.leg_progress_mm = 0.0

    def advance_distance_mm(self, distance_mm: float):
        if self.phase != PHASE_TRACK:
            return

        remaining = distance_mm
        while (remaining > 0.0) and (self.phase == PHASE_TRACK):
            leg = self.current_leg()
            budget = leg.length_mm - self.leg_progress_mm
            advance = budget if remaining >= budget else remaining
            self.leg_progress_mm += advance
            remaining -= advance

            if self.leg_progress_mm + 1e-6 >= leg.length_mm:
                self._complete_current_leg()

    def tick_hold(self, ticks: int):
        if self.phase != PHASE_HOLD:
            return

        self.hold_ticks_remaining -= ticks
        if self.hold_ticks_remaining <= 0:
            self.hold_ticks_remaining = 0
            self.phase = PHASE_TRACK
