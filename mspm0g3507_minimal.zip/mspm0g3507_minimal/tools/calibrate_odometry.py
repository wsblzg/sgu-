import argparse
from pathlib import Path

from parse_car_log import load_rows


def counts_per_mm_x100(counts: int, distance_mm: float):
    if distance_mm <= 0:
        raise ValueError("distance_mm must be > 0")
    return int(round((counts * 100.0) / distance_mm))


def calibrate_from_log(log_path: Path, leg_name: str, distance_mm: float):
    rows = load_rows(log_path)
    matched = [row for row in rows if row.get("leg") == leg_name]
    if not matched:
        raise ValueError(f"No rows found for leg {leg_name}")

    counts = max(row["leg_progress_count"] for row in matched)
    return {
        "leg": leg_name,
        "distance_mm": distance_mm,
        "counts": counts,
        "counts_per_mm_x100": counts_per_mm_x100(counts, distance_mm),
    }


def main():
    parser = argparse.ArgumentParser(description="Calibrate odometry counts/mm from CARLOG.")
    parser.add_argument("--distance-mm", type=float, required=True, help="Measured physical travel distance in mm")
    parser.add_argument("--counts", type=int, help="Measured encoder travel counts")
    parser.add_argument("--log", type=Path, help="CARLOG text file")
    parser.add_argument("--leg", default="AB", help="Leg name to extract from CARLOG when --log is used")
    args = parser.parse_args()

    if args.counts is None and args.log is None:
        raise SystemExit("Provide either --counts or --log")

    if args.log is not None:
        result = calibrate_from_log(args.log, args.leg, args.distance_mm)
        counts = result["counts"]
        counts_per_mm = result["counts_per_mm_x100"]
    else:
        counts = args.counts
        counts_per_mm = counts_per_mm_x100(counts, args.distance_mm)

    print(f"distance_mm={args.distance_mm:.3f}")
    print(f"counts={counts}")
    print(f"counts_per_mm_x100={counts_per_mm}")


if __name__ == "__main__":
    main()
