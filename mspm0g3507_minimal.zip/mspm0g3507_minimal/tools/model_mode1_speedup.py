"""
Model and simulate mode 1 speed-up tuning from CARLOG data.

The script reads a stage-1 log, removes stalled/collision samples, fits a
simple AB heading response model, then simulates candidate BASE/HPID settings.
It does not modify firmware files.
"""

from __future__ import annotations

import argparse
import math
import statistics
from dataclasses import dataclass
from pathlib import Path


CONTROL_DT_S = 0.2
BASE_CURRENT = 650
LINE_KP_CURRENT = 28 / 25
ARCFF_CURRENT = -120
HPID_CURRENT = (67, 21, 1, 401, 9, 20)
HDB_CURRENT = 2
HILIM_CURRENT = 600
HLIM_CURRENT = 500


@dataclass
class CarRow:
    t_ms: int
    state: int
    seg: int
    leg: str
    lcnt: int
    lcnt_target: int
    hdg_target: int
    hdg_error: int
    ryaw: int
    spd_l: int
    spd_r: int
    term_bal: int
    term_steer: int
    tar_l: int
    tar_r: int
    pwm_l: int
    pwm_r: int
    yaw: float
    gz: float


@dataclass
class FitResult:
    valid_rows: list[CarRow]
    lcnt_rate: float
    yaw_term_gain: float
    yaw_bias: float
    yaw_tau_s: float
    max_valid_pwm: int
    avg_speed_pps: float
    avg_yaw_error_x10: float


@dataclass
class Candidate:
    base: int
    hpid: tuple[int, int, int, int, int, int]
    hdb: int
    hilim: int
    hlim: int
    line_gain_num: int
    line_gain_den: int
    arcff: int
    straight_limit: int


class HeadingPid:
    def __init__(
        self,
        kp_num: int,
        kp_den: int,
        ki_num: int,
        ki_den: int,
        kd_num: int,
        kd_den: int,
        hdb: int,
        hilim: int,
        hlim: int,
    ) -> None:
        self.kp_num = kp_num
        self.kp_den = kp_den
        self.ki_num = ki_num
        self.ki_den = ki_den
        self.kd_num = kd_num
        self.kd_den = kd_den
        self.hdb = hdb
        self.hilim = hilim
        self.hlim = hlim
        self.integral = 0
        self.last_error = 0
        self.initialized = False

    def step(self, error_x10: int) -> int:
        error = 0 if abs(error_x10) <= self.hdb else error_x10
        if not self.initialized:
            self.last_error = error
            self.initialized = True
        if error == 0:
            self.integral = 0
        else:
            self.integral = clamp(self.integral + error, -self.hilim, self.hilim)
        derivative = error - self.last_error
        output = (
            error * self.kp_num / self.kp_den
            + self.integral * self.ki_num / self.ki_den
            + derivative * self.kd_num / self.kd_den
        )
        self.last_error = error
        return int(round(clamp(output, -self.hlim, self.hlim)))


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def parse_pair(value: str) -> tuple[int, int]:
    left, right = value.split("/", 1)
    return int(left, 0), int(right, 0)


def parse_rpy(value: str) -> tuple[float, float, float]:
    parts = value.split("/")
    return float(parts[0]), float(parts[1]), float(parts[2])


def parse_log(path: Path) -> list[CarRow]:
    rows: list[CarRow] = []
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        if not line.startswith("CARLOG"):
            continue
        fields: dict[str, str] = {}
        for part in line.split(",")[1:]:
            if "=" in part:
                key, value = part.split("=", 1)
                fields[key] = value
        try:
            seg, _ = parse_pair(fields["seg"])
            lcnt, lcnt_target = parse_pair(fields["lcnt"])
            hdg_target, hdg_error = parse_pair(fields["hdg"])
            spd_l, spd_r = parse_pair(fields["spd"])
            term_bal, term_steer = parse_pair(fields["term"])
            tar_l, tar_r = parse_pair(fields["tar"])
            pwm_l, pwm_r = parse_pair(fields["pwm"])
            _, _, yaw = parse_rpy(fields["rpy"])
            gz = float(fields.get("gz", "nan"))
            rows.append(
                CarRow(
                    t_ms=int(fields["t_ms"]),
                    state=int(fields["state"]),
                    seg=seg,
                    leg=fields.get("leg", ""),
                    lcnt=lcnt,
                    lcnt_target=lcnt_target,
                    hdg_target=hdg_target,
                    hdg_error=hdg_error,
                    ryaw=int(fields["ryaw"]),
                    spd_l=spd_l,
                    spd_r=spd_r,
                    term_bal=term_bal,
                    term_steer=term_steer,
                    tar_l=tar_l,
                    tar_r=tar_r,
                    pwm_l=pwm_l,
                    pwm_r=pwm_r,
                    yaw=yaw,
                    gz=gz,
                )
            )
        except (KeyError, ValueError):
            continue
    return rows


def unwrap_delta_deg(current: float, previous: float) -> float:
    delta = current - previous
    while delta > 180:
        delta -= 360
    while delta < -180:
        delta += 360
    return delta


def select_valid_ab_rows(rows: list[CarRow]) -> list[CarRow]:
    ab = [r for r in rows if r.state == 1 and r.seg == 0 and r.leg == "AB"]
    collision_t_ms: int | None = None
    for row in ab:
        avg_target = (row.tar_l + row.tar_r) / 2
        avg_speed = (row.spd_l + row.spd_r) / 2
        max_pwm = max(abs(row.pwm_l), abs(row.pwm_r))
        if (avg_target > 300) and (avg_speed < avg_target * 0.55) and (max_pwm >= 2500):
            collision_t_ms = row.t_ms
            break
    if collision_t_ms is not None:
        ab = [r for r in ab if r.t_ms < collision_t_ms]

    valid: list[CarRow] = []
    for row in ab:
        moving = (row.spd_l > 0) and (row.spd_r > 0)
        pwm_not_stalled = max(abs(row.pwm_l), abs(row.pwm_r)) < 2500
        if moving and pwm_not_stalled:
            valid.append(row)
    if len(valid) < 8:
        return ab
    return valid


def linfit(xs: list[float], ys: list[float]) -> tuple[float, float]:
    mx = statistics.mean(xs)
    my = statistics.mean(ys)
    den = sum((x - mx) ** 2 for x in xs)
    if den == 0:
        return 0.0, my
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den
    return slope, my - slope * mx


def fit_ab_model(rows: list[CarRow]) -> FitResult:
    valid = select_valid_ab_rows(rows)
    intervals = []
    for prev, cur in zip(valid, valid[1:]):
        dt = (cur.t_ms - prev.t_ms) / 1000
        if dt <= 0:
            continue
        lcnt_rate = (cur.lcnt - prev.lcnt) / dt
        yaw_rate = unwrap_delta_deg(cur.yaw, prev.yaw) / dt
        intervals.append((prev, lcnt_rate, yaw_rate))
    if not intervals:
        raise RuntimeError("not enough valid AB rows for fitting")

    good_rates = [rate for _, rate, _ in intervals if rate > 0]
    lcnt_rate = statistics.median(good_rates)
    xs = [item[0].term_steer for item in intervals]
    ys = [item[2] for item in intervals]
    yaw_term_gain, yaw_bias = linfit(xs, ys)
    avg_speed = statistics.mean((r.spd_l + r.spd_r) / 2 for r in valid)
    avg_yaw_error = statistics.mean(abs(r.hdg_error) for r in valid)
    max_pwm = max(max(abs(r.pwm_l), abs(r.pwm_r)) for r in valid)

    # Logs are 200 ms apart and the yaw response visibly settles in roughly
    # 2-3 samples after launch, so fit a conservative first-order yaw lag.
    yaw_tau_s = 0.35

    return FitResult(
        valid_rows=valid,
        lcnt_rate=lcnt_rate,
        yaw_term_gain=yaw_term_gain,
        yaw_bias=yaw_bias,
        yaw_tau_s=yaw_tau_s,
        max_valid_pwm=max_pwm,
        avg_speed_pps=avg_speed,
        avg_yaw_error_x10=avg_yaw_error,
    )


def make_candidate(base: int) -> Candidate:
    ratio = base / BASE_CURRENT
    root_ratio = math.sqrt(ratio)
    kp_num = int(round(HPID_CURRENT[0] * root_ratio))
    kd_num = int(round(HPID_CURRENT[4] * root_ratio))
    hlim = int(round(HLIM_CURRENT * ratio / 10) * 10)
    hilim = int(round(HILIM_CURRENT * ratio / 50) * 50)
    line_kp = LINE_KP_CURRENT * ratio
    line_gain_den = 25
    line_gain_num = int(round(line_kp * line_gain_den))
    arcff = int(round(ARCFF_CURRENT * ratio / 10) * 10)
    straight_limit = int(round(120 * ratio / 10) * 10)
    return Candidate(
        base=base,
        hpid=(kp_num, HPID_CURRENT[1], HPID_CURRENT[2], HPID_CURRENT[3], kd_num, HPID_CURRENT[5]),
        hdb=HDB_CURRENT,
        hilim=hilim,
        hlim=hlim,
        line_gain_num=line_gain_num,
        line_gain_den=line_gain_den,
        arcff=arcff,
        straight_limit=straight_limit,
    )


def simulate_ab(candidate: Candidate, fit: FitResult) -> dict[str, float]:
    pid = HeadingPid(*candidate.hpid, candidate.hdb, candidate.hilim, candidate.hlim)
    ratio = candidate.base / BASE_CURRENT
    lcnt_rate = fit.lcnt_rate * ratio
    lcnt = fit.valid_rows[0].lcnt
    yaw_x10 = fit.valid_rows[0].ryaw
    yaw_rate = 0.0
    max_abs_error = 0
    max_abs_term = 0
    sum_abs_error = 0
    samples = 0
    time_s = 0.0

    while lcnt < 6600 and time_s < 20.0:
        target_hdg = -30 if lcnt >= 5000 else 0
        error = target_hdg - int(round(yaw_x10))
        term = pid.step(error)
        desired_yaw_rate_deg_s = fit.yaw_term_gain * term + fit.yaw_bias
        alpha = CONTROL_DT_S / (fit.yaw_tau_s + CONTROL_DT_S)
        yaw_rate += alpha * (desired_yaw_rate_deg_s - yaw_rate)
        yaw_x10 += yaw_rate * CONTROL_DT_S * 10.0
        lcnt += lcnt_rate * CONTROL_DT_S
        time_s += CONTROL_DT_S
        max_abs_error = max(max_abs_error, abs(error))
        max_abs_term = max(max_abs_term, abs(term))
        sum_abs_error += abs(error)
        samples += 1

    return {
        "remaining_ab_time_s": time_s,
        "full_ab_time_s": 6600.0 / lcnt_rate,
        "max_abs_error_deg": max_abs_error / 10.0,
        "avg_abs_error_deg": (sum_abs_error / max(samples, 1)) / 10.0,
        "max_abs_heading_term": max_abs_term,
        "pred_lcnt_rate": lcnt_rate,
    }


def print_report(path: Path, fit: FitResult, candidates: list[Candidate]) -> None:
    valid = fit.valid_rows
    print(f"log={path}")
    print(f"valid_ab_rows={len(valid)}")
    print(f"valid_time_ms={valid[0].t_ms}-{valid[-1].t_ms}")
    print(f"valid_lcnt={valid[0].lcnt}-{valid[-1].lcnt}")
    print(f"fit_lcnt_rate_counts_s={fit.lcnt_rate:.1f}")
    print(f"fit_avg_speed_pps={fit.avg_speed_pps:.1f}")
    print(f"fit_avg_abs_heading_error_deg={fit.avg_yaw_error_x10 / 10.0:.3f}")
    print(f"fit_yaw_rate_deg_s={fit.yaw_term_gain:.5f}*heading_term+{fit.yaw_bias:.3f}")
    print(f"fit_max_valid_pwm={fit.max_valid_pwm}")
    print()

    print("candidates:")
    for cand in candidates:
        sim = simulate_ab(cand, fit)
        line_kp = cand.line_gain_num / cand.line_gain_den
        print(
            f"BASE={cand.base}: "
            f"AB_full={sim['full_ab_time_s']:.2f}s, "
            f"AB_remaining_from_log={sim['remaining_ab_time_s']:.2f}s, "
            f"max_err={sim['max_abs_error_deg']:.2f}deg, "
            f"avg_err={sim['avg_abs_error_deg']:.2f}deg, "
            f"max_hterm={sim['max_abs_heading_term']:.0f}, "
            f"HPID={cand.hpid[0]},{cand.hpid[1]},{cand.hpid[2]},{cand.hpid[3]},{cand.hpid[4]},{cand.hpid[5]}, "
            f"HILIM={cand.hilim}, HLIM={cand.hlim}, "
            f"LINE_KP={cand.line_gain_num}/{cand.line_gain_den}={line_kp:.3f}, "
            f"ARCFF={cand.arcff}, STRAIGHT_LIMIT={cand.straight_limit}"
        )
        print(
            "  serial: "
            f"PARAM,BASE,1,{cand.base} | "
            f"PARAM,HPID,{cand.hpid[0]},{cand.hpid[1]},{cand.hpid[2]},{cand.hpid[3]},{cand.hpid[4]},{cand.hpid[5]} | "
            f"PARAM,HDB,{cand.hdb} | PARAM,HILIM,{cand.hilim} | "
            f"PARAM,HLIM,{cand.hlim} | PARAM,ARCFF,{cand.arcff}"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "log",
        nargs="?",
        default=str(Path.home() / "Desktop" / "阶段1.txt"),
        help="Path to stage-1 CARLOG file.",
    )
    parser.add_argument("--bases", nargs="*", type=int, default=[650, 750, 800, 850])
    args = parser.parse_args()

    log_path = Path(args.log)
    rows = parse_log(log_path)
    fit = fit_ab_model(rows)
    candidates = [make_candidate(base) for base in args.bases]
    print_report(log_path, fit, candidates)


if __name__ == "__main__":
    main()
