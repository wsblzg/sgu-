import importlib.util
import tempfile
import unittest
from pathlib import Path


TOOLS_DIR = Path(__file__).resolve().parent
MODULE_PATH = TOOLS_DIR / "parse_car_log.py"
SPEC = importlib.util.spec_from_file_location("parse_car_log", MODULE_PATH)
parse_car_log = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(parse_car_log)


SAMPLE_LINE = (
    "CARLOG,t_ms=250,profile=safe,mode=1,k230=AIM,state=1,phase=0,seg=0/2,loop=1/1,"
    "last=A,leg=AB,ltype=ST,lline=0,llen=1000,lhd=0/0,lcnt=123/1000,hdg=0/-15,evt=0,hold_ms=0,line_ok=1,line=0x18,err=0,vok=1,vstat=LOCKED,verr=12/-7,spd=800/800,tar=820/820,"
    "pwm=2107/2107,yaw=0.0,gim_en=1,gim_us=1490/1510,gim_tar_us=1500/1500\n"
)


class ParseCarLogEncodingTest(unittest.TestCase):
    def test_load_rows_supports_utf8(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_path = Path(temp_dir) / "utf8.log"
            log_path.write_text(SAMPLE_LINE, encoding="utf-8")

            rows = parse_car_log.load_rows(log_path)

            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["profile"], "safe")
            self.assertEqual(rows[0]["k230_mode"], "AIM")
            self.assertEqual(rows[0]["leg"], "AB")
            self.assertEqual(rows[0]["leg_type"], "ST")
            self.assertEqual(rows[0]["leg_line_tracked"], 0)
            self.assertEqual(rows[0]["leg_length_mm"], 1000)
            self.assertEqual(rows[0]["leg_heading_start_deg_x10"], 0)
            self.assertEqual(rows[0]["leg_heading_end_deg_x10"], 0)
            self.assertEqual(rows[0]["leg_progress_count"], 123)
            self.assertEqual(rows[0]["leg_target_count"], 1000)
            self.assertEqual(rows[0]["heading_target_deg_x10"], 0)
            self.assertEqual(rows[0]["heading_error_deg_x10"], -15)
            self.assertEqual(rows[0]["vision_online"], 1)
            self.assertEqual(rows[0]["vision_status"], "LOCKED")
            self.assertEqual(rows[0]["vision_err_x"], 12)
            self.assertEqual(rows[0]["vision_err_y"], -7)
            self.assertEqual(rows[0]["line_mask"], "0x18")
            self.assertEqual(rows[0]["gimbal_enabled"], 1)
            self.assertEqual(rows[0]["gimbal_pan_us"], 1490)
            self.assertEqual(rows[0]["gimbal_tilt_us"], 1510)
            self.assertEqual(rows[0]["gimbal_pan_target_us"], 1500)
            self.assertEqual(rows[0]["gimbal_tilt_target_us"], 1500)

    def test_load_rows_supports_utf16le_bom(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_path = Path(temp_dir) / "utf16.log"
            log_path.write_text(SAMPLE_LINE, encoding="utf-16")

            rows = parse_car_log.load_rows(log_path)

            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["mode"], 1)
            self.assertEqual(rows[0]["yaw_deg"], 0.0)


if __name__ == "__main__":
    unittest.main()
