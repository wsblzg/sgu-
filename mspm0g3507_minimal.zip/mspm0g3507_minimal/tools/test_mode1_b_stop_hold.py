from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAR_APP = ROOT / "car_app.c"


def read_car_app() -> str:
    return CAR_APP.read_text(encoding="utf-8")


def mode1_reach_node_body() -> str:
    text = read_car_app()
    body = text.split("static void car_app_basic1_reach_node", 1)[1]
    return body.split("static void car_app_update_basic1_task_state", 1)[0]


def test_basic1_b_enters_stop_hold_only_for_mode1_b():
    body = mode1_reach_node_body()
    assert "CONTEST_TASK_BASIC_1" in body
    assert "CHASSIS_MODE_1" in body
    assert "node == ROUTE_NODE_B" in body
    assert "TASK_PHASE_STOP_HOLD" in body
    assert "mode1_stop_hold_ms" in body
    assert "hold_ticks_remaining" in body


def test_basic1_b_stop_hold_resets_motor_command():
    body = mode1_reach_node_body()
    assert "car_app_reset_motor_command(app)" in body


if __name__ == "__main__":
    test_basic1_b_enters_stop_hold_only_for_mode1_b()
    test_basic1_b_stop_hold_resets_motor_command()
    print("mode1 B stop-hold static checks passed")
