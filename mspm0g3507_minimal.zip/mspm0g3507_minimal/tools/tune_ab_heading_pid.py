#!/usr/bin/env python3
"""Tune A-B heading PID from logged ryaw and steering terms.

The script intentionally models only the open A-B heading-hold section.
Input data is the user's 50 ms CARLOG sequence before the old PREAIM branch.

Model:
    ryaw[k+1] = ryaw[k] + drift + response * steer[k]

Where:
    ryaw is in deg_x10
    steer is the POSPID output term in pps

The plant constants are fitted from the observed PID output and measured
ryaw deltas, then candidate POSPID values are simulated with the same
disturbance. This is not a full vehicle model; it is a local heading-hold
model for the A-B straight only.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import inf


DT_S = 0.05


@dataclass(frozen=True)
class Sample:
    t_ms: int
    ryaw_x10: int
    steer_pps: int


@dataclass(frozen=True)
class Pid:
    kp_num: int
    kp_den: int
    ki_num: int
    ki_den: int
    kd_num: int
    kd_den: int
    deadband: int
    ilim: int
    olim: int
    direction: int

    def command(self) -> str:
        return (
            "CFG,POSPID,"
            f"{self.kp_num},{self.kp_den},"
            f"{self.ki_num},{self.ki_den},"
            f"{self.kd_num},{self.kd_den},"
            f"{self.deadband},{self.ilim},{self.olim},{self.direction}"
        )

    @property
    def kp(self) -> float:
        return self.kp_num / self.kp_den

    @property
    def ki(self) -> float:
        return self.ki_num / self.ki_den

    @property
    def kd(self) -> float:
        return self.kd_num / self.kd_den


@dataclass(frozen=True)
class Fit:
    drift_x10_per_step: float
    response_x10_per_pps_step: float
    rmse_x10: float


@dataclass(frozen=True)
class Result:
    pid: Pid
    score: float
    max_abs_x10: float
    final_abs_x10: float
    itae: float
    rms_x10: float
    max_steer: int
    final_x10: float
    series: tuple[float, ...]


# Current old clean A-B samples before PREAIM was triggered.
# t=12750 and later are deliberately excluded because hdg became -35 there.
SAMPLES = (
    Sample(11450, 3, -10),
    Sample(11500, 4, -14),
    Sample(11550, 1, 0),
    Sample(11600, -3, 10),
    Sample(11650, -3, 10),
    Sample(11700, -13, 47),
    Sample(11750, -13, 47),
    Sample(11800, -15, 55),
    Sample(11850, -13, 48),
    Sample(11900, -13, 48),
    Sample(11950, -6, 22),
    Sample(12000, -14, 52),
    Sample(12050, -17, 63),
    Sample(12100, -17, 63),
    Sample(12150, -16, 59),
    Sample(12200, -13, 49),
    Sample(12250, -17, 63),
    Sample(12300, -17, 63),
    Sample(12350, -17, 63),
    Sample(12400, -17, 63),
    Sample(12450, -16, 59),
    Sample(12500, -16, 59),
    Sample(12550, -16, 59),
    Sample(12600, -17, 63),
    Sample(12650, -21, 78),
    Sample(12700, -17, 63),
)


CURRENT = Pid(76, 21, 1, 401, 10, 20, 2, 900, 760, 1)


class RuntimePid:
    def __init__(self, cfg: Pid) -> None:
        self.cfg = cfg
        self.integral = 0
        self.last_error = 0
        self.initialized = False

    def step(self, error: int) -> int:
        cfg = self.cfg
        if abs(error) <= cfg.deadband:
            error = 0
        if not self.initialized:
            self.last_error = error
            self.initialized = True
        if error == 0:
            self.integral = 0
        else:
            self.integral = max(-cfg.ilim, min(cfg.ilim, self.integral + error))
        derivative = error - self.last_error
        output = (
            error * cfg.kp_num // cfg.kp_den
            + self.integral * cfg.ki_num // cfg.ki_den
            + derivative * cfg.kd_num // cfg.kd_den
        )
        output = max(-cfg.olim, min(cfg.olim, output))
        output *= cfg.direction
        self.last_error = error
        return int(output)


def fit_plant(samples: tuple[Sample, ...]) -> Fit:
    xs = [s.steer_pps for s in samples[:-1]]
    ys = [samples[i + 1].ryaw_x10 - samples[i].ryaw_x10 for i in range(len(samples) - 1)]
    n = len(xs)
    sx = sum(xs)
    sy = sum(ys)
    sxx = sum(x * x for x in xs)
    sxy = sum(x * y for x, y in zip(xs, ys))
    denom = n * sxx - sx * sx
    response = (n * sxy - sx * sy) / denom if denom else 0.0
    drift = (sy - response * sx) / n
    err2 = 0.0
    for x, y in zip(xs, ys):
        pred = drift + response * x
        err2 += (pred - y) ** 2
    rmse = (err2 / n) ** 0.5
    return Fit(drift, response, rmse)


def simulate(pid: Pid, fit: Fit, start_x10: float, steps: int) -> Result:
    runtime = RuntimePid(pid)
    y = start_x10
    series = [y]
    steer_values: list[int] = []
    itae = 0.0
    for i in range(steps):
        error = int(round(-y))
        steer = runtime.step(error)
        steer_values.append(steer)
        y = y + fit.drift_x10_per_step + fit.response_x10_per_pps_step * steer
        series.append(y)
        itae += (i + 1) * DT_S * abs(y)
    max_abs = max(abs(v) for v in series)
    final_abs = abs(series[-1])
    rms = (sum(v * v for v in series) / len(series)) ** 0.5
    max_steer = max(abs(v) for v in steer_values) if steer_values else 0
    # Penalize residual error, large peaks, ITAE and excessive steering.
    score = final_abs * 5.0 + max_abs * 2.0 + rms * 1.5 + itae * 0.7 + max_steer * 0.015
    return Result(
        pid=pid,
        score=score,
        max_abs_x10=max_abs,
        final_abs_x10=final_abs,
        itae=itae,
        rms_x10=rms,
        max_steer=max_steer,
        final_x10=series[-1],
        series=tuple(series),
    )


def search(fit: Fit) -> list[Result]:
    start = SAMPLES[0].ryaw_x10
    steps = len(SAMPLES) - 1
    results: list[Result] = []
    for kp_num in range(60, 101):
        for kd_num in range(8, 25):
            for ilim in (900, 1200, 1500, 1800):
                for olim in (760, 850, 950, 1050):
                    pid = Pid(kp_num, 21, 1, 301, kd_num, 20, 1, ilim, olim, 1)
                    result = simulate(pid, fit, start, steps)
                    # Reject candidates that are too violent for straight holding.
                    if result.max_steer > 420:
                        continue
                    results.append(result)
    results.sort(key=lambda r: r.score)
    return results


def main() -> None:
    fit = fit_plant(SAMPLES)
    current = simulate(CURRENT, fit, SAMPLES[0].ryaw_x10, len(SAMPLES) - 1)
    results = search(fit)

    print("A-B heading fit from log:")
    print(f"  samples={len(SAMPLES)}, dt={DT_S:.3f}s")
    print(f"  plant: ryaw_next = ryaw + {fit.drift_x10_per_step:.3f} + {fit.response_x10_per_pps_step:.5f} * steer")
    print(f"  fit_rmse={fit.rmse_x10:.3f} deg_x10 ({fit.rmse_x10 / 10:.3f} deg)")
    print()
    print("Current POSPID simulation:")
    print(f"  {CURRENT.command()}")
    print(
        "  "
        f"final={current.final_x10 / 10:.3f}deg, "
        f"max_abs={current.max_abs_x10 / 10:.3f}deg, "
        f"rms={current.rms_x10 / 10:.3f}deg, "
        f"ITAE={current.itae / 10:.3f}, "
        f"max_steer={current.max_steer}pps"
    )
    print()
    print("Top candidates:")
    for idx, r in enumerate(results[:8], start=1):
        print(f"{idx}. {r.pid.command()}")
        print(
            "   "
            f"Kp={r.pid.kp:.3f}, Ki={r.pid.ki:.4f}, Kd={r.pid.kd:.3f}, "
            f"final={r.final_x10 / 10:.3f}deg, "
            f"max_abs={r.max_abs_x10 / 10:.3f}deg, "
            f"rms={r.rms_x10 / 10:.3f}deg, "
            f"ITAE={r.itae / 10:.3f}, "
            f"max_steer={r.max_steer}pps, score={r.score:.2f}"
        )


if __name__ == "__main__":
    main()
