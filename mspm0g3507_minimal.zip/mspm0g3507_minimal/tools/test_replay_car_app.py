import importlib.util
import unittest
from pathlib import Path


TOOLS_DIR = Path(__file__).resolve().parent
MODULE_PATH = TOOLS_DIR / "replay_car_app.py"
SPEC = importlib.util.spec_from_file_location("replay_car_app", MODULE_PATH)
replay_car_app = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(replay_car_app)


def build_app():
    profiles = replay_car_app.parse_profiles(TOOLS_DIR.parent / "car_app_profiles.def")
    return replay_car_app.CarAppReplay(profiles["safe"])


class ReplayK230ModeTest(unittest.TestCase):
    def test_idle_outputs_stop_mode(self):
        app = build_app()
        self.assertEqual(app.get_k230_mode(), "STOP")

    def test_basic_mode1_outputs_stop(self):
        app = build_app()
        app.step(
            {
                "button_mask": replay_car_app.BUTTON_BITS["start"],
                "line_online": True,
                "line_mask": 0x18,
                "left_delta": 4,
                "right_delta": 4,
                "left_total": 4,
                "right_total": 4,
                "yaw_deg": 0.0,
            }
        )
        self.assertEqual(app.get_k230_mode(), "STOP")

    def test_basic_mode2_outputs_stop(self):
        app = build_app()
        app.step(
            {
                "button_mask": replay_car_app.BUTTON_BITS["mode2"],
                "line_online": True,
                "line_mask": 0x18,
                "left_delta": 0,
                "right_delta": 0,
                "left_total": 0,
                "right_total": 0,
                "yaw_deg": 0.0,
            }
        )
        app.step(
            {
                "button_mask": replay_car_app.BUTTON_BITS["start"],
                "line_online": True,
                "line_mask": 0x18,
                "left_delta": 4,
                "right_delta": 4,
                "left_total": 4,
                "right_total": 4,
                "yaw_deg": 0.0,
            }
        )
        self.assertEqual(app.get_k230_mode(), "STOP")

    def test_basic_mode3_outputs_stop(self):
        app = build_app()
        app.step(
            {
                "button_mask": replay_car_app.BUTTON_BITS["mode3"],
                "line_online": False,
                "line_mask": 0x00,
                "left_delta": 0,
                "right_delta": 0,
                "left_total": 0,
                "right_total": 0,
                "yaw_deg": 0.0,
            }
        )
        app.step(
            {
                "button_mask": replay_car_app.BUTTON_BITS["start"],
                "line_online": True,
                "line_mask": 0x18,
                "left_delta": 4,
                "right_delta": 4,
                "left_total": 4,
                "right_total": 4,
                "yaw_deg": 0.0,
            }
        )
        self.assertEqual(app.get_k230_mode(), "STOP")

    def test_mode1_second_press_selects_ecg_task(self):
        app = build_app()
        for button in ("mode1", "mode1", "start"):
            app.step(
                {
                    "button_mask": replay_car_app.BUTTON_BITS[button],
                    "line_online": True,
                    "line_mask": 0x18,
                    "left_delta": 0,
                    "right_delta": 0,
                    "left_total": 0,
                    "right_total": 0,
                    "yaw_deg": 0.0,
                }
            )
            app.step(
                {
                    "button_mask": 0,
                    "line_online": True,
                    "line_mask": 0x18,
                    "left_delta": 0,
                    "right_delta": 0,
                    "left_total": 0,
                    "right_total": 0,
                    "yaw_deg": 0.0,
                }
            )
        self.assertEqual(app.get_k230_mode(), "ECG")

    def test_mode2_second_press_selects_aim_task(self):
        app = build_app()
        for button in ("mode2", "mode2", "start"):
            app.step(
                {
                    "button_mask": replay_car_app.BUTTON_BITS[button],
                    "line_online": True,
                    "line_mask": 0x18,
                    "left_delta": 0,
                    "right_delta": 0,
                    "left_total": 0,
                    "right_total": 0,
                    "yaw_deg": 0.0,
                }
            )
            app.step(
                {
                    "button_mask": 0,
                    "line_online": True,
                    "line_mask": 0x18,
                    "left_delta": 0,
                    "right_delta": 0,
                    "left_total": 0,
                    "right_total": 0,
                    "yaw_deg": 0.0,
                }
            )
        self.assertEqual(app.get_k230_mode(), "AIM")

    def test_mode3_fourth_press_selects_aim_task(self):
        app = build_app()
        for button in ("mode3", "mode3", "mode3", "mode3", "start"):
            app.step(
                {
                    "button_mask": replay_car_app.BUTTON_BITS[button],
                    "line_online": True,
                    "line_mask": 0x18,
                    "left_delta": 0,
                    "right_delta": 0,
                    "left_total": 0,
                    "right_total": 0,
                    "yaw_deg": 0.0,
                }
            )
            app.step(
                {
                    "button_mask": 0,
                    "line_online": True,
                    "line_mask": 0x18,
                    "left_delta": 0,
                    "right_delta": 0,
                    "left_total": 0,
                    "right_total": 0,
                    "yaw_deg": 0.0,
                }
            )
        self.assertEqual(app.get_k230_mode(), "AIM")


if __name__ == "__main__":
    unittest.main()
