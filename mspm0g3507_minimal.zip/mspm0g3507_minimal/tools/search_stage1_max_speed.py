"""
Search stage-1 maximum practical BASE speed and matched PID values.

The search is derived from actual CARLOG data. It does not modify firmware.
It uses the parsed log to estimate:
- PWM required for target wheel speed.
- Heading PID scaling needed as speed rises.
- Line PID scaling needed as speed rises.

The result is a ranked list of serial CFG commands.
"""

from __future__ import annotations

import argparse
import importlib.util
import math
import statistics
import sys
from dataclasses import dataclass
from pathlib import Path


TOOLS_DIR = Path(__file__).resolve().parent
MODEL_PATH = TOOLS_DIR / "model_stage1_log.py"
SPEC = importlib.util.spec_from_file_location("model_stage1_log", MODEL_PATH)
model_stage1_log = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = model_stage1_log
SPEC.loader.exec_module(model_stage1_log)


WHEEL_SPEED_MAX_PPS = 1800
CFG_SPEED_OUTPUT_LIMIT_MAX = 3000
MOTOR_PWM_LIMIT = 4000
CURRENT_BASE = 800
CURRENT_POSPID = (67, 21, 1, 401, 9, 20, 2, 600, 500, 1)
CURRENT_LINEPID = (28, 25, 0, 100, 3, 1, 0, 0, 1800, 1)
CURRENT_SPDPID = (9, 8, 2, 8, 0, 1, 0, 3200, 3000, 2, 600)
CURRENT_ARCFF = -120
CURRENT_SBIAS = 20
CURRENT_PREAIM = (5000, -30)


@dataclass(frozen=True)
class WheelFit:
    pwm_per_pps: float
    pwm_offset: float
    r2: float
    samples: int

    def pwm_for_speed(self, pps: float) -> float:
        return self.pwm_offset + self.pwm_per_pps * pps


@dataclass(frozen=True)
class Candidate:
    base: int
    pospid: tuple[int, int, int, int, int, int, int, int, int, int]
    linepid: tuple[int, int, int, int, int, int, int, int, int, int]
    spdpid: tuple[int, int, int, int, int, int, int, int, int, int, int]
    arcff: int
    sbias: int
    preaim: tuple[int, int]
    predicted_pwm: float
    predicted_ab_time_s: float
    heading_margin: float
    line_margin: float
    score: float

    def command_lines(self) -> list[str]:
        pos = ",".join(str(v) for v in self.pospid)
        line = ",".join(str(v) for v in self.linepid)
        spd = ",".join(str(v) for v in self.spdpid)
        return [
            f"CFG,BASE,{self.base}",
            "CFG,ANGLE,0",
            f"CFG,POSPID,{pos}",
            f"CFG,LINEPID,{line}",
            f"CFG,SPDPID,{spd}",
            f"PARAM,ARCFF,{self.arcff}",
            f"PARAM,SBIAS,{self.sbias}",
            f"PARAM,PREAIM,{self.preaim[0]},{self.preaim[1]}",
        ]


def linfit(xs: list[float], ys: list[float]) -> tuple[float, float, float]:
    if len(xs) < 2:
        return 0.0, 0.0, 0.0
    mx = statistics.mean(xs)
    my = statistics.mean(ys)
    den = sum((x - mx) ** 2 for x in xs)
    if abs(den) < 1e-12:
        return 0.0, my, 0.0
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den
    intercept = my - slope * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    if abs(ss_tot) < 1e-12:
        r2 = 1.0
    else:
        ss_res = sum((y - (intercept + slope * x)) ** 2 for x, y in zip(xs, ys))
        r2 = 1.0 - ss_res / ss_tot
    return slope, intercept, r2


def fit_pwm_for_speed(rows: list[model_stage1_log.Row]) -> WheelFit:
    xs: list[float] = []
    ys: list[float] = []
    for row in model_stage1_log.select_valid_rows(rows):
        for target, speed, pwm in (
            (row.tar_l, row.speed_l, row.pwm_l),
            (row.tar_r, row.speed_r, row.pwm_r),
        ):
            if target < 500:
                continue
            if speed < 300:
                continue
            if abs(pwm) < 600 or abs(pwm) > 3900:
                continue
            xs.append(float(speed))
            ys.append(float(abs(pwm)))
    slope, intercept, r2 = linfit(xs, ys)
    if slope <= 0 or r2 < 0.05:
        # Conservative fallback from observed stage-1 AB samples.
        slope = 1.45
        intercept = 520.0
        r2 = max(r2, 0.05)
    return WheelFit(slope, intercept, r2, len(xs))


def estimate_peak_terms(rows: list[model_stage1_log.Row]) -> tuple[float, float]:
    ab_rows = model_stage1_log.select_ab_rows(rows)
    bc_rows = model_stage1_log.select_bc_rows(rows)
    heading_peak = max((abs(row.term_steer) for row in ab_rows), default=1)
    line_peak = max((abs(row.term_steer) for row in bc_rows), default=1)
    return float(heading_peak), float(line_peak)


def scale_pospid(base: int, scale_factor: float, hlim_scale: float) -> tuple[int, int, int, int, int, int, int, int, int, int]:
    speed_scale = base / CURRENT_BASE
    kp = round(CURRENT_POSPID[0] * math.sqrt(speed_scale) * scale_factor)
    kd = round(CURRENT_POSPID[4] * math.sqrt(speed_scale) * min(scale_factor, 1.25))
    ilim = round(CURRENT_POSPID[7] * speed_scale / 50) * 50
    hlim = round(CURRENT_POSPID[8] * speed_scale * hlim_scale / 50) * 50
    return (
        int(max(1, min(100, kp))),
        CURRENT_POSPID[1],
        CURRENT_POSPID[2],
        CURRENT_POSPID[3],
        int(max(0, min(100, kd))),
        CURRENT_POSPID[5],
        CURRENT_POSPID[6],
        int(max(0, min(20000, ilim))),
        int(max(0, min(1000, hlim))),
        CURRENT_POSPID[9],
    )


def scale_linepid(base: int, scale_factor: float) -> tuple[int, int, int, int, int, int, int, int, int, int]:
    speed_scale = base / CURRENT_BASE
    kp = round(CURRENT_LINEPID[0] * speed_scale * scale_factor)
    kd = round(CURRENT_LINEPID[4] * math.sqrt(speed_scale) * min(scale_factor, 1.3))
    return (
        int(max(1, min(100, kp))),
        CURRENT_LINEPID[1],
        CURRENT_LINEPID[2],
        CURRENT_LINEPID[3],
        int(max(0, min(100, kd))),
        CURRENT_LINEPID[5],
        CURRENT_LINEPID[6],
        CURRENT_LINEPID[7],
        CURRENT_LINEPID[8],
        CURRENT_LINEPID[9],
    )


def scale_spdpid(base: int, kp_scale: float, ki_scale: float) -> tuple[int, int, int, int, int, int, int, int, int, int, int]:
    speed_scale = base / CURRENT_BASE
    kp = round(CURRENT_SPDPID[0] * kp_scale * math.sqrt(speed_scale))
    ki = round(CURRENT_SPDPID[2] * ki_scale * math.sqrt(speed_scale))
    ilim = round(CURRENT_SPDPID[7] * speed_scale / 100) * 100
    return (
        int(max(1, min(100, kp))),
        CURRENT_SPDPID[1],
        int(max(0, min(100, ki))),
        CURRENT_SPDPID[3],
        CURRENT_SPDPID[4],
        CURRENT_SPDPID[5],
        CURRENT_SPDPID[6],
        int(max(0, min(20000, ilim))),
        CFG_SPEED_OUTPUT_LIMIT_MAX,
        CURRENT_SPDPID[9],
        CURRENT_SPDPID[10],
    )


def evaluate_candidate(
    base: int,
    pospid: tuple[int, int, int, int, int, int, int, int, int, int],
    linepid: tuple[int, int, int, int, int, int, int, int, int, int],
    spdpid: tuple[int, int, int, int, int, int, int, int, int, int, int],
    fit: WheelFit,
    stats: dict[str, float],
    heading_peak: float,
    line_peak: float,
) -> Candidate | None:
    speed_scale = base / CURRENT_BASE
    predicted_pwm = fit.pwm_for_speed(base)
    if predicted_pwm > CFG_SPEED_OUTPUT_LIMIT_MAX * 0.94:
        return None
    if predicted_pwm > MOTOR_PWM_LIMIT * 0.80:
        return None

    # Target composition must leave room for turn terms after BASE.
    if base > WHEEL_SPEED_MAX_PPS - 300:
        return None

    pos_kp_scale = (pospid[0] / pospid[1]) / (CURRENT_POSPID[0] / CURRENT_POSPID[1])
    line_kp_scale = (linepid[0] / linepid[1]) / (CURRENT_LINEPID[0] / CURRENT_LINEPID[1])
    hlim = pospid[8]
    line_olim = linepid[8]

    predicted_heading_peak = heading_peak * speed_scale * pos_kp_scale
    predicted_line_peak = line_peak * speed_scale * line_kp_scale
    heading_margin = hlim - predicted_heading_peak
    line_margin = line_olim - predicted_line_peak
    if heading_margin < 80:
        return None
    if line_margin < 120:
        return None

    lcnt_rate = stats["ab_lcnt_rate"] * speed_scale
    predicted_ab_time_s = 6600.0 / max(lcnt_rate, 1.0)

    arcff = int(round(CURRENT_ARCFF * speed_scale / 10) * 10)
    arcff = int(max(-500, min(500, arcff)))
    sbias = int(round(CURRENT_SBIAS * min(1.35, math.sqrt(speed_scale))))
    preaim_start = int(round(CURRENT_PREAIM[0] / min(1.2, math.sqrt(speed_scale)) / 100) * 100)
    preaim_heading = int(round(CURRENT_PREAIM[1] * min(1.25, math.sqrt(speed_scale)) / 5) * 5)

    # Higher base is better, but large saturation risk is penalized.
    pwm_margin = CFG_SPEED_OUTPUT_LIMIT_MAX - predicted_pwm
    score = base + 0.03 * pwm_margin + 0.01 * min(heading_margin, line_margin)
    return Candidate(
        base=base,
        pospid=pospid,
        linepid=linepid,
        spdpid=spdpid,
        arcff=arcff,
        sbias=sbias,
        preaim=(preaim_start, preaim_heading),
        predicted_pwm=predicted_pwm,
        predicted_ab_time_s=predicted_ab_time_s,
        heading_margin=heading_margin,
        line_margin=line_margin,
        score=score,
    )


def search(rows: list[model_stage1_log.Row]) -> tuple[dict[str, float], WheelFit, list[Candidate]]:
    stats = model_stage1_log.estimate_speed_model(rows)
    pwm_fit = fit_pwm_for_speed(rows)
    heading_peak, line_peak = estimate_peak_terms(rows)
    candidates: list[Candidate] = []

    for base in range(800, 1801, 20):
        for pos_scale in (0.9, 1.0, 1.1, 1.2, 1.35):
            for hlim_scale in (1.0, 1.1, 1.2):
                pospid = scale_pospid(base, pos_scale, hlim_scale)
                for line_scale in (0.85, 1.0, 1.15, 1.3):
                    linepid = scale_linepid(base, line_scale)
                    for spd_kp_scale, spd_ki_scale in ((1.0, 1.0), (1.15, 1.0), (1.25, 0.9)):
                        spdpid = scale_spdpid(base, spd_kp_scale, spd_ki_scale)
                        cand = evaluate_candidate(
                            base,
                            pospid,
                            linepid,
                            spdpid,
                            pwm_fit,
                            stats,
                            heading_peak,
                            line_peak,
                        )
                        if cand is not None:
                            candidates.append(cand)

    candidates.sort(key=lambda item: (item.base, item.score), reverse=True)
    return stats, pwm_fit, candidates


def print_report(log_path: Path, stats: dict[str, float], pwm_fit: WheelFit, candidates: list[Candidate], limit: int) -> None:
    print(f"log={log_path}")
    print(
        f"source: ab_rows={int(stats['ab_count'])}, bc_rows={int(stats['bc_count'])}, "
        f"ab_rate={stats['ab_lcnt_rate']:.1f} cnt/s, current_avg_target={stats['avg_target']:.1f}"
    )
    print(
        f"pwm_fit: pwm ~= {pwm_fit.pwm_offset:.1f} + {pwm_fit.pwm_per_pps:.3f}*pps, "
        f"r2={pwm_fit.r2:.3f}, samples={pwm_fit.samples}"
    )
    print(
        "limits: wheel_target<=1800, CFG_SPDPID output_limit<=3000, recommended_pwm<=2820, base<=1500"
    )
    print()
    if not candidates:
        print("no candidate passed constraints")
        return
    best = candidates[0]
    print(
        f"best_base={best.base}, predicted_pwm={best.predicted_pwm:.0f}, "
        f"predicted_ab_time={best.predicted_ab_time_s:.2f}s, "
        f"heading_margin={best.heading_margin:.0f}, line_margin={best.line_margin:.0f}"
    )
    print()
    print("top candidates:")
    for idx, cand in enumerate(candidates[:limit], start=1):
        print(
            f"[{idx}] BASE={cand.base}, pwm={cand.predicted_pwm:.0f}, "
            f"AB={cand.predicted_ab_time_s:.2f}s, "
            f"h_margin={cand.heading_margin:.0f}, l_margin={cand.line_margin:.0f}"
        )
        for command in cand.command_lines():
            print(f"    {command}")
        print()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "log",
        nargs="?",
        default=str(Path.home() / "Desktop" / "阶段1.txt"),
        help="Path to a CARLOG stage file.",
    )
    parser.add_argument("--limit", type=int, default=8)
    args = parser.parse_args()

    log_path = Path(args.log)
    rows = model_stage1_log.load_rows(log_path)
    if not rows:
        raise SystemExit("no CARLOG rows found")
    stats, pwm_fit, candidates = search(rows)
    print_report(log_path, stats, pwm_fit, candidates, args.limit)


if __name__ == "__main__":
    main()
