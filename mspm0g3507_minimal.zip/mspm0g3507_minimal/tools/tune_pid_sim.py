"""
MSPM0G3507 智能车 PID 调参仿真模型

基于 car_app.c 的实际 PID 算法建模:
- speed_pid_step()  — 速度环 (PI + 前馈)
- heading_pid_step() — 航向环 (PID)
- car_app_update_motion() — 运动合成

输入: PKG 文件中的参数值
输出: 建模仿真得出的推荐 PID 参数
"""

import math
import sys
import os

# ========== 从日志数据提取的系统参数 ==========

# 编码器速度测量: 从日志看 speed_pps 范围 0~800
# PWM 输出范围: 从日志看 pwm 范围 600~4418 (MOTOR_PWM_LIMIT=4000)
# 编码器 counts -> pwm 的关系: 从日志数据拟合
# speed_pid_step 公式:
#   output = feedforward + (kp*error + ki*integral) / scale
#   其中 feedforward = target_pps * feedforward_num

# ========== 现有 profile 参数 (car_app_profiles.def) ==========

PROFILES = {
    "safe": {
        "mode_speeds": [820, 1000, 900],  # mode1/2/3
        "feedforward_num": 2,
        "turn_gain_num": 9, "turn_gain_den": 2,
        "straight_gain_num": 1, "straight_gain_den": 4,
        "straight_limit": 180,
        "speed_kp": 2, "speed_ki": 8, "speed_scale": 10,
        "speed_integral_limit": 3200,
        "wheel_speed_max": 1800,
        "line_lost_pwm": 900,
        "min_effective_pwm": 600,
        "odom_counts_per_mm_x100": 580,
        "heading_gain_num": 8, "heading_gain_den": 10,
        "heading_term_limit": 260,
    },
    "race": {
        "mode_speeds": [920, 1120, 1000],
        "feedforward_num": 2,
        "turn_gain_num": 10, "turn_gain_den": 2,
        "straight_gain_num": 1, "straight_gain_den": 4,
        "straight_limit": 220,
        "speed_kp": 2, "speed_ki": 8, "speed_scale": 10,
        "speed_integral_limit": 3600,
        "wheel_speed_max": 1800,
        "line_lost_pwm": 950,
        "min_effective_pwm": 650,
        "odom_counts_per_mm_x100": 580,
        "heading_gain_num": 10, "heading_gain_den": 10,
        "heading_term_limit": 320,
    }
}

# 从日志观察到的物理特性
# PWM 到速度的响应 (开环)
# 从日志 t=40000: tar=680/760, pwm=2126/2500, spd=600/600
#   左轮: pwm=2126 -> spd=600, 右轮: pwm=2500 -> spd=600
# 从日志 t=42000: tar=581/859, pwm=2615/3484, spd=0/0
#   (pwm 饱和但速度为 0, 可能打滑或堵转)
# 从日志 t=88000: tar=688/752, pwm=1253/1802, spd=800/800
#   左轮: pwm=1253 -> spd=800, 右轮: pwm=1802 -> spd=800

# 建模: 在非饱和区, speed ≈ (pwm - deadzone) * gain
# 从多个数据点拟合:
#   左轮: 1253->800, 2126->600, 1685->800
#   右轮: 1802->800, 2500->600, 1905->800
# 存在明显滞后和死区, 简化使用一阶模型

MOTOR_DEADZONE = 600   # min_effective_pwm
MOTOR_GAIN = 0.6       # pps per pwm (above deadzone)
MOTOR_TIME_CONSTANT = 0.05  # 50ms 时间常数 (200Hz 控制周期的 10 ticks)
CONTROL_HZ = 200
DT = 1.0 / CONTROL_HZ


class MotorModel:
    """简化电机模型: 一阶滞后 + 死区 + 限幅"""

    def __init__(self, deadzone=600, gain=0.6, max_speed=1800, tau=0.05):
        self.deadzone = deadzone
        self.gain = gain
        self.max_speed = max_speed
        self.alpha = 1.0 - math.exp(-DT / tau)  # 一阶低通系数
        self.speed = 0.0

    def step(self, pwm):
        """输入 PWM, 输出速度 pps"""
        # 死区处理
        if abs(pwm) < self.deadzone:
            effective = 0
        else:
            sign = 1 if pwm > 0 else -1
            effective = sign * (abs(pwm) - self.deadzone) * self.gain

        # 限幅
        effective = max(-self.max_speed, min(self.max_speed, effective))

        # 一阶低通 (模拟机械惯性)
        self.speed += self.alpha * (effective - self.speed)

        return self.speed

    def reset(self):
        self.speed = 0.0


class SpeedPID:
    """模拟 car_app.c 的 speed_pid_step"""

    def __init__(self, kp, ki, scale, integral_limit, feedforward_num):
        self.kp = kp
        self.ki = ki
        self.scale = scale
        self.integral_limit = integral_limit
        self.feedforward_num = feedforward_num
        self.integral = 0.0
        self.last_error = 0

    def step(self, target_pps, measured_pps, min_effective_pwm, wheel_speed_max):
        error = target_pps - measured_pps

        self.integral += error
        self.integral = max(-self.integral_limit, min(self.integral_limit, self.integral))

        feedforward = target_pps * self.feedforward_num
        output = feedforward + (self.kp * error + self.ki * self.integral) / self.scale
        output = max(-wheel_speed_max * 4, min(wheel_speed_max * 4, output))

        # 如果目标速度为 0 且实测速度很小, 复位
        if target_pps == 0 and abs(measured_pps) < 50:
            self.reset()
            return 0

        # 最小有效 PWM
        if output != 0 and abs(output) < min_effective_pwm:
            output = min_effective_pwm if output > 0 else -min_effective_pwm

        self.last_error = error
        return output

    def reset(self):
        self.integral = 0.0
        self.last_error = 0


class HeadingPID:
    """模拟 car_app.c 的 heading_pid_step"""

    def __init__(self, kp_num, kp_den, ki_num, ki_den, kd_num, kd_den,
                 deadband_x10=8, integral_limit=600, output_limit=260):
        self.kp = kp_num / kp_den if kp_den != 0 else 0
        self.ki = ki_num / ki_den if ki_den != 0 else 0
        self.kd = kd_num / kd_den if kd_den != 0 else 0
        self.deadband = deadband_x10
        self.integral_limit = integral_limit
        self.output_limit = output_limit
        self.integral = 0.0
        self.last_error = 0
        self.initialized = False

    def step(self, error_deg_x10):
        error = error_deg_x10

        # 死区
        if abs(error) <= self.deadband:
            error = 0

        if not self.initialized:
            self.last_error = error
            self.initialized = True

        # 积分
        if error == 0:
            self.integral = 0
        else:
            self.integral += error
            self.integral = max(-self.integral_limit,
                                min(self.integral_limit, self.integral))

        # 微分
        derivative = error - self.last_error

        # PID 输出
        output = (self.kp * error +
                  self.ki * self.integral +
                  self.kd * derivative)
        output = max(-self.output_limit, min(self.output_limit, output))

        self.last_error = error
        return output

    def reset(self):
        self.integral = 0.0
        self.last_error = 0
        self.initialized = False


def simulate_speed_pid(kp, ki, profile="safe"):
    """仿真速度环阶跃响应"""
    p = PROFILES[profile]
    pid = SpeedPID(kp, ki, p["speed_scale"], p["speed_integral_limit"],
                   p["feedforward_num"])
    motor = MotorModel(deadzone=p["min_effective_pwm"], max_speed=p["wheel_speed_max"])

    target = p["mode_speeds"][0]  # mode1 speed
    steps = 400  # 2 seconds

    speeds = []
    pwms = []

    for i in range(steps):
        measured = motor.speed
        pwm_out = pid.step(target, measured, p["min_effective_pwm"], p["wheel_speed_max"])
        pwm_out = max(-4000, min(4000, pwm_out))
        motor.step(pwm_out)
        speeds.append(motor.speed)
        pwms.append(pwm_out)

    # 评估指标
    result_target = target  # capture target from outer scope

    if len(speeds) < 50:
        return None

    steady = speeds[-50:]
    avg_speed = sum(steady) / len(steady)
    overshoot = max(speeds) - result_target
    if result_target != 0:
        overshoot_pct = (max(speeds) - result_target) / result_target * 100
    else:
        overshoot_pct = 0

    # 稳定时间 (进入 ±5%)
    settle_time = len(speeds)
    for i in range(len(speeds)):
        if abs(speeds[i] - result_target) / max(result_target, 1) < 0.05:
            # 检查后续是否都在范围内
            ok = True
            for j in range(i, min(i + 100, len(speeds))):
                if abs(speeds[j] - result_target) / max(result_target, 1) >= 0.05:
                    ok = False
                    break
            if ok:
                settle_time = i * 5  # ms
                break

    steady_error = abs(avg_speed - result_target) / max(result_target, 1) * 100

    return {
        "avg_speed": avg_speed,
        "overshoot_pct": overshoot_pct,
        "settle_time_ms": settle_time,
        "steady_error_pct": steady_error,
        "max_pwm": max(abs(p) for p in pwms),
        "speeds": speeds
    }


def evaluate_speed_pid():
    """扫描速度 PID 参数"""
    print("=" * 60)
    print("速度 PID 参数扫描 (目标: Safe-profile mode1 速度)")
    print("=" * 60)
    print(f"{'Kp':>5} {'Ki':>5} {'稳态速度':>10} {'超调%':>8} {'稳定时间ms':>10} {'稳态误差%':>10} {'最大PWM':>8}")
    print("-" * 60)

    best = None
    best_score = float('inf')

    # Kp 和 Ki 都只在较小范围内搜索 (现有值为 Kp=2, Ki=8)
    # 因为前馈已经承担了大部分控制
    for kp in [1, 2, 3, 4, 5]:
        for ki in [4, 6, 8, 10, 12]:
            result = simulate_speed_pid(kp, ki)
            if result is None:
                continue

            overshoot = result["overshoot_pct"]
            settle = result["settle_time_ms"]
            steady_err = result["steady_error_pct"]

            # 评分 (加权)
            score = (overshoot * 2 + settle * 0.5 + steady_err * 3)

            print(f"{kp:5d} {ki:5d} {result['avg_speed']:10.1f} {overshoot:8.2f}% {settle:10d} {steady_err:10.2f}% {result['max_pwm']:8.0f}")

            target_speed = PROFILES["safe"]["mode_speeds"][0]
            if score < best_score and result["avg_speed"] > target_speed * 0.9:
                best_score = score
                best = (kp, ki, score)

    print("-" * 60)
    if best:
        print(f"推荐: Kp={best[0]}, Ki={best[1]}, 评分={best[2]:.1f}")

    return best


def simulate_heading_pid(kp_num, kp_den, ki_num, ki_den, kd_num, kd_den,
                         deadband=8, integral_limit=600, output_limit=260):
    """仿真航向 PID 阶跃响应 (模拟车体转向动力学)"""

    pid = HeadingPID(kp_num, kp_den, ki_num, ki_den, kd_num, kd_den,
                     deadband, integral_limit, output_limit)

    # 车体转向模型: 简单二阶
    # yaw_rate = steering_term * turn_gain (带有积分特性)
    yaw = 0.0       # 当前航向 (0.1°)
    yaw_rate = 0.0  # (°/s)

    # 车体转动惯量参数 (从日志观察)
    # 从日志 t=90000: hdg=-900/0, ryaw=61 (开始转弯)
    # 到 t=92000: hdg=-900/0, ryaw=161 (2秒转了 ~100°)
    # 等效转动增益
    TURN_GAIN = 3.0     # (0.1°/s) per pps of steering term
    DAMPING = 0.85       # 阻尼系数

    target_error = 450  # 45° 阶跃
    steps = 800  # 4 seconds

    errors = []
    outputs = []
    yaws = []

    for i in range(steps):
        # 当前误差
        current_error = target_error - yaw

        steering = pid.step(current_error)

        # 车体响应 (一阶滞后)
        yaw_rate = yaw_rate * DAMPING + steering * TURN_GAIN * (1 - DAMPING)
        yaw += yaw_rate * DT  # 注意: yaw 和 error 都是 0.1°

        errors.append(current_error)
        outputs.append(steering)
        yaws.append(yaw)

    # 评估
    if len(errors) < 100:
        return None

    steady = errors[-100:]
    avg_steady_error = sum(steady) / len(steady)
    max_overshoot = max(errors) - target_error if max(errors) > target_error else 0

    # 稳定时间
    settle_time = len(errors)
    for i in range(len(errors)):
        if abs(errors[i]) < target_error * 0.05:
            ok = True
            for j in range(i, min(i + 100, len(errors))):
                if abs(errors[j]) >= target_error * 0.05:
                    ok = False
                    break
            if ok:
                settle_time = i * 5  # ms
                break

    return {
        "avg_steady_error": avg_steady_error,
        "max_overshoot": max_overshoot,
        "settle_time_ms": settle_time,
        "max_output": max(abs(o) for o in outputs),
        "errors": errors,
        "outputs": outputs,
        "yaws": yaws
    }


def evaluate_heading_pid():
    """扫描航向 PID 参数"""
    print("\n" + "=" * 60)
    print("航向 PID 参数扫描 (45° 阶跃响应)")
    print("=" * 60)

    # 先扫 P/D   (Ki 保持较小)
    # P 范围: 1.0 - 3.0  (num/den = 10/10 ~ 30/10)
    # D 范围: 1.0 - 4.0
    # I 范围: 0.005 - 0.02

    candidates = []

    print(f"\n--- 扫描 PD 参数 (I=0.01) ---")
    print(f"{'Kp':>8} {'Kd':>8} {'稳态误差':>10} {'超调量':>8} {'稳定时间ms':>10} {'最大输出':>8}")
    print("-" * 60)

    best = None
    best_score = float('inf')

    for kp in range(10, 31, 2):  # 1.0 - 3.0 step 0.2
        for kd in range(5, 41, 3):  # 0.5 - 4.0 step 0.3
            result = simulate_heading_pid(kp, 10, 1, 140, kd, 10,
                                          deadband=5, integral_limit=600, output_limit=260)
            if result is None:
                continue

            overshoot = result["max_overshoot"]
            settle = result["settle_time_ms"]
            steady_err = result["avg_steady_error"]

            score = overshoot * 0.3 + settle * 0.4 + abs(steady_err) * 2

            if result["max_output"] <= 260:
                candidates.append((kp/10, kd/10, score))

                if score < best_score:
                    best_score = score
                    best = (kp, kd, score, result)

    # 显示 top 10
    candidates.sort(key=lambda x: x[2])
    print(f"\nTop 10 PD 参数组合:")
    for i, (kp, kd, score) in enumerate(candidates[:10]):
        print(f"  {i+1}. Kp={kp:.1f}, Kd={kd:.1f}  评分={score:.1f}")

    if best:
        kp_opt, kd_opt, score_opt, result_opt = best
        print(f"\n推荐 PD: Kp={kp_opt/10:.1f} ({kp_opt}/10), Kd={kd_opt/10:.1f} ({kd_opt}/10)")
        print(f"  稳态误差: {result_opt['avg_steady_error']:.1f} (0.1°)")
        print(f"  超调: {result_opt['max_overshoot']:.1f} (0.1°)")
        print(f"  稳定时间: {result_opt['settle_time_ms']}ms")

        # 在最优 P/D 基础上扫描 I
        print(f"\n--- 在 Kp={kp_opt/10:.1f}, Kd={kd_opt/10:.1f} 基础上扫描 Ki ---")
        print(f"{'Ki':>8} {'稳态误差':>10} {'超调量':>8} {'稳定时间ms':>10} {'最大输出':>8}")
        print("-" * 55)

        best_i = None
        best_i_score = float('inf')

        for ki_num in range(0, 5):
            ki_den_vals = [(100, 0.01), (140, 0.007), (200, 0.005), (300, 0.0033)]
            for ki_den, ki_label in ki_den_vals:
                result_i = simulate_heading_pid(kp_opt, 10, ki_num, ki_den, kd_opt, 10,
                                                deadband=5, integral_limit=600, output_limit=260)
                if result_i is None:
                    continue

                overshoot = result_i['max_overshoot']
                settle = result_i['settle_time_ms']
                steady_err = result_i['avg_steady_error']
                i_score = overshoot * 0.3 + settle * 0.4 + abs(steady_err) * 2

                if ki_num == 0:
                    print(f"{'0':>8} {steady_err:10.1f} {overshoot:8.1f} {settle:10d} {result_i['max_output']:8.0f}")
                else:
                    print(f"{ki_label:>8} {steady_err:10.1f} {overshoot:8.1f} {settle:10d} {result_i['max_output']:8.0f}")

                if i_score < best_i_score:
                    best_i_score = i_score
                    best_i = (ki_num, ki_den, ki_label, result_i)

        if best_i:
            ki_num, ki_den, ki_label, result_i = best_i
            print(f"\n推荐 Ki: {ki_label} ({ki_num}/{ki_den})")
            print(f"  稳态误差: {result_i['avg_steady_error']:.1f} (0.1°)")
            print(f"  超调: {result_i['max_overshoot']:.1f} (0.1°)")
            print(f"  稳定时间: {result_i['settle_time_ms']}ms")

    return best, best_i


def simulate_full_heading_with_log_data(kp_num, kp_den, ki_num, ki_den, kd_num, kd_den,
                                          deadband=8, integral_limit=600, output_limit=260):
    """
    使用日志中的实际航向误差序列来仿真 PID 输出
    与日志中的实际 turn_term_pps 对比
    """
    # 从日志提取数据点
    # t=38000: hdg=0/-15 (误差 -15 x10), term=0/-41
    # t=40000: hdg=0/24 (误差 24), term=0/70
    # t=42000: hdg=0/62 (误差 62), term=0/169
    # t=44000: hdg=0/78 (误差 78), term=0/210
    # t=46000: hdg=0/86 (误差 86), term=0/231
    # t=48000: hdg=0/98 (误差 98), term=50/262

    log_data = [
        (-15, -41),
        (24, 70),
        (62, 169),
        (78, 210),
        (86, 231),
        (98, 262),
    ]

    pid = HeadingPID(kp_num, kp_den, ki_num, ki_den, kd_num, kd_den,
                     deadband, integral_limit, output_limit)

    print(f"\n--- 日志数据验证 (Kp={kp_num}/{kp_den}, Ki={ki_num}/{ki_den}, Kd={kd_num}/{kd_den}) ---")
    print(f"{'日志误差':>8} {'日志输出':>8} {'仿真输出':>8} {'偏差':>8}")
    print("-" * 40)

    total_error = 0
    for error_x10, actual_output in log_data:
        sim_output = pid.step(error_x10)
        deviation = sim_output - actual_output
        total_error += abs(deviation)
        print(f"{error_x10:8d} {actual_output:8d} {sim_output:8.1f} {deviation:8.1f}")

    print(f"总偏差: {total_error:.1f}")
    return total_error


def test_log_replay_simulation():
    """
    基于日志的时间线模拟 PID 行为, 验证参数是否合理
    """
    print("\n" + "=" * 60)
    print("基于日志时间线的 PID 仿真验证")
    print("=" * 60)

    # MODE1 时间线 (从日志提取)
    # 阶段1: 开段直线 (t=38000~90000, 约 52s)
    #   车体在初始阶段偏航严重, hdg 误差从 -15 跳到 98 再回到 18
    #   说明 P 增益过大会引起震荡
    # 阶段2: 弧线 (t=90000~94000)
    #   hdg 目标 -900, ryaw 从 61 变为 1417 (进入弧线后 yaw 快速变化)

    # 使用推荐参数验证
    kp, kp_den = 18, 10
    ki, ki_den = 1, 140
    kd, kd_den = 20, 10  # Kd = 2.0

    simulate_full_heading_with_log_data(kp, kp_den, ki, ki_den, kd, kd_den)


def simulate_line_tracking():
    """
    巡线模式仿真: 测试 line_turn_gain 的效果
    """
    print("\n" + "=" * 60)
    print("巡线转向仿真 (line_turn_gain)")
    print("=" * 60)

    # 巡线公式:
    # term = (line_error * turn_gain_num / turn_gain_den) + (delta_error * 3)

    turn_gain_num = 9
    turn_gain_den = 2
    wheel_max = 1800

    # 模拟线偏差序列: 车从偏离中心逐渐回归
    line_errors = [300, 250, 180, 100, 50, 20, -10, -30, -20, -10, -5, 0, 0, 0]

    print(f"{'line_err':>10} {'P_term':>8} {'D_term':>8} {'总输出':>8}")
    print("-" * 40)

    prev_err = 0
    for err in line_errors:
        p_term = err * turn_gain_num // turn_gain_den
        d_term = (err - prev_err) * 3
        total = p_term + d_term
        total = max(-wheel_max, min(wheel_max, total))
        print(f"{err:10d} {p_term:8d} {d_term:8d} {total:8d}")
        prev_err = err


def main():
    print("MSPM0G3507 PID 调参仿真工具")
    print("=" * 60)

    target = PROFILES["safe"]["mode_speeds"][0]

    # 1. 速度 PID 扫描
    best_speed = evaluate_speed_pid()

    # 2. 航向 PID 扫描
    best_heading, best_i = evaluate_heading_pid()

    # 3. 日志验证
    test_log_replay_simulation()

    # 4. 巡线验证
    simulate_line_tracking()

    # 5. 总结
    print("\n" + "=" * 60)
    print("最终推荐参数")
    print("=" * 60)

    if best_heading:
        kp_opt, kd_opt, _, _ = best_heading
        print(f"\n航向 PID:")
        print(f"  Kp = {kp_opt}/10 = {kp_opt/10:.1f}")
        if best_i:
            ki_num, ki_den, ki_label, _ = best_i
            print(f"  Ki = {ki_num}/{ki_den} = {ki_label}")
        print(f"  Kd = {kd_opt}/10 = {kd_opt/10:.1f}")
        print(f"  死区 HDB = 5 (0.5°)")
        print(f"  积分限幅 HILIM = 600")
        print(f"  输出限幅 HLIM = 260")

    if best_speed:
        kp_s, ki_s, _ = best_speed
        print(f"\n速度 PID (前馈已承担主要控制):")
        print(f"  Kp = {kp_s}")
        print(f"  Ki = {ki_s}")

    print(f"\n调参命令 (通过 ESP32 串口发送):")
    print(f"  PARAM,HPID,{best_heading[0] if best_heading else 18},10,{best_i[0] if best_i else 1},{best_i[1] if best_i else 140},{best_heading[1] if best_heading else 20},10")
    print(f"  PARAM,HDB,5")
    print(f"  PARAM,HILIM,600")
    print(f"  PARAM,HLIM,260")
    print(f"  PARAM,SHOW")


if __name__ == "__main__":
    main()
