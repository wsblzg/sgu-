import argparse
import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path


APP_CONTROL_HZ = 200
CAR_APP_LOG_PREFIX = "CARLOG"
BUTTON_BITS = {
    "mode1": 1 << 0,
    "mode2": 1 << 1,
    "mode3": 1 << 2,
    "start": 1 << 3,
}
ROUTES = {
    1: ["A", "B", "C"],
    2: ["A", "B", "C", "D", "A"],
    3: ["A", "C", "B", "D", "A"],
}
WEIGHTS = [-350, -250, -150, -50, 50, 150, 250, 350]
K230_MODE_STOP = "STOP"
K230_MODE_AIM = "AIM"
K230_MODE_ECG = "ECG"

TASK_BASIC_1 = 0
TASK_BASIC_2 = 1
TASK_BASIC_3 = 2
TASK_ADV_ECG = 3
TASK_ADV_ROUTE2_AIM = 4
TASK_ADV_ROUTE3_AIM = 5


@dataclass
class Profile:
    name: str
    base_speed_mode_1: int
    base_speed_mode_2: int
    base_speed_mode_3: int
    motor_feedforward_num: int
    line_turn_gain_num: int
    line_turn_gain_den: int
    straight_diff_gain_num: int
    straight_diff_gain_den: int
    straight_diff_limit_pps: int
    speed_pid_kp_num: int
    speed_pid_ki_num: int
    speed_pid_scale_den: int
    speed_pid_integral_limit: int
    wheel_speed_max_pps: int
    motor_line_lost_pwm: int
    motor_min_effective_pwm: int
    node_active_count_min: int
    node_confirm_ticks: int
    node_release_ticks: int
    node_rearm_min_travel: int
    mode1_stop_hold_ms: int
    odom_counts_per_mm_x100: int
    heading_gain_num: int
    heading_gain_den: int
    heading_term_limit_pps: int
    node_event_beep_ms: int
    start_event_beep_ms: int
    stop_event_beep_ms: int


def parse_profiles(path: Path):
    profiles = {}
    pattern = re.compile(r"CAR_APP_PROFILE\((.*?)\)", re.S)
    text = path.read_text(encoding="utf-8")
    for match in pattern.finditer(text):
        body = match.group(1).replace("\n", " ")
        row = next(csv.reader([body], skipinitialspace=True))
        key = row[1].strip('"')
        values = [int(value.strip()) for value in row[2:]]
        profiles[key] = Profile(key, *values)
    return profiles


def clamp_i32(value, min_value, max_value):
    return max(min_value, min(max_value, value))


def abs_i16(value):
    return -value if value < 0 else value


class SpeedPid:
    def __init__(self):
        self.integral = 0
        self.last_error = 0

    def reset(self):
        self.integral = 0
        self.last_error = 0

    def step(self, profile: Profile, target_pps: int, measured_pps: int):
        error = target_pps - measured_pps
        feedforward = target_pps * profile.motor_feedforward_num
        self.integral = clamp_i32(
            self.integral + error,
            -profile.speed_pid_integral_limit,
            profile.speed_pid_integral_limit,
        )
        output = feedforward + (
            profile.speed_pid_kp_num * error
            + profile.speed_pid_ki_num * self.integral
        ) // profile.speed_pid_scale_den
        output = clamp_i32(
            output,
            -profile.wheel_speed_max_pps * 4,
            profile.wheel_speed_max_pps * 4,
        )
        self.last_error = error

        if target_pps == 0 and abs_i16(measured_pps) < 50:
            self.reset()
            return 0

        if output != 0 and abs_i16(output) < profile.motor_min_effective_pwm:
            output = -profile.motor_min_effective_pwm if output < 0 else profile.motor_min_effective_pwm

        return output


class CarAppReplay:
    def __init__(self, profile: Profile):
        self.profile = profile
        self.state = 0
        self.phase = 2
        self.selected_mode = 1
        self.contest_task = TASK_BASIC_1
        self.mode3_loops = 1
        self.active_loops = 0
        self.completed_loops = 0
        self.route_index = 0
        self.node_confirm_ticks = 0
        self.node_release_ticks = 0
        self.hold_ticks_remaining = 0
        self.prev_button_mask = 0
        self.last_selection_button = None
        self.node_event_count = 0
        self.tick_count = 0
        self.travel_count_total = 0
        self.prev_left_total_count = 0
        self.prev_right_total_count = 0
        self.last_node_trigger_travel_count = 0
        self.last_event_node = "A"
        self.node_detector_armed = False
        self.last_line_error = 0
        self.line_has = False
        self.line_error = 0
        self.line_mask = 0
        self.left_speed_pps = 0
        self.right_speed_pps = 0
        self.left_target_pps = 0
        self.right_target_pps = 0
        self.left_pwm = 0
        self.right_pwm = 0
        self.yaw_deg = 0.0
        self.led_on = False
        self.left_pid = SpeedPid()
        self.right_pid = SpeedPid()
        self.max_hold_ms = 0

    def mode_base_speed(self):
        return {
            1: self.profile.base_speed_mode_1,
            2: self.profile.base_speed_mode_2,
            3: self.profile.base_speed_mode_3,
        }[self.selected_mode]

    def mode1_hold_ticks(self):
        return self.profile.mode1_stop_hold_ms * APP_CONTROL_HZ // 1000

    def reset_motor(self):
        self.left_target_pps = 0
        self.right_target_pps = 0
        self.left_pwm = 0
        self.right_pwm = 0
        self.left_pid.reset()
        self.right_pid.reset()

    def get_route(self):
        return ROUTES[self.selected_mode]

    def handle_selection_buttons(self, pressed_mask):
        if pressed_mask & BUTTON_BITS["mode1"]:
            if self.last_selection_button == "mode1" and self.contest_task == TASK_BASIC_1:
                self.contest_task = TASK_ADV_ECG
            else:
                self.contest_task = TASK_BASIC_1
            self.selected_mode = 1
            self.last_selection_button = "mode1"
        if pressed_mask & BUTTON_BITS["mode2"]:
            if self.last_selection_button == "mode2" and self.contest_task == TASK_BASIC_2:
                self.contest_task = TASK_ADV_ROUTE2_AIM
            else:
                self.contest_task = TASK_BASIC_2
            self.selected_mode = 2
            self.last_selection_button = "mode2"
        if pressed_mask & BUTTON_BITS["mode3"]:
            if self.contest_task == TASK_ADV_ROUTE3_AIM:
                self.contest_task = TASK_BASIC_3
                self.mode3_loops = 1
            elif self.last_selection_button == "mode3" and self.contest_task == TASK_BASIC_3:
                self.mode3_loops += 1
                if self.mode3_loops > 3:
                    self.contest_task = TASK_ADV_ROUTE3_AIM
                    self.mode3_loops = 1
            else:
                self.contest_task = TASK_BASIC_3
                self.mode3_loops = 1
                self.selected_mode = 3
            self.selected_mode = 3
            self.last_selection_button = "mode3"

    def start(self):
        route = self.get_route()
        self.state = 1
        self.phase = 0
        self.route_index = 0
        self.completed_loops = 0
        self.active_loops = self.mode3_loops if self.selected_mode == 3 else 1
        self.node_confirm_ticks = 0
        self.node_release_ticks = 0
        self.hold_ticks_remaining = 0
        self.node_event_count = 0
        self.travel_count_total = 0
        self.prev_left_total_count = 0
        self.prev_right_total_count = 0
        self.last_node_trigger_travel_count = 0
        self.last_event_node = route[0]
        self.node_detector_armed = False
        self.last_line_error = 0
        self.led_on = True
        self.reset_motor()

    def stop(self):
        self.state = 2
        self.phase = 2
        self.hold_ticks_remaining = 0
        self.node_confirm_ticks = 0
        self.node_release_ticks = 0
        self.node_detector_armed = False
        self.led_on = False
        self.reset_motor()

    def get_k230_mode(self):
        if self.state != 1:
            return K230_MODE_STOP
        if self.contest_task == TASK_ADV_ECG:
            return K230_MODE_ECG
        if self.contest_task in (TASK_ADV_ROUTE2_AIM, TASK_ADV_ROUTE3_AIM):
            return K230_MODE_AIM
        return K230_MODE_STOP

    def line_looks_like_node(self, active_count, active_mask):
        if not self.line_has:
            return False
        if active_count >= self.profile.node_active_count_min:
            return True
        if active_count >= 4 and (active_mask & 0x81) == 0x81:
            return True
        if active_count >= 4 and (active_mask & 0xC3) == 0xC3:
            return True
        return False

    def update_line(self, line_online, active_mask):
        weighted_sum = 0
        active_count = 0
        for index in range(8):
            bit = 1 << index
            if active_mask & bit:
                weighted_sum += WEIGHTS[index]
                active_count += 1
        if not line_online or active_count == 0:
            self.line_has = False
            self.line_error = 0
            self.line_mask = active_mask
            return active_count
        self.line_has = True
        self.line_error = weighted_sum // active_count
        self.line_mask = active_mask
        return active_count

    def update_motion(self):
        if self.contest_task == TASK_ADV_ECG:
            self.reset_motor()
            return
        if self.state != 1 or self.phase != 0:
            self.reset_motor()
            return
        if not self.line_has:
            self.left_target_pps = 0
            self.right_target_pps = 0
            self.left_pwm = self.profile.motor_line_lost_pwm
            self.right_pwm = -self.profile.motor_line_lost_pwm
            return
        turn_term = (
            self.line_error * self.profile.line_turn_gain_num
        ) // self.profile.line_turn_gain_den + (self.line_error - self.last_line_error) * 3
        straight_term = (
            (self.left_speed_pps - self.right_speed_pps)
            * self.profile.straight_diff_gain_num
        ) // self.profile.straight_diff_gain_den
        straight_term = clamp_i32(
            straight_term,
            -self.profile.straight_diff_limit_pps,
            self.profile.straight_diff_limit_pps,
        )
        self.left_target_pps = clamp_i32(
            self.mode_base_speed() + straight_term + turn_term,
            0,
            self.profile.wheel_speed_max_pps,
        )
        self.right_target_pps = clamp_i32(
            self.mode_base_speed() - straight_term - turn_term,
            0,
            self.profile.wheel_speed_max_pps,
        )
        self.left_pwm = self.left_pid.step(
            self.profile, self.left_target_pps, self.left_speed_pps
        )
        self.right_pwm = self.right_pid.step(
            self.profile, self.right_target_pps, self.right_speed_pps
        )
        self.last_line_error = self.line_error

    def handle_route_node(self):
        route = self.get_route()
        is_mode1_mid_stop = self.selected_mode == 1 and self.route_index == 0 and route[1] == "B"
        if self.route_index + 1 >= len(route):
            return
        reached_node = route[self.route_index + 1]
        self.route_index += 1
        self.node_event_count += 1
        self.last_event_node = reached_node
        reached_route_end = self.route_index >= len(route) - 1
        if is_mode1_mid_stop:
            self.phase = 1
            self.hold_ticks_remaining = self.mode1_hold_ticks()
            self.reset_motor()
            return
        if reached_route_end:
            self.completed_loops += 1
            if self.active_loops > 1:
                self.active_loops -= 1
                self.route_index = 0
                return
            self.stop()

    def update_task_state(self, active_count):
        if self.state != 1:
            return
        if self.contest_task == TASK_ADV_ECG:
            self.reset_motor()
            return
        if self.phase == 1:
            self.reset_motor()
            if self.hold_ticks_remaining > 0:
                self.hold_ticks_remaining -= 1
            self.max_hold_ms = max(self.max_hold_ms, self.hold_ticks_remaining * 1000 // APP_CONTROL_HZ)
            if self.hold_ticks_remaining == 0:
                self.phase = 0
                self.last_line_error = 0
                self.node_confirm_ticks = 0
                self.node_release_ticks = 0
                self.node_detector_armed = False
                self.last_node_trigger_travel_count = self.travel_count_total
            return
        if self.phase != 0:
            self.reset_motor()
            return
        looks_like_node = self.line_looks_like_node(active_count, self.line_mask)
        travel_since_last = self.travel_count_total - self.last_node_trigger_travel_count
        if not self.node_detector_armed:
            self.node_confirm_ticks = 0
            if not looks_like_node:
                self.node_release_ticks = min(self.node_release_ticks + 1, 255)
                if (
                    self.node_release_ticks >= self.profile.node_release_ticks
                    and travel_since_last >= self.profile.node_rearm_min_travel
                ):
                    self.node_detector_armed = True
            else:
                self.node_release_ticks = 0
            return
        if not looks_like_node:
            self.node_confirm_ticks = 0
            return
        self.node_confirm_ticks = min(self.node_confirm_ticks + 1, 255)
        if self.node_confirm_ticks < self.profile.node_confirm_ticks:
            return
        self.node_confirm_ticks = 0
        self.node_release_ticks = 0
        self.node_detector_armed = False
        self.last_node_trigger_travel_count = self.travel_count_total
        self.handle_route_node()

    def step(self, frame):
        pressed_mask = frame["button_mask"] & ~self.prev_button_mask
        self.prev_button_mask = frame["button_mask"]
        if self.state != 1:
            self.handle_selection_buttons(pressed_mask)
        if pressed_mask & BUTTON_BITS["start"]:
            if self.state == 1:
                self.stop()
            else:
                self.start()

        active_count = self.update_line(frame["line_online"], frame["line_mask"])
        self.yaw_deg = frame["yaw_deg"]
        self.left_speed_pps = frame["left_delta"] * APP_CONTROL_HZ
        self.right_speed_pps = frame["right_delta"] * APP_CONTROL_HZ
        self.travel_count_total += (abs(frame["left_delta"]) + abs(frame["right_delta"])) // 2
        self.update_task_state(active_count)
        self.update_motion()
        self.tick_count += 1

    def snapshot(self):
        route = self.get_route()
        total_loops = self.mode3_loops if self.selected_mode == 3 else 1
        current_loop = total_loops if self.completed_loops >= total_loops else self.completed_loops + 1
        return {
            "t_ms": self.tick_count * 1000 // APP_CONTROL_HZ,
            "profile": self.profile.name,
            "mode": self.selected_mode,
            "task": self.contest_task,
            "k230_mode": self.get_k230_mode(),
            "state": self.state,
            "phase": self.phase,
            "seg_idx": self.route_index,
            "seg_total": len(route) - 1,
            "loop_cur": current_loop,
            "loop_total": total_loops,
            "last": self.last_event_node,
            "evt": self.node_event_count,
            "hold_ms": self.hold_ticks_remaining * 1000 // APP_CONTROL_HZ,
            "line_ok": 1 if self.line_has else 0,
            "line_mask": self.line_mask,
            "err": self.line_error,
            "spd_l": self.left_speed_pps,
            "spd_r": self.right_speed_pps,
            "tar_l": self.left_target_pps,
            "tar_r": self.right_target_pps,
            "pwm_l": self.left_pwm,
            "pwm_r": self.right_pwm,
            "yaw_deg": self.yaw_deg,
            "completed_loops": self.completed_loops,
        }


def format_log(snapshot):
    yaw_tenth = int(snapshot["yaw_deg"] * 10.0)
    yaw_frac = abs(yaw_tenth % 10)
    return (
        f"{CAR_APP_LOG_PREFIX},t_ms={snapshot['t_ms']},profile={snapshot['profile']},"
        f"mode={snapshot['mode']},task={snapshot['task']},k230={snapshot['k230_mode']},state={snapshot['state']},phase={snapshot['phase']},"
        f"seg={snapshot['seg_idx']}/{snapshot['seg_total']},loop={snapshot['loop_cur']}/{snapshot['loop_total']},"
        f"last={snapshot['last']},evt={snapshot['evt']},hold_ms={snapshot['hold_ms']},"
        f"line_ok={snapshot['line_ok']},line=0x{snapshot['line_mask']:02X},err={snapshot['err']},"
        f"spd={snapshot['spd_l']}/{snapshot['spd_r']},tar={snapshot['tar_l']}/{snapshot['tar_r']},"
        f"pwm={snapshot['pwm_l']}/{snapshot['pwm_r']},yaw={yaw_tenth // 10}.{yaw_frac}"
    )


def button_mask_from_names(names):
    mask = 0
    for name in names:
        mask |= BUTTON_BITS[name]
    return mask


def build_frames(scenario):
    frames = []
    left_total = 0
    right_total = 0
    for frame in scenario["frames"]:
        repeat = frame.get("repeat", 1)
        button_mask = button_mask_from_names(frame.get("buttons", []))
        line_mask = int(frame.get("line_mask", "0x00"), 16)
        line_online = frame.get("line_online", True)
        left_delta = int(frame.get("left_delta", 0))
        right_delta = int(frame.get("right_delta", 0))
        yaw_deg = float(frame.get("yaw_deg", 0.0))
        for _ in range(repeat):
            left_total += left_delta
            right_total += right_delta
            frames.append(
                {
                    "button_mask": button_mask,
                    "line_online": line_online,
                    "line_mask": line_mask,
                    "left_delta": left_delta,
                    "right_delta": right_delta,
                    "left_total": left_total,
                    "right_total": right_total,
                    "yaw_deg": yaw_deg,
                }
            )
            button_mask = 0
    return frames


def check_expectations(app: CarAppReplay, scenario):
    expect = scenario.get("expect", {})
    snapshot = app.snapshot()
    failures = []
    if "last_node" in expect and snapshot["last"] != expect["last_node"]:
        failures.append(f"last_node={snapshot['last']} expected={expect['last_node']}")
    if "node_event_count" in expect and snapshot["evt"] != expect["node_event_count"]:
        failures.append(f"node_event_count={snapshot['evt']} expected={expect['node_event_count']}")
    if "final_state" in expect and snapshot["state"] != expect["final_state"]:
        failures.append(f"final_state={snapshot['state']} expected={expect['final_state']}")
    if "completed_loops" in expect and snapshot["completed_loops"] != expect["completed_loops"]:
        failures.append(
            f"completed_loops={snapshot['completed_loops']} expected={expect['completed_loops']}"
        )
    if "min_hold_ms" in expect and app.max_hold_ms < expect["min_hold_ms"]:
        failures.append(f"max_hold_ms={app.max_hold_ms} expected>={expect['min_hold_ms']}")
    return failures


def main():
    parser = argparse.ArgumentParser(description="Replay offline car_app scenarios.")
    parser.add_argument("scenario", type=Path, help="Scenario JSON file")
    parser.add_argument(
        "--profiles",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "car_app_profiles.def",
        help="Path to car_app_profiles.def",
    )
    args = parser.parse_args()

    scenario = json.loads(args.scenario.read_text(encoding="utf-8"))
    profiles = parse_profiles(args.profiles)
    app = CarAppReplay(profiles[scenario["profile"]])
    frames = build_frames(scenario)
    log_every = int(scenario.get("log_every_ticks", 20))

    for index, frame in enumerate(frames, start=1):
        app.step(frame)
        if (index % log_every) == 0 or index == len(frames):
            print(format_log(app.snapshot()))

    snapshot = app.snapshot()
    print(
        f"SUMMARY name={scenario['name']} state={snapshot['state']} phase={snapshot['phase']} "
        f"last={snapshot['last']} evt={snapshot['evt']} loop={snapshot['loop_cur']}/{snapshot['loop_total']} "
        f"hold_max_ms={app.max_hold_ms}"
    )
    failures = check_expectations(app, scenario)
    if failures:
        for failure in failures:
            print(f"EXPECT_FAIL {failure}")
        raise SystemExit(1)
    print("EXPECT_OK")


if __name__ == "__main__":
    main()
