# MSPM0G3507 小车底盘基础工程

工程目录：

- `main.c`：主入口，只保留初始化、主循环和模块调用
- `board.c / board.h`：底层板级驱动，负责 PWM、电机方向、编码器、按键、LED、蜂鸣器、巡线 I2C、串口读写
- `car_app.c / car_app.h`：小车控制主逻辑，负责模式选择、节点识别、速度环、比赛状态机
- `jy901.c / jy901.h`：JY901B 协议解析
- `gimbal_servo.c / gimbal_servo.h`：PCA9685 双轴舵机云台控制
- `app_types.h`：跨模块共享的数据结构
- `mspm0g3507_minimal.syscfg`：当前工程的 SysConfig 入口
- `legacy/startup_mspm0g3507_ticlang.c.disabled`：历史保留启动文件，不参与当前 SDK 工程编译
- `legacy/mspm0g3507.cmd.disabled`：历史保留链接脚本，不参与当前 SDK 工程链接
- `targetConfigs/MSPM0G3507.ccxml`：调试配置
- `.ccsproject / .cproject`：已切换为 `MSPM0 SDK 2.10.0.04` 工程格式

当前 SDK 安装路径：

- `D:\TI\MSPM0_SDK\mspm0_sdk_2_10_00_04`

当前工程已经植入以下 SDK 能力：

- `MSPM0-SDK:2.10.0.04`
- `sysconfig:1.27.0`
- `driverlib` 头文件、库路径、符号宏自动注入
- `SysConfig` 生成 `ti_msp_dl_config.c/.h`、`device.opt`、`device_linker.cmd`

适用场景：

- 继续往下落地 PWM、编码器、I2C 巡线、JY901B 串口姿态
- 在 CCS Theia 里直接基于 SysConfig 补外设实例
- 作为校赛车模控制工程的主工程

当前目录已经继续扩成“小车底盘基础工程”的软件骨架，增加了：

- `JY901B` 协议解析框架
- 巡线误差计算框架
- 模式 1 / 2 / 3 状态机
- 电机、编码器、巡线、按键、蜂鸣器、LED 的统一 HAL 接口
- `main.c` 与业务/驱动模块解耦
- [引脚分配表.md](./引脚分配表.md)

当前这版已经实际接入并编译验证了：

- `TB6612`：左右轮 PWM 输出 + 方向控制
- 左轮编码器：`TIMG8 QEI` 硬件解码
- 右轮编码器：`GPIOA 26/27` 双边沿中断软件 AB 解码
- 感为八路巡线：`I2C` 读取 `Ping / 数字量 / 8 路模拟量`
- `JY901B`：`UART1` FIFO 轮询收包
- 板载/外接：4 键、LED、蜂鸣器
- 瞄准模块：`PCA9685 + 双舵机云台`，由 `MSPM0` 通过 `I2C` 输出 `50Hz` 舵机 PWM
- 激光笔：归属 `K230` 瞄准模块侧控制，默认 `IO33 TTL/EN`

需要注意：

- `main.c` 现在已经会调用 `SYSCFG_DL_init()`，说明工程不再是纯裸工程
- `legacy/startup_mspm0g3507_ticlang.c.disabled` 和 `legacy/mspm0g3507.cmd.disabled` 先保留，便于回退和对照
- 如果 SysConfig 无头编译在中文路径下报路径解析错误，当前工程可用 `subst M: D:\项目\电赛\mspm0` 后在 `Debug` 目录直接跑 `gmake clean all`
- 当前 `MSPM0G3507` 的 `SysConfig` 里只有一组硬件 `QEI`，所以双编码器方案采用“左硬件 QEI + 右软件 AB 解码”

最新这轮继续补了比赛流程层：

- 模式 1：`A -> B` 停车保持 `3s`，再继续到 `C` 终止
- 模式 2：`A -> B -> C -> D -> A` 单圈
- 模式 3：`A -> C -> B -> D -> A`，支持按键切换 `N=1~3` 圈
- 节点识别采用“巡线位图宽线特征 + 编码器行进距离冷却”
- 调试串口增加了 `phase / seg / loop / last node / event count / hold ticks` 观测字段

按 2025 电赛题目要求，当前工程分工已经明确为：

- `MSPM0`：巡线、小车电机、编码器、底盘状态机、PCA9685 双轴舵机云台控制
- `K230`：视觉识别、瞄准策略、激光笔开关控制
- 两块控制板需采用独立电源开关，并各自具备供电状态指示

当前又补了一套“先离线验证，再上车联调”的工具链：

- `car_app_profiles.def`：集中管理关键参数，当前内置 `safe / race` 两套 profile
- `tools/replay_car_app.py`：离线回放巡线位图、编码器增量、IMU 航向角，直接跑 `mode1 / mode2 / mode3` 状态机
- `tools/parse_car_log.py`：解析实机或回放输出的 `CARLOG` 日志，打印摘要并导出 CSV

## 参数 profile

当前参数统一收敛在 `car_app_profiles.def`：

- 基础速度：`base_speed_mode_1/2/3`
- 速度环：`motor_feedforward_num`、`speed_pid_kp_num`、`speed_pid_ki_num`
- 巡线转向：`line_turn_gain_num/den`
- 节点识别：`node_active_count_min`、`node_confirm_ticks`、`node_release_ticks`
- 节点重触发冷却：`node_rearm_min_travel`
- 模式 1 停车时间：`mode1_stop_hold_ms`

默认建议：

- `safe`：先保证不乱判节点、不丢线，适合首次上车
- `race`：速度更激进，适合底盘稳定后冲成绩

MCU 侧已经提供：

- `car_app_set_profile()`
- `car_app_get_profile()`
- `car_app_get_profile_name()`

## CARLOG 协议

调试串口日志前缀固定为：

- `CARLOG`

单行示例：

```text
CARLOG,t_ms=250,profile=safe,mode=1,k230=STOP,state=1,phase=0,seg=0/2,loop=1/1,last=A,leg=AB,ltype=ST,lline=0,llen=1000,lhd=0/0,lcnt=123/1000,hdg=0/-15,evt=0,hold_ms=0,line_ok=1,line=0x18,err=0,vok=1,vstat=IDLE,verr=0/0,spd=800/800,tar=820/820,pwm=2107/2107,yaw=0.0,gim_en=1,gim_us=1500/1500,gim_tar_us=1500/1500
```

字段含义：

- `t_ms`：时间戳
- `phase`：任务子阶段，`0` 巡线运行，`1` 停车保持，`2` 空闲
- `k230`：当前底盘要求 K230 进入的视觉模式，`STOP / AIM / ECG`
- `leg`：当前理论路段，例如 `AB / AC / CB / BD / DA`
- `ltype`：当前理论路段类型，`ST` 直线、`ARC` 弧线
- `lline`：当前理论路段是否应由巡线主导，`0/1`
- `llen`：当前理论路段长度，单位 `mm`
- `lhd`：当前理论路段起止航向，单位 `0.1deg`
- `lcnt`：当前理论路段已走里程计数 / 目标计数
- `hdg`：当前理论目标航向 / 航向误差，单位 `0.1deg`
- `vok`：是否收到过 K230 视觉状态回传，`0/1`
- `vstat`：K230 当前视觉状态，`IDLE / TRACKING / LOCKED / LOST`
- `verr`：K230 视觉目标相对图像中心的像素误差，格式 `err_x/err_y`
- `seg`：当前路径段索引 / 总段数
- `loop`：当前圈 / 目标圈
- `last`：最近一次确认到达的节点
- `evt`：累计节点事件数
- `line`：8 路巡线位图
- `spd / tar / pwm`：左右轮实测速度 / 目标速度 / PWM
- `yaw`：JY901B 航向角
- `gim_us / gim_tar_us`：双轴舵机当前脉宽 / 目标脉宽，单位 `us`，格式 `pan/tilt`

当前默认联动规则：

- 底盘停止：`k230=STOP`
- 校赛基本 1/2/3：底盘运行时仍保持 `k230=STOP`
- 校赛发挥 1：原地心电图，`k230=ECG`
- 校赛发挥 2/3：行驶中瞄准靶心，`k230=AIM`

## PCA9685 双舵机云台

当前瞄准云台硬件统一为 `PCA9685 + 两个舵机`：

- `PCA9685` 默认 I2C 地址：`0x40`
- `PCA9685 SDA/SCL`：接 `PA0/PA1`，与巡线模块共用 I2C 总线
- `CH0`：水平轴 `pan`
- `CH1`：俯仰轴 `tilt`
- 舵机控制单位：`1000~2000us` 脉宽，软件中位 `1500us`
- `GIMBAL,pan_us,tilt_us`：设置绝对目标脉宽
- `GIMBALD,pan_delta_us,tilt_delta_us`：在当前目标基础上做脉宽增量
- `GIMBALC`：回到 `1500us / 1500us`

## 校赛几何建模

针对 `D:\项目\电赛\校赛\电赛校赛要求.md`，当前工程已经按题目给出的主尺寸建立理论几何模型：

- `AB = 1000mm`
- 黑色半圆弧半径：`400mm`
- 上下直线 `AB / CD`：`1000mm`
- 对角直线 `AC / BD`：`1280.62mm`
- 单个半圆弧：`1256.64mm`
- 目标靶所在直线与 `AB` 平行，距离 `AB` 外侧 `500mm`

由此得到：

- 模式 2 单圈理论路径：`4513.27mm`
- 模式 3 单圈理论路径：`5074.55mm`
- 模式 2 若要求 `30s` 完成，平均速度下限约：`150.44mm/s`
- 模式 3 若要求 `40s` 完成，平均速度下限约：`126.86mm/s`

离线几何分析与采样仿真脚本：

```powershell
python .\tools\school_track_geometry.py --route mode2 --time-limit 30
python .\tools\school_track_geometry.py --route mode3 --time-limit 40
```

校赛路线推进逻辑的纯软件状态机脚本与测试：

```powershell
python .\tools\test_school_track_route_logic.py
```

当前 MCU 侧已经按这套思路落入基础控制框架：

- 直线段 `AB / CD / AC / BD`：使用 `JY901` 航向保持 + 编码器里程推进
- 弧线段 `BC / CB / DA`：继续使用巡线闭环 + 编码器里程推进
- 模式 1：`AB` 完成后进入 `B` 点停车保持 `3s`
- 模式 2：`AB -> BC -> CD -> DA`
- 模式 3：`AC -> CB -> BD -> DA`

当前需要重点标定的量已经并入 `car_app_profiles.def`：

- `odom_counts_per_mm_x100`
- `heading_gain_num`
- `heading_gain_den`
- `heading_term_limit_pps`

其中：

- `odom_counts_per_mm_x100`：把理论毫米长度换算成当前软件里的里程计单位
- `heading_gain_num / den`：直线段 `JY901` 航向保持的转向增益
- `heading_term_limit_pps`：直线段航向修正项限幅

当前默认值只是占位起点，不是实车定值。

## 直线段标定

推荐先用 `AB=1000mm` 做最小标定：

1. 固定使用模式 1 或模式 2，让小车只做短距离直线段测试
2. 抓串口 `CARLOG`
3. 观察：
   - `leg=AB`
   - `lcnt=当前计数/目标计数`
   - `hdg=目标航向/误差`
4. 实际测量本次直线段真实行驶距离 `distance_mm`
5. 用脚本反算 `odom_counts_per_mm_x100`

直接用计数值：

```powershell
python .\tools\calibrate_odometry.py --counts 640 --distance-mm 320
```

直接从日志中抽取某一路段的最大计数：

```powershell
python .\tools\calibrate_odometry.py --log .\tools\run.log --leg AB --distance-mm 1000
python .\tools\calibrate_odometry.py --log .\tools\run.log --leg AC --distance-mm 1280.625
```

脚本会输出：

- `counts`
- `counts_per_mm_x100`

然后把结果写回 `car_app_profiles.def` 中对应 profile 的 `odom_counts_per_mm_x100`。

## 航向段调参

建议顺序：

1. 先把 `odom_counts_per_mm_x100` 标准
2. 再调直线段航向保持：
   - 偏航修正太慢：增大 `heading_gain_num`
   - 左右摆动明显：减小 `heading_gain_num` 或增大 `heading_gain_den`
   - 转向修正过猛：减小 `heading_term_limit_pps`

重点观察日志：

- `leg=AC / BD`
- `hdg=target/error`
- `yaw=...`
- `pwm=.../...`

## 离线回放

场景文件目录：

- `tools/scenarios/mode1_stop_then_c.json`
- `tools/scenarios/mode2_full_loop.json`
- `tools/scenarios/mode3_two_loops.json`

运行示例：

```powershell
python .\tools\replay_car_app.py .\tools\scenarios\mode1_stop_then_c.json
python .\tools\replay_car_app.py .\tools\scenarios\mode2_full_loop.json
python .\tools\replay_car_app.py .\tools\scenarios\mode3_two_loops.json
```

当前 3 个场景分别覆盖：

- 模式 1：`B` 点停车 `3s`，再继续到 `C`
- 模式 2：`A -> B -> C -> D -> A` 单圈闭环
- 模式 3：两圈运行结束逻辑

## 日志解析

解析脚本支持：

- 普通 `UTF-8` 文本日志
- PowerShell `>` 重定向生成的 `UTF-16 LE BOM` 日志

使用示例：

```powershell
python .\tools\parse_car_log.py .\tools\mode1_replay.log --csv .\tools\mode1_replay.csv
```

输出结果包括：

- 运行摘要：`rows / profile / mode / time_ms / events / last_node / loop / state / phase`
- 可直接喂给 Excel 的 `CSV`

如果是回放日志，推荐先导出日志文件，再跑解析：

```powershell
python .\tools\replay_car_app.py .\tools\scenarios\mode1_stop_then_c.json > .\tools\mode1_replay.log
python .\tools\parse_car_log.py .\tools\mode1_replay.log --csv .\tools\mode1_replay.csv
```
