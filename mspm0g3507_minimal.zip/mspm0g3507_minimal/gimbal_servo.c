#include <string.h>

#include "board.h"
#include "gimbal_servo.h"

#define GIMBAL_SERVO_MIN_US         (600)  /* WHEELTEC 云台安全下限。资料源码 300 个 2us 计数，约 600us。 */
#define GIMBAL_SERVO_MAX_US         (2400) /* WHEELTEC 云台安全上限。资料源码 1200 个 2us 计数，约 2400us。 */
#define GIMBAL_SERVO_CENTER_US      (1500) /* 舵机中位脉宽。调大整体偏向一侧；调小整体偏向另一侧，用于机械中位校准。 */
#define GIMBAL_SERVO_MAX_US_PER_TICK (16)  /* 每个控制 tick 最大脉宽变化。调大云台响应更快但更抖；调小更平滑但跟随慢。 */
#define GIMBAL_PAN_MAX_DEG       (270)
#define GIMBAL_TILT_MAX_DEG      (180)
#define GIMBAL_SERVO_US_AT_0_DEG (500)
#define GIMBAL_SERVO_US_SPAN     (2000)

static gimbal_state_t g_gimbal;
static bool g_servo_ready;

static int32_t clamp_i32(int32_t value, int32_t min_value, int32_t max_value)
{
    if (value < min_value) {
        return min_value;
    }
    if (value > max_value) {
        return max_value;
    }
    return value;
}

static int32_t gimbal_angle_to_us(int32_t angle_deg, int32_t max_deg)
{
    angle_deg = clamp_i32(angle_deg, 0, max_deg);
    return GIMBAL_SERVO_US_AT_0_DEG + ((angle_deg * GIMBAL_SERVO_US_SPAN) / max_deg);
}

static int32_t gimbal_us_this_tick(int32_t error)
{
    int32_t magnitude = (error < 0) ? -error : error;

    if (magnitude > GIMBAL_SERVO_MAX_US_PER_TICK) {
        magnitude = GIMBAL_SERVO_MAX_US_PER_TICK;
    }

    return (error > 0) ? magnitude : -magnitude;
}

static bool gimbal_move_axis(int32_t *position_us, int32_t target_us)
{
    int32_t step;
    const int32_t error = target_us - *position_us;

    if (error == 0) {
        return false;
    }

    step = gimbal_us_this_tick(error);
    *position_us += step;
    return true;
}

void gimbal_servo_init(void)
{
    memset(&g_gimbal, 0, sizeof(g_gimbal));
    g_gimbal.enabled = false;
    g_gimbal.pan_position_us = GIMBAL_SERVO_CENTER_US;
    g_gimbal.tilt_position_us = GIMBAL_SERVO_CENTER_US;
    g_gimbal.pan_target_us = GIMBAL_SERVO_CENTER_US;
    g_gimbal.tilt_target_us = GIMBAL_SERVO_CENTER_US;
    g_servo_ready = false;
}

void gimbal_servo_set_enabled(bool enabled)
{
    g_gimbal.enabled = enabled;
    if (enabled && !g_servo_ready) {
        g_servo_ready = board_servo_gimbal_init();
    }
}

void gimbal_servo_center(void)
{
    gimbal_servo_set_target(GIMBAL_SERVO_CENTER_US, GIMBAL_SERVO_CENTER_US);
}

void gimbal_servo_set_target(int32_t pan_us, int32_t tilt_us)
{
    g_gimbal.pan_target_us = clamp_i32(
        pan_us, GIMBAL_SERVO_MIN_US, GIMBAL_SERVO_MAX_US);
    g_gimbal.tilt_target_us = clamp_i32(
        tilt_us, GIMBAL_SERVO_MIN_US, GIMBAL_SERVO_MAX_US);
}

void gimbal_servo_sync_position(int32_t pan_us, int32_t tilt_us)
{
    gimbal_servo_set_target(pan_us, tilt_us);
    g_gimbal.pan_position_us = g_gimbal.pan_target_us;
    g_gimbal.tilt_position_us = g_gimbal.tilt_target_us;
}

void gimbal_servo_set_angle(int32_t pan_deg, int32_t tilt_deg)
{
    gimbal_servo_set_target(
        gimbal_angle_to_us(pan_deg, GIMBAL_PAN_MAX_DEG),
        gimbal_angle_to_us(tilt_deg, GIMBAL_TILT_MAX_DEG));
}

void gimbal_servo_sync_angle(int32_t pan_deg, int32_t tilt_deg)
{
    gimbal_servo_set_angle(pan_deg, tilt_deg);
    g_gimbal.pan_position_us = g_gimbal.pan_target_us;
    g_gimbal.tilt_position_us = g_gimbal.tilt_target_us;
}

void gimbal_servo_offset(int16_t pan_delta_us, int16_t tilt_delta_us)
{
    gimbal_servo_set_target(
        g_gimbal.pan_target_us + pan_delta_us,
        g_gimbal.tilt_target_us + tilt_delta_us);
}

void gimbal_servo_service_200hz(void)
{
    bool changed;

    if (!g_gimbal.enabled) {
        return;
    }

    if (!g_servo_ready) {
        g_servo_ready = board_servo_gimbal_init();
        if (!g_servo_ready) {
            return;
        }
    }

    changed = gimbal_move_axis(&g_gimbal.pan_position_us, g_gimbal.pan_target_us);
    changed = gimbal_move_axis(&g_gimbal.tilt_position_us, g_gimbal.tilt_target_us) ||
              changed;

    if (changed) {
        if (!board_servo_gimbal_set_us(
                (uint16_t) g_gimbal.pan_position_us,
                (uint16_t) g_gimbal.tilt_position_us)) {
            g_servo_ready = false;
        }
    }
}

void gimbal_servo_get_state(gimbal_state_t *state)
{
    if (state == NULL) {
        return;
    }

    *state = g_gimbal;
}
