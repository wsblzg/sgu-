#ifndef OLED_H_
#define OLED_H_

#include <stdbool.h>
#include <stdint.h>

void oled_init(void);
void oled_show_waiting(void);
void oled_show_mode(uint8_t mode, uint8_t state, uint8_t phase, uint8_t current_loop, uint8_t total_loops);
void oled_show_task(const char *task, uint8_t state, uint8_t phase, uint8_t current_loop, uint8_t total_loops);

#endif /* OLED_H_ */
