/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_LEFT */
#define PWM_LEFT_INST                                                      TIMA1
#define PWM_LEFT_INST_IRQHandler                                TIMA1_IRQHandler
#define PWM_LEFT_INST_INT_IRQN                                  (TIMA1_INT_IRQn)
#define PWM_LEFT_INST_CLK_FREQ                                          32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_LEFT_C0_PORT                                              GPIOA
#define GPIO_PWM_LEFT_C0_PIN                                      DL_GPIO_PIN_15
#define GPIO_PWM_LEFT_C0_IOMUX                                   (IOMUX_PINCM37)
#define GPIO_PWM_LEFT_C0_IOMUX_FUNC                  IOMUX_PINCM37_PF_TIMA1_CCP0
#define GPIO_PWM_LEFT_C0_IDX                                 DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_LEFT_C1_PORT                                              GPIOA
#define GPIO_PWM_LEFT_C1_PIN                                      DL_GPIO_PIN_24
#define GPIO_PWM_LEFT_C1_IOMUX                                   (IOMUX_PINCM54)
#define GPIO_PWM_LEFT_C1_IOMUX_FUNC                  IOMUX_PINCM54_PF_TIMA1_CCP1
#define GPIO_PWM_LEFT_C1_IDX                                 DL_TIMER_CC_1_INDEX

/* Defines for PWM_RIGHT */
#define PWM_RIGHT_INST                                                     TIMG7
#define PWM_RIGHT_INST_IRQHandler                               TIMG7_IRQHandler
#define PWM_RIGHT_INST_INT_IRQN                                 (TIMG7_INT_IRQn)
#define PWM_RIGHT_INST_CLK_FREQ                                         32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_RIGHT_C0_PORT                                             GPIOA
#define GPIO_PWM_RIGHT_C0_PIN                                     DL_GPIO_PIN_17
#define GPIO_PWM_RIGHT_C0_IOMUX                                  (IOMUX_PINCM39)
#define GPIO_PWM_RIGHT_C0_IOMUX_FUNC                 IOMUX_PINCM39_PF_TIMG7_CCP0
#define GPIO_PWM_RIGHT_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_RIGHT_C1_PORT                                             GPIOA
#define GPIO_PWM_RIGHT_C1_PIN                                     DL_GPIO_PIN_18
#define GPIO_PWM_RIGHT_C1_IOMUX                                  (IOMUX_PINCM40)
#define GPIO_PWM_RIGHT_C1_IOMUX_FUNC                 IOMUX_PINCM40_PF_TIMG7_CCP1
#define GPIO_PWM_RIGHT_C1_IDX                                DL_TIMER_CC_1_INDEX




/* Defines for QEI_LEFT */
#define QEI_LEFT_INST                                                      TIMG8
#define QEI_LEFT_INST_IRQHandler                                TIMG8_IRQHandler
#define QEI_LEFT_INST_INT_IRQN                                  (TIMG8_INT_IRQn)
/* Pin configuration defines for QEI_LEFT PHA Pin */
#define GPIO_QEI_LEFT_PHA_PORT                                             GPIOA
#define GPIO_QEI_LEFT_PHA_PIN                                     DL_GPIO_PIN_29
#define GPIO_QEI_LEFT_PHA_IOMUX                                   (IOMUX_PINCM4)
#define GPIO_QEI_LEFT_PHA_IOMUX_FUNC                  IOMUX_PINCM4_PF_TIMG8_CCP0
/* Pin configuration defines for QEI_LEFT PHB Pin */
#define GPIO_QEI_LEFT_PHB_PORT                                             GPIOA
#define GPIO_QEI_LEFT_PHB_PIN                                     DL_GPIO_PIN_30
#define GPIO_QEI_LEFT_PHB_IOMUX                                   (IOMUX_PINCM5)
#define GPIO_QEI_LEFT_PHB_IOMUX_FUNC                  IOMUX_PINCM5_PF_TIMG8_CCP1



/* Defines for I2C_LINE */
#define I2C_LINE_INST                                                       I2C0
#define I2C_LINE_INST_IRQHandler                                 I2C0_IRQHandler
#define I2C_LINE_INST_INT_IRQN                                     I2C0_INT_IRQn
#define I2C_LINE_BUS_SPEED_HZ                                             100000
#define GPIO_I2C_LINE_SDA_PORT                                             GPIOA
#define GPIO_I2C_LINE_SDA_PIN                                      DL_GPIO_PIN_0
#define GPIO_I2C_LINE_IOMUX_SDA                                   (IOMUX_PINCM1)
#define GPIO_I2C_LINE_IOMUX_SDA_FUNC                    IOMUX_PINCM1_PF_I2C0_SDA
#define GPIO_I2C_LINE_SCL_PORT                                             GPIOA
#define GPIO_I2C_LINE_SCL_PIN                                      DL_GPIO_PIN_1
#define GPIO_I2C_LINE_IOMUX_SCL                                   (IOMUX_PINCM2)
#define GPIO_I2C_LINE_IOMUX_SCL_FUNC                    IOMUX_PINCM2_PF_I2C0_SCL


/* Defines for UART_DEBUG */
#define UART_DEBUG_INST                                                    UART0
#define UART_DEBUG_INST_FREQUENCY                                       32000000
#define UART_DEBUG_INST_IRQHandler                              UART0_IRQHandler
#define UART_DEBUG_INST_INT_IRQN                                  UART0_INT_IRQn
#define GPIO_UART_DEBUG_RX_PORT                                            GPIOA
#define GPIO_UART_DEBUG_TX_PORT                                            GPIOA
#define GPIO_UART_DEBUG_RX_PIN                                    DL_GPIO_PIN_11
#define GPIO_UART_DEBUG_TX_PIN                                    DL_GPIO_PIN_10
#define GPIO_UART_DEBUG_IOMUX_RX                                 (IOMUX_PINCM22)
#define GPIO_UART_DEBUG_IOMUX_TX                                 (IOMUX_PINCM21)
#define GPIO_UART_DEBUG_IOMUX_RX_FUNC                  IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_DEBUG_IOMUX_TX_FUNC                  IOMUX_PINCM21_PF_UART0_TX
#define UART_DEBUG_BAUD_RATE                                            (115200)
#define UART_DEBUG_IBRD_32_MHZ_115200_BAUD                                  (17)
#define UART_DEBUG_FBRD_32_MHZ_115200_BAUD                                  (23)
/* Defines for UART_IMU */
#define UART_IMU_INST                                                      UART1
#define UART_IMU_INST_FREQUENCY                                         32000000
#define UART_IMU_INST_IRQHandler                                UART1_IRQHandler
#define UART_IMU_INST_INT_IRQN                                    UART1_INT_IRQn
#define GPIO_UART_IMU_RX_PORT                                              GPIOA
#define GPIO_UART_IMU_TX_PORT                                              GPIOA
#define GPIO_UART_IMU_RX_PIN                                       DL_GPIO_PIN_9
#define GPIO_UART_IMU_TX_PIN                                       DL_GPIO_PIN_8
#define GPIO_UART_IMU_IOMUX_RX                                   (IOMUX_PINCM20)
#define GPIO_UART_IMU_IOMUX_TX                                   (IOMUX_PINCM19)
#define GPIO_UART_IMU_IOMUX_RX_FUNC                    IOMUX_PINCM20_PF_UART1_RX
#define GPIO_UART_IMU_IOMUX_TX_FUNC                    IOMUX_PINCM19_PF_UART1_TX
#define UART_IMU_BAUD_RATE                                                (9600)
#define UART_IMU_IBRD_32_MHZ_9600_BAUD                                     (208)
#define UART_IMU_FBRD_32_MHZ_9600_BAUD                                      (21)





/* Port definition for Pin Group GPIO_MOTOR_LEFT_DIR */
#define GPIO_MOTOR_LEFT_DIR_PORT                                         (GPIOA)

/* Defines for AIN1: GPIOA.14 with pinCMx 36 on package pin 7 */
#define GPIO_MOTOR_LEFT_DIR_AIN1_PIN                            (DL_GPIO_PIN_14)
#define GPIO_MOTOR_LEFT_DIR_AIN1_IOMUX                           (IOMUX_PINCM36)
/* Defines for AIN2: GPIOA.16 with pinCMx 38 on package pin 9 */
#define GPIO_MOTOR_LEFT_DIR_AIN2_PIN                            (DL_GPIO_PIN_16)
#define GPIO_MOTOR_LEFT_DIR_AIN2_IOMUX                           (IOMUX_PINCM38)
/* Port definition for Pin Group GPIO_MOTOR_RIGHT_DIR */
#define GPIO_MOTOR_RIGHT_DIR_PORT                                        (GPIOA)

/* Defines for BIN1: GPIOA.12 with pinCMx 34 on package pin 5 */
#define GPIO_MOTOR_RIGHT_DIR_BIN1_PIN                           (DL_GPIO_PIN_12)
#define GPIO_MOTOR_RIGHT_DIR_BIN1_IOMUX                          (IOMUX_PINCM34)
/* Defines for BIN2: GPIOA.13 with pinCMx 35 on package pin 6 */
#define GPIO_MOTOR_RIGHT_DIR_BIN2_PIN                           (DL_GPIO_PIN_13)
#define GPIO_MOTOR_RIGHT_DIR_BIN2_IOMUX                          (IOMUX_PINCM35)
/* Port definition for Pin Group GPIO_KEYS */
#define GPIO_KEYS_PORT                                                   (GPIOB)

/* Defines for MODE_1: GPIOB.13 with pinCMx 30 on package pin 1 */
#define GPIO_KEYS_MODE_1_PIN                                    (DL_GPIO_PIN_13)
#define GPIO_KEYS_MODE_1_IOMUX                                   (IOMUX_PINCM30)
/* Defines for MODE_2: GPIOB.15 with pinCMx 32 on package pin 3 */
#define GPIO_KEYS_MODE_2_PIN                                    (DL_GPIO_PIN_15)
#define GPIO_KEYS_MODE_2_IOMUX                                   (IOMUX_PINCM32)
/* Defines for MODE_3: GPIOB.16 with pinCMx 33 on package pin 4 */
#define GPIO_KEYS_MODE_3_PIN                                    (DL_GPIO_PIN_16)
#define GPIO_KEYS_MODE_3_IOMUX                                   (IOMUX_PINCM33)
/* Defines for START: GPIOB.21 with pinCMx 49 on package pin 20 */
#define GPIO_KEYS_START_PIN                                     (DL_GPIO_PIN_21)
#define GPIO_KEYS_START_IOMUX                                    (IOMUX_PINCM49)
/* Port definition for Pin Group GPIO_INDICATORS */
#define GPIO_INDICATORS_PORT                                             (GPIOB)

/* Defines for STATUS_LED: GPIOB.22 with pinCMx 50 on package pin 21 */
#define GPIO_INDICATORS_STATUS_LED_PIN                          (DL_GPIO_PIN_22)
#define GPIO_INDICATORS_STATUS_LED_IOMUX                         (IOMUX_PINCM50)
/* Defines for BUZZER: GPIOB.23 with pinCMx 51 on package pin 22 */
#define GPIO_INDICATORS_BUZZER_PIN                              (DL_GPIO_PIN_23)
#define GPIO_INDICATORS_BUZZER_IOMUX                             (IOMUX_PINCM51)
/* Port definition for Pin Group GPIO_ENCODER_RIGHT */
#define GPIO_ENCODER_RIGHT_PORT                                          (GPIOA)

/* Defines for PHA: GPIOA.26 with pinCMx 59 on package pin 30 */
// pins affected by this interrupt request:["PHA","PHB"]
#define GPIO_ENCODER_RIGHT_INT_IRQN                             (GPIOA_INT_IRQn)
#define GPIO_ENCODER_RIGHT_INT_IIDX             (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_ENCODER_RIGHT_PHA_IIDX                         (DL_GPIO_IIDX_DIO26)
#define GPIO_ENCODER_RIGHT_PHA_PIN                              (DL_GPIO_PIN_26)
#define GPIO_ENCODER_RIGHT_PHA_IOMUX                             (IOMUX_PINCM59)
/* Defines for PHB: GPIOA.27 with pinCMx 60 on package pin 31 */
#define GPIO_ENCODER_RIGHT_PHB_IIDX                         (DL_GPIO_IIDX_DIO27)
#define GPIO_ENCODER_RIGHT_PHB_PIN                              (DL_GPIO_PIN_27)
#define GPIO_ENCODER_RIGHT_PHB_IOMUX                             (IOMUX_PINCM60)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_LEFT_init(void);
void SYSCFG_DL_PWM_RIGHT_init(void);
void SYSCFG_DL_QEI_LEFT_init(void);
void SYSCFG_DL_I2C_LINE_init(void);
void SYSCFG_DL_UART_DEBUG_init(void);
void SYSCFG_DL_UART_IMU_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
