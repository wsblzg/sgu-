# FIXED

car_app.o: ../car_app.c ../car_app.h ../app_types.h ../board.h \
 ../gimbal_servo.h ../jy901.h ../k230_protocol.h ../oled.h \
 ../car_app_profiles.def
../car_app.h:
../app_types.h:
../board.h:
../gimbal_servo.h:
../jy901.h:
../k230_protocol.h:
../oled.h:
../car_app_profiles.def:
