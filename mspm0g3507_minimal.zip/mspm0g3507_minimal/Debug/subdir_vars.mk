################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../mspm0g3507_minimal.syscfg 

C_SRCS += \
../board.c \
../car_app.c \
../gimbal_servo.c \
../jy901.c \
../k230_protocol.c \
../main.c \
./ti_msp_dl_config.c \
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
../oled.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./board.d \
./car_app.d \
./gimbal_servo.d \
./jy901.d \
./k230_protocol.d \
./main.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d \
./oled.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./board.o \
./car_app.o \
./gimbal_servo.o \
./jy901.o \
./k230_protocol.o \
./main.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o \
./oled.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"board.o" \
"car_app.o" \
"gimbal_servo.o" \
"jy901.o" \
"k230_protocol.o" \
"main.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" \
"oled.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"board.d" \
"car_app.d" \
"gimbal_servo.d" \
"jy901.d" \
"k230_protocol.d" \
"main.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" \
"oled.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../board.c" \
"../car_app.c" \
"../gimbal_servo.c" \
"../jy901.c" \
"../k230_protocol.c" \
"../main.c" \
"./ti_msp_dl_config.c" \
"D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" \
"../oled.c" 

SYSCFG_SRCS__QUOTED += \
"../mspm0g3507_minimal.syscfg" 


