# FIXED

ti_msp_dl_config.o: ti_msp_dl_config.c ti_msp_dl_config.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h \
 D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h
ti_msp_dl_config.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h:
D:/TI/MSPM0_SDK/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h:
