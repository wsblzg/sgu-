# FIXED

k230_protocol.o: ../k230_protocol.c ../board.h ../app_types.h \
 ../car_app.h ../gimbal_servo.h ../k230_protocol.h
../board.h:
../app_types.h:
../car_app.h:
../gimbal_servo.h:
../k230_protocol.h:
