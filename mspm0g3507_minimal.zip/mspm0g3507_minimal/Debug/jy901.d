# FIXED

jy901.o: ../jy901.c ../jy901.h ../app_types.h
../jy901.h:
../app_types.h:
