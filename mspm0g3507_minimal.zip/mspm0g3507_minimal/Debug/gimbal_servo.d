# FIXED

gimbal_servo.o: ../gimbal_servo.c ../board.h ../app_types.h \
 ../gimbal_servo.h
../board.h:
../app_types.h:
../gimbal_servo.h:
