#include <string.h>

#include "ti_msp_dl_config.h"
#include "board_config.h"
#include "board.h"

#define MOTOR_PWM_LIMIT               4000   /* 电机 PWM 绝对限幅。调大最大占空比更高、车更猛；调小限制输出、更稳但可能动力不足。 */
#define APP_DELAY_CYCLES_PER_MS       (CPUCLK_FREQ / 1000U) /* 毫秒延时换算。随系统时钟变化，不建议手动改。 */
#define I2C_TIMEOUT_LOOPS             200000U /* I2C 软件等待超时循环。调大可容忍慢设备但卡死等待更久；调小故障返回更快但可能误超时。 */
#define I2C_TRANSFER_DELAY_CYCLES     64U     /* 硬件 I2C 传输间隔。调大总线更保守；调小更快但对时序余量要求高。 */
#define LINE_SENSOR_I2C_ADDR          0x4CU   /* 感为八路巡线 I2C 地址。地址不匹配会读不到巡线；只在模块地址改变时修改。 */
#define LINE_SENSOR_REG_PING          0xAAU   /* 巡线模块 Ping 寄存器。协议常量，不是调参项。 */
#define LINE_SENSOR_PING_OK           0x66U   /* 巡线模块 Ping 正常返回值。协议常量，不是调参项。 */
#define LINE_SENSOR_REG_DIGITAL       0xDDU   /* 巡线数字量寄存器。协议常量，不是调参项。 */
#define LINE_SENSOR_REG_ANALOG_BASE   0xB0U   /* 巡线模拟量起始寄存器。协议常量，不是调参项。 */
#define PCA9685_DEFAULT_ADDR          0x40U   /* PCA9685 I2C 地址。若 A0-A5 地址脚改变需同步修改，否则云台无响应。 */
#define PCA9685_REG_MODE1             0x00U   /* PCA9685 MODE1 寄存器地址。芯片协议常量，不调。 */
#define PCA9685_REG_MODE2             0x01U   /* PCA9685 MODE2 寄存器地址。芯片协议常量，不调。 */
#define PCA9685_REG_LED0_ON_L         0x06U   /* PCA9685 第 0 通道 PWM 寄存器基址。芯片协议常量，不调。 */
#define PCA9685_REG_PRESCALE          0xFEU   /* PCA9685 分频寄存器地址。芯片协议常量，不调。 */
#define PCA9685_MODE1_RESTART         0x80U   /* PCA9685 重启位。协议位，不调。 */
#define PCA9685_MODE1_AUTO_INCREMENT  0x20U   /* PCA9685 地址自增位。关闭会导致连续写通道失败，不调。 */
#define PCA9685_MODE1_SLEEP           0x10U   /* PCA9685 睡眠位。初始化设置分频时使用，不调。 */
#define PCA9685_MODE2_OUTDRV          0x04U   /* PCA9685 推挽输出配置。若硬件要求开漏才改，普通舵机保持当前值。 */
#define PCA9685_SERVO_PRESCALE_50HZ   121U    /* 50Hz 舵机周期分频。调大频率降低；调小频率升高，普通舵机不建议改。 */
#define PCA9685_TICKS_PER_PERIOD      4096U   /* PCA9685 每周期计数分辨率。芯片固定值，不调。 */
#define SERVO_PERIOD_US               20000U  /* 舵机 PWM 周期，单位 us，20ms=50Hz。调小频率升高；调大频率降低。 */
#define SERVO_CH_PAN                  0U      /* PCA9685 水平轴通道。接到别的通道时修改；调大/调小只是换通道号。 */
#define SERVO_CH_TILT                 1U      /* PCA9685 俯仰轴通道。接到别的通道时修改；调大/调小只是换通道号。 */
#define PCA9685_SDA_PORT              GPIOB   /* PCA9685 软件 I2C SDA 端口。换线需同步 PORT/PIN/IOMUX。 */
#define PCA9685_SDA_PIN               DL_GPIO_PIN_0 /* PCA9685 SDA 引脚。改错会导致云台 I2C 无响应。 */
#define PCA9685_SDA_IOMUX             IOMUX_PINCM12  /* PCA9685 SDA IOMUX。需与引脚匹配，不是性能调参。 */
#define PCA9685_SCL_PORT              GPIOB   /* PCA9685 软件 I2C SCL 端口。换线需同步 PORT/PIN/IOMUX。 */
#define PCA9685_SCL_PIN               DL_GPIO_PIN_1 /* PCA9685 SCL 引脚。改错会导致云台 I2C 无响应。 */
#define PCA9685_SCL_IOMUX             IOMUX_PINCM13  /* PCA9685 SCL IOMUX。需与引脚匹配，不是性能调参。 */
#define LEFT_ENCODER_SIGN             (-1)    /* 左编码器方向符号。改为 1 会反转左轮计数方向；方向错会影响里程和速度闭环。 */
#define RIGHT_ENCODER_SIGN            (1)     /* 右编码器方向符号。改为 -1 会反转右轮计数方向；方向错会影响里程和速度闭环。 */
#define IMU_RX_RING_SIZE              1024U   /* IMU 串口接收环形缓冲大小，必须为 2 的幂。调大更抗突发数据但占 RAM；调小省 RAM 但易溢出。 */
#define IMU_RX_RING_MASK              (IMU_RX_RING_SIZE - 1U) /* IMU 缓冲取模掩码，跟随 SIZE 自动变化，不单独改。 */
#define DEBUG_RX_RING_SIZE            256U    /* 调试串口接收缓冲大小，必须为 2 的幂。调大更能接长命令/突发命令；调小省 RAM。 */
#define DEBUG_RX_RING_MASK            (DEBUG_RX_RING_SIZE - 1U) /* 调试缓冲取模掩码，跟随 SIZE 自动变化，不单独改。 */
#define BUZZER_ACTIVE_LOW             1U      /* 蜂鸣器有效电平。设 1 为低电平响；设 0 为高电平响，取决于实际驱动电路。 */
#define BOARD_BEEP_SERVICE_HZ         APP_CONTROL_HZ /* 蜂鸣器非阻塞服务频率，跟随主控制 tick，避免声光提示阻塞巡线。 */
#define LASER_RELAY_PORT            GPIOA     /* 激光/瞄准模块继电器 IN 端口。默认 PA22，换线需同步引脚表。 */
#define LASER_RELAY_PIN             DL_GPIO_PIN_22 /* 激光/瞄准模块继电器 IN 引脚。 */
#define LASER_RELAY_IOMUX           IOMUX_PINCM47 /* PA22 对应 IOMUX。 */
#define LASER_RELAY_ACTIVE_HIGH     0U        /* 继电器触发极性。当前继电器 IN 接 GND 吸合，低电平触发设 0。 */

static volatile int32_t g_right_encoder_count = 0;
static volatile uint8_t g_right_encoder_prev_state = 0U;
static volatile uint8_t g_debug_rx_ring[DEBUG_RX_RING_SIZE];
static volatile uint16_t g_debug_rx_head = 0U;
static volatile uint16_t g_debug_rx_tail = 0U;
static volatile uint32_t g_debug_rx_overflow = 0U;
static volatile uint8_t g_imu_rx_ring[IMU_RX_RING_SIZE];
static volatile uint16_t g_imu_rx_head = 0U;
static volatile uint16_t g_imu_rx_tail = 0U;
static volatile uint32_t g_imu_rx_overflow = 0U;
static uint16_t g_buzzer_ticks_remaining = 0U;

static int16_t clamp_i16(int32_t value, int16_t min_value, int16_t max_value)
{
    if (value < (int32_t) min_value) {
        return min_value;
    }
    if (value > (int32_t) max_value) {
        return max_value;
    }
    return (int16_t) value;
}

static int16_t abs_i16(int16_t value)
{
    return (value < 0) ? (int16_t) (-value) : value;
}

static void board_set_buzzer_active(bool active)
{
#if BUZZER_ACTIVE_LOW
    if (active) {
        DL_GPIO_clearPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_BUZZER_PIN);
    } else {
        DL_GPIO_setPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_BUZZER_PIN);
    }
#else
    if (active) {
        DL_GPIO_setPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_BUZZER_PIN);
    } else {
        DL_GPIO_clearPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_BUZZER_PIN);
    }
#endif
}

void board_delay_cycles(volatile uint32_t cycles)
{
    while (cycles-- > 0U) {
        __asm(" nop");
    }
}

static uint8_t board_read_right_encoder_state(void)
{
    const uint32_t pins = DL_GPIO_readPins(
        GPIO_ENCODER_RIGHT_PORT,
        GPIO_ENCODER_RIGHT_PHA_PIN | GPIO_ENCODER_RIGHT_PHB_PIN);
    const uint8_t pha = ((pins & GPIO_ENCODER_RIGHT_PHA_PIN) != 0U) ? 1U : 0U;
    const uint8_t phb = ((pins & GPIO_ENCODER_RIGHT_PHB_PIN) != 0U) ? 1U : 0U;

    return (uint8_t) ((pha << 1U) | phb);
}

static int8_t board_quadrature_step(uint8_t previous_state, uint8_t current_state)
{
    static const int8_t transition_table[16] = {
        0, -1, 1, 0,
        1, 0, 0, -1,
        -1, 0, 0, 1,
        0, 1, -1, 0
    };

    return transition_table[((previous_state & 0x03U) << 2U) | (current_state & 0x03U)];
}

static bool board_i2c_wait_idle(void)
{
    uint32_t timeout = I2C_TIMEOUT_LOOPS;

    while (timeout-- > 0U) {
        if ((DL_I2C_getControllerStatus(I2C_LINE_INST) &
             DL_I2C_CONTROLLER_STATUS_IDLE) != 0U) {
            return true;
        }
    }

    return false;
}

static bool board_i2c_wait_bus_ready(void)
{
    uint32_t timeout = I2C_TIMEOUT_LOOPS;

    while (timeout-- > 0U) {
        if ((DL_I2C_getControllerStatus(I2C_LINE_INST) &
             DL_I2C_CONTROLLER_STATUS_BUSY_BUS) == 0U) {
            return true;
        }
    }

    return false;
}

static bool board_i2c_has_error(void)
{
    return (DL_I2C_getControllerStatus(I2C_LINE_INST) &
            DL_I2C_CONTROLLER_STATUS_ERROR) != 0U;
}

static void board_i2c_recover(void)
{
    DL_I2C_flushControllerTXFIFO(I2C_LINE_INST);
    DL_I2C_flushControllerRXFIFO(I2C_LINE_INST);
    DL_I2C_resetControllerTransfer(I2C_LINE_INST);
}

static bool board_i2c_read_bytes(uint8_t device_address,
                                 uint8_t register_address,
                                 uint8_t *buffer,
                                 size_t length)
{
    size_t index;

    if ((buffer == NULL) || (length == 0U)) {
        return false;
    }

    if (!board_i2c_wait_bus_ready()) {
        board_i2c_recover();
        return false;
    }

    DL_I2C_fillControllerTXFIFO(I2C_LINE_INST, &register_address, 1U);
    DL_I2C_startControllerTransfer(
        I2C_LINE_INST, device_address, DL_I2C_CONTROLLER_DIRECTION_TX, 1U);
    board_delay_cycles(I2C_TRANSFER_DELAY_CYCLES);

    if ((!board_i2c_wait_bus_ready()) ||
        (!board_i2c_wait_idle()) ||
        board_i2c_has_error()) {
        board_i2c_recover();
        return false;
    }

    DL_I2C_flushControllerTXFIFO(I2C_LINE_INST);
    DL_I2C_startControllerTransfer(
        I2C_LINE_INST, device_address, DL_I2C_CONTROLLER_DIRECTION_RX, (uint16_t) length);

    if ((!board_i2c_wait_bus_ready()) ||
        (!board_i2c_wait_idle()) ||
        board_i2c_has_error()) {
        board_i2c_recover();
        return false;
    }

    for (index = 0U; index < length; ++index) {
        uint32_t timeout = I2C_TIMEOUT_LOOPS;

        while (DL_I2C_isControllerRXFIFOEmpty(I2C_LINE_INST)) {
            if (timeout-- == 0U) {
                board_i2c_recover();
                return false;
            }
        }

        buffer[index] = DL_I2C_receiveControllerData(I2C_LINE_INST);
    }

    return true;
}

static void pca9685_sda_out(void)
{
    DL_GPIO_initDigitalOutputFeatures(
        PCA9685_SDA_IOMUX,
        DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_DRIVE_STRENGTH_HIGH,
        DL_GPIO_HIZ_DISABLE);
    DL_GPIO_enableOutput(PCA9685_SDA_PORT, PCA9685_SDA_PIN);
}

static void pca9685_sda_in(void)
{
    DL_GPIO_disableOutput(PCA9685_SDA_PORT, PCA9685_SDA_PIN);
    DL_GPIO_initDigitalInputFeatures(
        PCA9685_SDA_IOMUX,
        DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
}

static void pca9685_scl_lo(void)
{
    DL_GPIO_clearPins(PCA9685_SCL_PORT, PCA9685_SCL_PIN);
}

static void pca9685_scl_hi(void)
{
    DL_GPIO_setPins(PCA9685_SCL_PORT, PCA9685_SCL_PIN);
}

static void pca9685_sda_lo(void)
{
    DL_GPIO_clearPins(PCA9685_SDA_PORT, PCA9685_SDA_PIN);
}

static void pca9685_sda_hi(void)
{
    DL_GPIO_setPins(PCA9685_SDA_PORT, PCA9685_SDA_PIN);
}

static bool pca9685_sda_read(void)
{
    return (DL_GPIO_readPins(PCA9685_SDA_PORT, PCA9685_SDA_PIN) != 0U);
}

static void pca9685_i2c_delay(void)
{
    for (volatile uint32_t delay = 0U; delay < 8U; delay++) {
        __asm volatile("");
    }
}

static void pca9685_i2c_start(void)
{
    pca9685_sda_out();
    pca9685_sda_hi();
    pca9685_scl_hi();
    pca9685_i2c_delay();
    pca9685_sda_lo();
    pca9685_i2c_delay();
    pca9685_scl_lo();
}

static void pca9685_i2c_stop(void)
{
    pca9685_sda_out();
    pca9685_sda_lo();
    pca9685_scl_hi();
    pca9685_i2c_delay();
    pca9685_sda_hi();
    pca9685_i2c_delay();
}

static bool pca9685_i2c_write_byte(uint8_t byte)
{
    uint8_t mask;
    bool ack;

    pca9685_sda_out();
    for (mask = 0x80U; mask != 0U; mask >>= 1U) {
        if ((byte & mask) != 0U) {
            pca9685_sda_hi();
        } else {
            pca9685_sda_lo();
        }
        pca9685_i2c_delay();
        pca9685_scl_hi();
        pca9685_i2c_delay();
        pca9685_scl_lo();
    }

    pca9685_sda_in();
    pca9685_i2c_delay();
    pca9685_scl_hi();
    pca9685_i2c_delay();
    ack = !pca9685_sda_read();
    pca9685_scl_lo();
    pca9685_sda_out();
    return ack;
}

static uint8_t pca9685_i2c_read_byte(bool ack)
{
    uint8_t value = 0U;
    uint8_t mask;

    pca9685_sda_in();
    for (mask = 0x80U; mask != 0U; mask >>= 1U) {
        pca9685_i2c_delay();
        pca9685_scl_hi();
        if (pca9685_sda_read()) {
            value |= mask;
        }
        pca9685_i2c_delay();
        pca9685_scl_lo();
    }

    pca9685_sda_out();
    if (ack) {
        pca9685_sda_lo();
    } else {
        pca9685_sda_hi();
    }
    pca9685_i2c_delay();
    pca9685_scl_hi();
    pca9685_i2c_delay();
    pca9685_scl_lo();
    pca9685_sda_hi();
    return value;
}

static bool pca9685_i2c_write_bytes(uint8_t register_address,
                                    const uint8_t *data,
                                    size_t length)
{
    size_t index;

    if ((data == NULL) || (length == 0U)) {
        return false;
    }

    pca9685_i2c_start();
    if (!pca9685_i2c_write_byte((PCA9685_DEFAULT_ADDR << 1U) | 0U) ||
        !pca9685_i2c_write_byte(register_address)) {
        pca9685_i2c_stop();
        return false;
    }

    for (index = 0U; index < length; ++index) {
        if (!pca9685_i2c_write_byte(data[index])) {
            pca9685_i2c_stop();
            return false;
        }
    }

    pca9685_i2c_stop();
    return true;
}

static bool pca9685_i2c_write_u8(uint8_t register_address, uint8_t value)
{
    return pca9685_i2c_write_bytes(register_address, &value, 1U);
}

static bool pca9685_i2c_read_u8(uint8_t register_address, uint8_t *value)
{
    if (value == NULL) {
        return false;
    }

    pca9685_i2c_start();
    if (!pca9685_i2c_write_byte((PCA9685_DEFAULT_ADDR << 1U) | 0U) ||
        !pca9685_i2c_write_byte(register_address)) {
        pca9685_i2c_stop();
        return false;
    }

    pca9685_i2c_start();
    if (!pca9685_i2c_write_byte((PCA9685_DEFAULT_ADDR << 1U) | 1U)) {
        pca9685_i2c_stop();
        return false;
    }

    *value = pca9685_i2c_read_byte(false);
    pca9685_i2c_stop();
    return true;
}

static void pca9685_i2c_init(void)
{
    DL_GPIO_initDigitalOutputFeatures(
        PCA9685_SCL_IOMUX,
        DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_DRIVE_STRENGTH_HIGH,
        DL_GPIO_HIZ_DISABLE);
    DL_GPIO_initDigitalOutputFeatures(
        PCA9685_SDA_IOMUX,
        DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_DRIVE_STRENGTH_HIGH,
        DL_GPIO_HIZ_DISABLE);
    DL_GPIO_setPins(PCA9685_SCL_PORT, PCA9685_SCL_PIN);
    DL_GPIO_setPins(PCA9685_SDA_PORT, PCA9685_SDA_PIN);
    DL_GPIO_enableOutput(PCA9685_SCL_PORT, PCA9685_SCL_PIN);
    DL_GPIO_enableOutput(PCA9685_SDA_PORT, PCA9685_SDA_PIN);
}

static uint16_t servo_us_to_ticks(uint16_t pulse_us)
{
    uint32_t ticks = ((uint32_t) pulse_us * PCA9685_TICKS_PER_PERIOD +
                      (SERVO_PERIOD_US / 2U)) /
                     SERVO_PERIOD_US;

    if (ticks > (PCA9685_TICKS_PER_PERIOD - 1U)) {
        ticks = PCA9685_TICKS_PER_PERIOD - 1U;
    }

    return (uint16_t) ticks;
}

static bool pca9685_set_pwm(uint8_t channel, uint16_t on_tick, uint16_t off_tick)
{
    uint8_t data[4];
    uint8_t reg;

    if (channel > 15U) {
        return false;
    }

    reg = (uint8_t) (PCA9685_REG_LED0_ON_L + (uint8_t) (4U * channel));
    data[0] = (uint8_t) (on_tick & 0xFFU);
    data[1] = (uint8_t) ((on_tick >> 8U) & 0x0FU);
    data[2] = (uint8_t) (off_tick & 0xFFU);
    data[3] = (uint8_t) ((off_tick >> 8U) & 0x0FU);

    return pca9685_i2c_write_bytes(reg, data, sizeof(data));
}

bool board_servo_gimbal_set_channel_us(uint8_t channel, uint16_t pulse_us)
{
    return pca9685_set_pwm(channel, 0U, servo_us_to_ticks(pulse_us));
}

bool board_servo_gimbal_set_us(uint16_t pan_us, uint16_t tilt_us)
{
    return board_servo_gimbal_set_channel_us(SERVO_CH_PAN, pan_us) &&
           board_servo_gimbal_set_channel_us(SERVO_CH_TILT, tilt_us);
}

bool board_servo_gimbal_init(void)
{
    uint8_t mode1 = 0U;
    uint8_t sleep_mode;

    pca9685_i2c_init();

    if (!pca9685_i2c_read_u8(PCA9685_REG_MODE1, &mode1)) {
        return false;
    }

    if (!pca9685_i2c_write_u8(PCA9685_REG_MODE2, PCA9685_MODE2_OUTDRV)) {
        return false;
    }

    sleep_mode = (uint8_t) ((mode1 & (uint8_t) (~PCA9685_MODE1_RESTART)) |
                            PCA9685_MODE1_SLEEP);
    if (!pca9685_i2c_write_u8(PCA9685_REG_MODE1, sleep_mode)) {
        return false;
    }

    if (!pca9685_i2c_write_u8(PCA9685_REG_PRESCALE, PCA9685_SERVO_PRESCALE_50HZ)) {
        return false;
    }

    if (!pca9685_i2c_write_u8(PCA9685_REG_MODE1, PCA9685_MODE1_AUTO_INCREMENT)) {
        return false;
    }

    board_delay_cycles(5U * APP_DELAY_CYCLES_PER_MS);

    if (!pca9685_i2c_write_u8(
            PCA9685_REG_MODE1,
            (uint8_t) (PCA9685_MODE1_RESTART | PCA9685_MODE1_AUTO_INCREMENT))) {
        return false;
    }

    board_delay_cycles(5U * APP_DELAY_CYCLES_PER_MS);

    return true;
}

static void board_motor_direction(GPIO_Regs *port,
                                  uint32_t pin_in1,
                                  uint32_t pin_in2,
                                  int16_t pwm_value)
{
    if (pwm_value > 0) {
        DL_GPIO_setPins(port, pin_in1);
        DL_GPIO_clearPins(port, pin_in2);
    } else if (pwm_value < 0) {
        DL_GPIO_clearPins(port, pin_in1);
        DL_GPIO_setPins(port, pin_in2);
    } else {
        DL_GPIO_clearPins(port, pin_in1 | pin_in2);
    }
}

void board_init(void)
{
    g_debug_rx_head = 0U;
    g_debug_rx_tail = 0U;
    g_debug_rx_overflow = 0U;
    g_imu_rx_head = 0U;
    g_imu_rx_tail = 0U;
    g_imu_rx_overflow = 0U;
    g_buzzer_ticks_remaining = 0U;
    board_set_buzzer_active(false);
    DL_GPIO_initDigitalOutput(LASER_RELAY_IOMUX);
    board_set_laser_power(false);
    DL_GPIO_enableOutput(LASER_RELAY_PORT, LASER_RELAY_PIN);

    g_right_encoder_prev_state = board_read_right_encoder_state();
    DL_GPIO_clearInterruptStatus(
        GPIO_ENCODER_RIGHT_PORT,
        GPIO_ENCODER_RIGHT_PHA_PIN | GPIO_ENCODER_RIGHT_PHB_PIN);
    NVIC_ClearPendingIRQ(GPIO_ENCODER_RIGHT_INT_IRQN);
    NVIC_EnableIRQ(GPIO_ENCODER_RIGHT_INT_IRQN);

    DL_TimerA_setCaptureCompareValue(PWM_LEFT_INST, 0U, GPIO_PWM_LEFT_C0_IDX);
    DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, 0U, GPIO_PWM_RIGHT_C0_IDX);
    DL_TimerA_startCounter(PWM_LEFT_INST);
    DL_TimerG_startCounter(PWM_RIGHT_INST);
    DL_TimerG_startCounter(QEI_LEFT_INST);

    DL_UART_Main_enableInterrupt(UART_DEBUG_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_ClearPendingIRQ(UART_DEBUG_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_DEBUG_INST_INT_IRQN);

    DL_UART_Main_enableInterrupt(UART_IMU_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_ClearPendingIRQ(UART_IMU_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_IMU_INST_INT_IRQN);
}

void board_debug_write(const char *text)
{
    while (*text != '\0') {
        DL_UART_Main_transmitDataBlocking(UART_DEBUG_INST, (uint8_t) *text);
        ++text;
    }
}

size_t board_read_debug_bytes(uint8_t *buffer, size_t capacity)
{
    size_t count = 0U;

    while ((count < capacity) && (g_debug_rx_tail != g_debug_rx_head)) {
        buffer[count++] = g_debug_rx_ring[g_debug_rx_tail];
        g_debug_rx_tail = (uint16_t) ((g_debug_rx_tail + 1U) & DEBUG_RX_RING_MASK);
    }

    return count;
}

uint32_t board_read_button_mask(void)
{
    const uint32_t pin_state = DL_GPIO_readPins(
        GPIO_KEYS_PORT,
        GPIO_KEYS_MODE_1_PIN | GPIO_KEYS_MODE_2_PIN |
        GPIO_KEYS_MODE_3_PIN | GPIO_KEYS_START_PIN);
    uint32_t button_mask = 0U;

    if ((pin_state & GPIO_KEYS_MODE_1_PIN) == 0U) {
        button_mask |= BUTTON_MODE_1;
    }
    if ((pin_state & GPIO_KEYS_MODE_2_PIN) == 0U) {
        button_mask |= BUTTON_MODE_2;
    }
    if ((pin_state & GPIO_KEYS_MODE_3_PIN) == 0U) {
        button_mask |= BUTTON_MODE_3;
    }
    if ((pin_state & GPIO_KEYS_START_PIN) == 0U) {
        button_mask |= BUTTON_START;
    }

    return button_mask;
}

bool board_line_sensor_read(line_sensor_sample_t *sample)
{
    static const int16_t weights[8] = {
        -3500, -2500, -1500, -500, 500, 1500, 2500, 3500
    };
    uint8_t analog_raw[8];
    uint8_t ping_value = 0U;
    uint8_t digital_raw = 0U;
    int32_t weighted_sum = 0;
    uint8_t active_count = 0U;
    uint8_t index;

    memset(sample, 0, sizeof(*sample));

    if (!board_i2c_read_bytes(
            LINE_SENSOR_I2C_ADDR, LINE_SENSOR_REG_PING, &ping_value, 1U) ||
        (ping_value != LINE_SENSOR_PING_OK)) {
        return false;
    }

    if (!board_i2c_read_bytes(
            LINE_SENSOR_I2C_ADDR, LINE_SENSOR_REG_DIGITAL, &digital_raw, 1U)) {
        return false;
    }

    sample->online = true;
    sample->digital_raw = digital_raw;
    /* This module reports white/background as 1 and black line as 0. Invert it
       so the application tracks black-line hits directly. */
    sample->digital_active_mask = (uint8_t) (~digital_raw);

    if (!board_i2c_read_bytes(
            LINE_SENSOR_I2C_ADDR,
            LINE_SENSOR_REG_ANALOG_BASE,
            analog_raw,
            8U)) {
        memset(sample->analog, 0, sizeof(sample->analog));
    } else {
        for (index = 0U; index < 8U; ++index) {
            sample->analog[index] = analog_raw[index];
        }
    }

    for (index = 0U; index < 8U; ++index) {
        if ((sample->digital_active_mask & (uint8_t) (1U << index)) != 0U) {
            weighted_sum += weights[index];
            active_count++;
        }

        if (sample->analog[index] > sample->max_value) {
            sample->max_value = (uint8_t) sample->analog[index];
            sample->max_index = index;
        }
    }

    sample->active_count = active_count;
    if (active_count > 0U) {
        sample->line_error = (int16_t) (weighted_sum / (int32_t) active_count);
    }

    return true;
}

encoder_sample_t board_read_encoder(void)
{
    static bool initialized = false;
    static uint16_t previous_left_raw = 0U;
    static int32_t previous_right_total = 0;
    static int32_t left_total = 0;
    static int32_t right_total = 0;
    encoder_sample_t sample;
    uint16_t left_raw;
    int32_t right_raw;
    int16_t left_delta;
    int16_t right_delta;

    memset(&sample, 0, sizeof(sample));
    left_raw = (uint16_t) DL_Timer_getTimerCount(QEI_LEFT_INST);
    right_raw = g_right_encoder_count;

    if (!initialized) {
        previous_left_raw = left_raw;
        previous_right_total = right_raw;
        initialized = true;
    }

    left_delta = (int16_t) (left_raw - previous_left_raw);
    right_delta = (int16_t) (right_raw - previous_right_total);
    previous_left_raw = left_raw;
    previous_right_total = right_raw;

    left_total += (int32_t) left_delta * LEFT_ENCODER_SIGN;
    right_total += (int32_t) right_delta * RIGHT_ENCODER_SIGN;
    sample.left_total_count = left_total;
    sample.right_total_count = right_total;
    sample.left_speed_pps = (int16_t) (
        left_delta * (int16_t) APP_CONTROL_HZ * (int16_t) LEFT_ENCODER_SIGN);
    sample.right_speed_pps = (int16_t) (
        right_delta * (int16_t) APP_CONTROL_HZ * (int16_t) RIGHT_ENCODER_SIGN);

    return sample;
}

size_t board_read_imu_bytes(uint8_t *buffer, size_t capacity)
{
    size_t count = 0U;

    while ((count < capacity) && (g_imu_rx_tail != g_imu_rx_head)) {
        buffer[count++] = g_imu_rx_ring[g_imu_rx_tail];
        g_imu_rx_tail = (uint16_t) ((g_imu_rx_tail + 1U) & IMU_RX_RING_MASK);
    }

    return count;
}

void board_apply_motor_command(const motor_command_t *command)
{
    const uint16_t left_pwm = (uint16_t) abs_i16(
        clamp_i16(command->left_pwm, -MOTOR_PWM_LIMIT, MOTOR_PWM_LIMIT));
    const uint16_t right_pwm = (uint16_t) abs_i16(
        clamp_i16(command->right_pwm, -MOTOR_PWM_LIMIT, MOTOR_PWM_LIMIT));
    const uint16_t left_compare = (left_pwm == 0U) ? 0U : (uint16_t) (MOTOR_PWM_LIMIT - left_pwm);
    const uint16_t right_compare = (right_pwm == 0U) ? 0U : (uint16_t) (MOTOR_PWM_LIMIT - right_pwm);

    board_motor_direction(
        GPIO_MOTOR_LEFT_DIR_PORT,
        GPIO_MOTOR_LEFT_DIR_AIN1_PIN,
        GPIO_MOTOR_LEFT_DIR_AIN2_PIN,
        command->left_pwm);
    board_motor_direction(
        GPIO_MOTOR_RIGHT_DIR_PORT,
        GPIO_MOTOR_RIGHT_DIR_BIN1_PIN,
        GPIO_MOTOR_RIGHT_DIR_BIN2_PIN,
        command->right_pwm);

    DL_TimerA_setCaptureCompareValue(PWM_LEFT_INST, left_compare, GPIO_PWM_LEFT_C0_IDX);
    DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, right_compare, GPIO_PWM_RIGHT_C0_IDX);
}

void board_set_led(bool enabled)
{
    if (enabled) {
        DL_GPIO_setPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_STATUS_LED_PIN);
    } else {
        DL_GPIO_clearPins(GPIO_INDICATORS_PORT, GPIO_INDICATORS_STATUS_LED_PIN);
    }
}

void board_set_laser_power(bool enabled)
{
#if LASER_RELAY_ACTIVE_HIGH
    if (enabled) {
        DL_GPIO_setPins(LASER_RELAY_PORT, LASER_RELAY_PIN);
    } else {
        DL_GPIO_clearPins(LASER_RELAY_PORT, LASER_RELAY_PIN);
    }
#else
    if (enabled) {
        DL_GPIO_clearPins(LASER_RELAY_PORT, LASER_RELAY_PIN);
    } else {
        DL_GPIO_setPins(LASER_RELAY_PORT, LASER_RELAY_PIN);
    }
#endif
}

void board_beep(uint16_t frequency_hz, uint16_t duration_ms)
{
    (void) frequency_hz;

    if (duration_ms == 0U) {
        g_buzzer_ticks_remaining = 0U;
        board_set_buzzer_active(false);
        return;
    }

    g_buzzer_ticks_remaining =
        (uint16_t) (((uint32_t) duration_ms * BOARD_BEEP_SERVICE_HZ + 999U) / 1000U);
    if (g_buzzer_ticks_remaining == 0U) {
        g_buzzer_ticks_remaining = 1U;
    }
    board_set_buzzer_active(true);
}

void board_beep_service(void)
{
    if (g_buzzer_ticks_remaining == 0U) {
        return;
    }

    g_buzzer_ticks_remaining--;
    if (g_buzzer_ticks_remaining == 0U) {
        board_set_buzzer_active(false);
    }
}

void GROUP1_IRQHandler(void)
{
    switch (DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1)) {
        case GPIO_ENCODER_RIGHT_INT_IIDX:
        {
            const uint32_t pending = DL_GPIO_getEnabledInterruptStatus(
                GPIO_ENCODER_RIGHT_PORT,
                GPIO_ENCODER_RIGHT_PHA_PIN | GPIO_ENCODER_RIGHT_PHB_PIN);

            if ((pending & (GPIO_ENCODER_RIGHT_PHA_PIN | GPIO_ENCODER_RIGHT_PHB_PIN)) != 0U) {
                const uint8_t current_state = board_read_right_encoder_state();
                g_right_encoder_count += board_quadrature_step(
                    g_right_encoder_prev_state, current_state);
                g_right_encoder_prev_state = current_state;
                DL_GPIO_clearInterruptStatus(GPIO_ENCODER_RIGHT_PORT, pending);
            }
            break;
        }
        default:
            break;
    }
}

void UART1_IRQHandler(void)
{
    switch (DL_UART_Main_getPendingInterrupt(UART_IMU_INST)) {
        case DL_UART_MAIN_IIDX_RX:
            while (!DL_UART_Main_isRXFIFOEmpty(UART_IMU_INST)) {
                uint16_t next_head;
                uint8_t byte = DL_UART_Main_receiveData(UART_IMU_INST);

                next_head = (uint16_t) ((g_imu_rx_head + 1U) & IMU_RX_RING_MASK);
                if (next_head == g_imu_rx_tail) {
                    g_imu_rx_tail = (uint16_t) ((g_imu_rx_tail + 1U) & IMU_RX_RING_MASK);
                    g_imu_rx_overflow++;
                }

                g_imu_rx_ring[g_imu_rx_head] = byte;
                g_imu_rx_head = next_head;
            }
            break;

        default:
            break;
    }
}

void UART0_IRQHandler(void)
{
    switch (DL_UART_Main_getPendingInterrupt(UART_DEBUG_INST)) {
        case DL_UART_MAIN_IIDX_RX:
            while (!DL_UART_Main_isRXFIFOEmpty(UART_DEBUG_INST)) {
                uint16_t next_head;
                uint8_t byte = DL_UART_Main_receiveData(UART_DEBUG_INST);

                next_head = (uint16_t) ((g_debug_rx_head + 1U) & DEBUG_RX_RING_MASK);
                if (next_head == g_debug_rx_tail) {
                    g_debug_rx_tail = (uint16_t) ((g_debug_rx_tail + 1U) & DEBUG_RX_RING_MASK);
                    g_debug_rx_overflow++;
                }

                g_debug_rx_ring[g_debug_rx_head] = byte;
                g_debug_rx_head = next_head;
            }
            break;

        default:
            break;
    }
}
