#ifndef BOARD_CONFIG_H_
#define BOARD_CONFIG_H_

/*
 * 默认接线方案基于：
 * 1. 天猛星 MSPM0G3507 官方教程中已验证的 TB6612 / 编码器 / 串口资源
 * 2. 感为八路巡线模块使用 I2C 模式，节省 GPIO
 * 3. 三个独立按键用于三种校赛模式，板载 B21 作为启动/暂停按键
 */

#define PIN_DEBUG_UART_TX        "PA10" /* 调试串口 TX，接 ESP32/USB-TTL RX。换线只改字符串说明，实际外设还需在 SysConfig 同步。 */
#define PIN_DEBUG_UART_RX        "PA11" /* 调试串口 RX，接 ESP32/USB-TTL TX。接反会只能发不能收或完全无通信。 */

#define PIN_IMU_UART_TX          "PA8"  /* JY901 串口 TX。换线需同步 SysConfig UART1 TX。 */
#define PIN_IMU_UART_RX          "PA9"  /* JY901 串口 RX。换线需同步 SysConfig UART1 RX。 */

#define PIN_I2C_SDA              "PA0"  /* 巡线模块硬件 I2C SDA。换线需同步 SysConfig I2C0。 */
#define PIN_I2C_SCL              "PA1"  /* 巡线模块硬件 I2C SCL。换线需同步 SysConfig I2C0。 */
#define PIN_PCA9685_SDA          "PB0"  /* PCA9685 云台软件 I2C SDA。换线需同步 board.c 的 PCA9685_SDA_*。 */
#define PIN_PCA9685_SCL          "PB1"  /* PCA9685 云台软件 I2C SCL。换线需同步 board.c 的 PCA9685_SCL_*。 */
#define PIN_LINE_I2C_SDA         PIN_I2C_SDA /* 巡线 SDA 复用主 I2C SDA。改 PIN_I2C_SDA 会一起变化。 */
#define PIN_LINE_I2C_SCL         PIN_I2C_SCL /* 巡线 SCL 复用主 I2C SCL。改 PIN_I2C_SCL 会一起变化。 */

#define PIN_OLED_SDA             "PB10" /* OLED 软件 I2C SDA。换线需同步 oled.c 的 I2C_SDA_*。 */
#define PIN_OLED_SCL             "PB11" /* OLED 软件 I2C SCL。换线需同步 oled.c 的 I2C_SCL_*。 */

#define PIN_TB6612_PWMA          "PA15" /* TB6612 左轮 PWM。换线需同步 SysConfig PWM_LEFT。 */
#define PIN_TB6612_AIN1          "PA14" /* TB6612 左轮方向 1。若电机反转，优先换 AIN1/AIN2 或改方向逻辑。 */
#define PIN_TB6612_AIN2          "PA16" /* TB6612 左轮方向 2。若电机反转，优先换 AIN1/AIN2 或改方向逻辑。 */
#define PIN_TB6612_PWMB          "PA17" /* TB6612 右轮 PWM。换线需同步 SysConfig PWM_RIGHT。 */
#define PIN_TB6612_BIN1          "PA12" /* TB6612 右轮方向 1。若电机反转，优先换 BIN1/BIN2 或改方向逻辑。 */
#define PIN_TB6612_BIN2          "PA13" /* TB6612 右轮方向 2。若电机反转，优先换 BIN1/BIN2 或改方向逻辑。 */
#define PIN_TB6612_STBY          "3.3V" /* TB6612 待机脚当前常接高电平。若改 GPIO 控制，需新增驱动逻辑。 */

#define PIN_ENCODER_LEFT_A       "PA29" /* 左编码器 A 相，当前硬件 QEI。换线需同步 SysConfig QEI_LEFT。 */
#define PIN_ENCODER_LEFT_B       "PA30" /* 左编码器 B 相，当前硬件 QEI。AB 对调会反转计数方向。 */
#define PIN_ENCODER_RIGHT_A      "PA26" /* 右编码器 A 相，当前 GPIO 中断软件解码。换线需同步 SysConfig GPIO。 */
#define PIN_ENCODER_RIGHT_B      "PA27" /* 右编码器 B 相，当前 GPIO 中断软件解码。AB 对调会反转计数方向。 */

#define PIN_KEY_MODE_1           "PB13" /* 模式 1 选择键。换线需同步 SysConfig GPIO_KEYS。 */
#define PIN_KEY_MODE_2           "PB15" /* 模式 2 选择键。换线需同步 SysConfig GPIO_KEYS。 */
#define PIN_KEY_MODE_3           "PB16" /* 模式 3/圈数选择键。换线需同步 SysConfig GPIO_KEYS。 */
#define PIN_KEY_START            "PB21" /* 启动/停止键。换线需同步 SysConfig GPIO_KEYS。 */

#define PIN_STATUS_LED           "PB22" /* 状态 LED 引脚。换线需同步 SysConfig GPIO_INDICATORS。 */
#define PIN_BUZZER               "PB23" /* 蜂鸣器引脚。有效电平由 board.c 的 BUZZER_ACTIVE_LOW 决定。 */
#define PIN_LASER_RELAY         "PA22" /* 激光/瞄准模块继电器 IN。当前模块低电平吸合；若换线需同步 board.c 的 LASER_RELAY_*。 */

#define PIN_RESERVED_BSL         "PA18" /* BSL/保留脚，避免随意占用，防止影响下载/启动相关功能。 */

#endif /* BOARD_CONFIG_H_ */
