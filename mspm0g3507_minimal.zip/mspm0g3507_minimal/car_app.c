#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "car_app.h"
#include "board.h"
#include "gimbal_servo.h"
#include "jy901.h"
#include "k230_protocol.h"
#include "oled.h"

#define MODE3_LOOP_MIN 1U                 /* 阶段三最小圈数。调大后不能选择更少圈；通常不建议改，避免题目 1 圈测试不可用。 */
#define MODE3_LOOP_MAX 3U                 /* 阶段三最大圈数。调大需要同步数组容量、按键逻辑和评分需求；调小会禁用后续圈参数。 */
#define DEBUG_PRINT_MS_DEFAULT 50U        /* 默认 CARLOG 输出周期，单位 ms。调大日志更稀疏、串口负担小；调小日志更密但可能占用调试串口时间。 */
#define DEBUG_PRINT_MS_MIN 50U            /* PARAM,LOGMS 允许的最小日志周期。调小可看更细动态，但串口更容易刷屏。 */
#define DEBUG_PRINT_MS_MAX 5000U          /* PARAM,LOGMS 允许的最大日志周期。调大日志更少；调小限制现场误设过慢日志。 */
#define DEBUG_PRINT_DIVIDER ((APP_CONTROL_HZ * DEBUG_PRINT_MS_DEFAULT) / 1000U) /* 默认日志周期换算成控制 tick。随 APP_CONTROL_HZ 和 DEBUG_PRINT_MS_DEFAULT 自动变化。 */
#define SERIAL_PERIODIC_LOG_ENABLED 0U    /* 串口周期 CARLOG 开关。设 0 时不主动刷运行日志，只保留口令响应；设 1 恢复周期日志。 */
#define SERIAL_EVENT_LOG_ENABLED 0U       /* 串口事件日志开关。设 0 时按键/自动启动不主动输出 CAR_EVT；设 1 恢复事件提示。 */
#define SERIAL_K230_MODE_OUTPUT_ENABLED 1U /* K230 模式主动发送开关。设 1 时仅在模式变化时发 MODE,xxx，不恢复周期日志。 */
#define OLED_REFRESH_DIVIDER (APP_CONTROL_HZ / 5U) /* OLED 刷新分频，当前约 5Hz。调大刷新更慢更省时；调小刷新更快但占用更多 I2C/CPU。 */
#define APP_BEEP_FULL_VOLUME_HZ 2400U     /* 蜂鸣器统一满响度提示频率。GPIO 直驱下实际为满电平驱动，所有响点保持一致。 */
#define BUTTON_DEBOUNCE_TICKS 8U          /* 按键去抖 tick 数。调大更抗抖但响应变慢；调小响应快但容易误触发。 */
#define BUTTON_LONG_PRESS_TICKS 120U      /* 模式键长按 tick 数，约 0.6s。长按模式 1/2/3 进入发挥 1/2/3。 */
#define PUSH_CAPTURE_NO_MOTOR 0U          /* 推车采集模式开关。设 1 时状态机可跑但电机不输出；设 0 为正常上车驱动。 */
#define AUTO_START_MODE1_ON_BOOT 0U       /* 上电自动启动模式 1。设 1 会跳过手动启动，适合固定测试；设 0 更安全。 */
#define OPEN_LEG_REACQUIRE_MIN_PERCENT 85 /* 开环直线路段允许重新识别线的最小进度百分比。调大更晚切段、不易误判；调小更早切段但可能误识别。 */
#define OPEN_LEG_REACQUIRE_CONFIRM_TICKS 1U /* 开环段重新看到线后的确认 tick。调大更稳但切段变晚；调小更灵敏但抗干扰差。 */
#define OPEN_LEG_MAX_OVERRUN_PERCENT 120  /* 开环直线路段最大超程百分比。调大允许多跑避免过早切段；调小更早强制切段但可能没到目标。 */
#define LINE_LEG_MAX_OVERRUN_PERCENT 170  /* 巡线路段最大超程百分比。调大允许弧线/直线多跑；调小更早保护切段但可能漏到点。 */
#define MODE1_AB_LINE_CONFIRM_TICKS 10U   /* 模式 1 A-B 后半段重新遇线确认 tick。调大更抗误触发但到 B 变晚；调小更快进入 B 事件。 */
#define MODE1_AB_LINE_FLOOR_PERCENT 65    /* 模式 1 A-B 至少走完该百分比后才允许遇线切到 B。调大更不易早判；调小更容易提前停车。 */
#define MODE1_BC_EXIT_MIN_COUNTS 3600     /* 模式 1 B-C 弧线允许出弧的最小编码器计数。调大更晚离开弧线；调小可能提前结束 B-C。 */
#define MODE1_BC_LINE_LOST_CONFIRM_TICKS 80U /* 模式 1 B-C 丢线确认 tick。调大丢线后继续保持更久；调小更快认为弧线结束。 */
#define MODE1_AB_TARGET_COUNTS 6600       /* 模式 1 A-B 编码器目标计数。调大 A-B 跑更远；调小 A-B 更早结束。 */
#define MODE1_BC_TARGET_COUNTS 8200       /* 模式 1 B-C 编码器目标计数。调大 B-C 跑更远；调小 B-C 更早结束。 */
#define MODE1_BASE_SPEED_PPS 1450         /* 阶段一基础速度，单位 pps。加云台后调大提高带载能力；过大容易冲过节点。 */
#define MODE2_BASE_SPEED_PPS 1450         /* 阶段二基础速度，单位 pps。加云台后调大提高带载能力；过大容易冲线。 */
#define MODE3_BASE_SPEED_PPS 1200         /* 阶段三基础速度，单位 pps。加云台后调大避免对角线/弧线发软；过大容易切段过冲。 */
#define ADV_ROUTE2_BASE_SPEED_PPS 950     /* 发挥 2 带云台追踪时的基础速度。调小给舵机更多追踪时间；调大整车更快但容易丢靶。 */
#define ADV_ROUTE3_BASE_SPEED_PPS 850     /* 发挥 3 带云台追踪时的基础速度。调小给舵机更多追踪时间；调大整车更快但容易丢靶。 */
#define LINE_TRACK_BASE_SPEED_BOOST_PPS 600 /* 巡线段基础速度额外增量，单位 pps。当前会把阶段一/二/三巡线段顶到单轮速度上限。 */
#define LINE_TURN_KP_NUM 56U              /* 巡线转向比例分子。重云台转不动时调大，让内外轮差速更快打满。 */
#define LINE_TURN_KP_DEN 14U              /* 巡线转向比例分母。调小转向更猛；调大转向更柔。 */
#define LINE_TURN_KD_NUM 10U              /* 巡线转向微分分子。高速巡线时调大用于压摆、减少冲线。 */
#define LINE_TURN_KD_DEN 1U               /* 巡线转向微分分母。调小微分更强；调大更柔。 */
#define LINE_TURN_OUTPUT_LIMIT_PPS 3600   /* 巡线转向输出限幅，单位 pps。目标轮速下限为 0，不做电机反转。 */
#define HEAVY_GIMBAL_MIN_EFFECTIVE_PWM 1000 /* 重云台下电机最低有效 PWM。调大低速/反转更有力；过大起步会冲。 */
#define MODE3_DIAGONAL_LINE_FLOOR_PERCENT 85 /* 阶段三对角线至少走完该百分比后才允许遇线切段。调大更晚切到弧线；调小更容易提前切段。 */
#define MODE3_DIAGONAL_MAX_OVERRUN_PERCENT 110 /* 阶段三对角线最大超程百分比。调大允许多跑找线；调小更早强制切段。 */
#define MODE3_DIAGONAL_LINE_ACTIVE_MIN 1U /* 阶段三对角线末端认为“看到线”的最少有效探头数。调大更抗噪但不易确认；调小更灵敏但易误判。 */
#define MODE3_DIAGONAL_HEADING_NUM 3      /* 阶段三默认对角线理论角缩放分子。调大默认 AC/BD 角度绝对值变大；调小默认角度更接近 0。 */
#define MODE3_DIAGONAL_HEADING_DEN 19     /* 阶段三默认对角线理论角缩放分母。调大默认 AC/BD 角度绝对值变小；调小默认角度更大。 */
#define MODE2_CD_HEADING_TRIM_X10 -330    /* 阶段二 C-D 直线默认角度补偿，单位 0.1 度。更负通常向一侧修，增大则向反侧修，最终以 hdg 日志确认。 */
#define MODE3_AC_LOOP1_HEADING_X10 -415   /* 阶段三第 1 圈 A-C 默认目标角，单位 0.1 度。对应 M3DIAG,1,AC=-415,BD=735。 */
#define MODE3_BD_LOOP1_HEADING_X10 +735   /* 阶段三第 1 圈 B-D 默认目标角，单位 0.1 度。对应 M3DIAG,1,AC=-415,BD=735。 */
#define MODE3_AC_LOOP2_HEADING_X10 -715    /* 阶段三第 2 圈 A-C 默认目标角，单位 0.1 度。对应 M3DIAG,2,AC=-715,BD=740。 */
#define MODE3_BD_LOOP2_HEADING_X10 +740   /* 阶段三第 2 圈 B-D 默认目标角，单位 0.1 度。对应 M3DIAG,2,AC=-715,BD=740。 */
#define MODE3_AC_LOOP3_HEADING_X10 -700    /* 阶段三第 3 圈 A-C 默认目标角，单位 0.1 度。对应 M3DIAG,3,AC=-700,BD=745。 */
#define MODE3_BD_LOOP3_HEADING_X10 +745   /* 阶段三第 3 圈 B-D 默认目标角，单位 0.1 度。对应 M3DIAG,3,AC=-700,BD=745。 */
#define MODE1_AB_YAW_COMP_END_X10 0       /* 模式 1 A-B 末端渐变航向补偿，单位 0.1 度。调大末端目标角更正；调小末端目标角更负。 */
#define MODE1_PREAIM_START_COUNTS 6500    /* 模式 1 A-B 预瞄开始计数。调大更晚进入预瞄；调小更早加预瞄角。 */
#define MODE1_PREAIM_HEADING_X10 0        /* 模式 1 预瞄附加角，单位 0.1 度。调大目标角更正；调小目标角更负。 */
#define MODE1_ARC_FEEDFORWARD_PPS -2200   /* 弧线巡线前馈转向，单位 pps。绝对值调大转弯更猛；绝对值调小弧线更柔，符号反了会反向帮偏。 */
#define LINE_TRANSITION_BLEND_TICKS 4U    /* 进入巡线后的转向混合 tick。调大开环/巡线过渡更柔；调小更快完全交给巡线。 */
#define ARC_ENTRY_COUNTS 1600             /* 弧线入口特殊限速/限转持续计数。调大入口保护更久；调小更快恢复正常巡线。 */
#define ARC_ENTRY_STEER_LIMIT_PPS 3600    /* 弧线入口转向项限幅。允许入口阶段打出超过基础速度的差速。 */
#define ARC_ENTRY_TARGET_SLEW_PPS 600     /* 弧线入口目标速度每 tick 最大变化。调大响应更快但冲击更大；调小更平滑但跟随慢。 */
#define YAW_ZERO_OFFSET_DEG_X10 0         /* 启动时航向零点偏置，单位 0.1 度。调大整体目标角更正；调小整体目标角更负。 */
#define ECG_CYCLE_COUNT 3U                /* 发挥 1 心电图周期数。赛题至少 3 个波峰，保持 3 个完整周期。 */
#define ECG_CYCLE_X 1000U                 /* 单个心电周期的归一化横向坐标。 */
#define ECG_TOTAL_X (ECG_CYCLE_COUNT * ECG_CYCLE_X) /* 心电图总横向坐标。 */
#define ECG_TOTAL_TIME_MS 15000U          /* 心电图绘制总时间，15s，小于赛题 18s 限制。 */
#define ECG_SETTLE_MS 500U                /* 移动到心电图起点后等待舵机稳定的时间。 */
#define ECG_UPDATE_TICKS ((APP_CONTROL_HZ * 20U) / 1000U) /* 心电图舵机更新周期，约 20ms。 */
#define ECG_START_LEFT_OFFSET_PX 120      /* 发挥 1 起点相对矩形中心向左平移的像素。调大起点更靠左；调小更靠近中心。 */
#define ECG_BASELINE_Y_OFFSET_PX 0        /* 发挥 1 基线相对矩形中心的纵向像素偏移。正数向下，负数向上。 */
#define ECG_LOCATE_PIXELS_PER_STEP 7      /* 保留的像素步进参考值；当前 ECG 定位实际由 MSPM0 云台 PD 参数控制。 */
#define ECG_LOCATE_MAX_STEP_US 10         /* 发挥 1 定位阶段单次最大云台修正，过大易抖，过小定位慢。 */
#define GIMBAL_AIM_PID_KP_NUM 1           /* 发挥 2/3 AIM 云台追踪 P 项分子，由 MSPM0 根据 K230 视觉误差控制舵机。 */
#define GIMBAL_AIM_PID_KP_DEN 5           /* 发挥 2/3 AIM 云台追踪 P 项分母，调大响应变柔，调小响应变猛。 */
#define GIMBAL_AIM_PID_KD_NUM 1           /* 发挥 2/3 AIM 云台追踪 D 项分子，用于抑制追踪过冲。 */
#define GIMBAL_AIM_PID_KD_DEN 14          /* 发挥 2/3 AIM 云台追踪 D 项分母，调大微分更弱，调小更强。 */
#define GIMBAL_AIM_MAX_STEP_US 14         /* 发挥 2/3 AIM 单次云台修正限幅，避免视觉噪声导致舵机大跳。 */
#define GIMBAL_AIM_DEADBAND_PX 4          /* 发挥 2/3 AIM 追踪死区，误差小于该像素时不再修正。 */
#define GIMBAL_AIM_SEARCH_START_TICKS 20U /* 发挥 2/3 丢矩形后延迟多少控制 tick 开始搜索，避免单帧抖动触发扫描。 */
#define GIMBAL_AIM_SEARCH_UPDATE_TICKS 8U /* 发挥 2/3 丢矩形搜索更新间隔。200Hz 下 8 tick 约 40ms，避免扫得过快。 */
#define GIMBAL_AIM_SEARCH_PAN_STEP_US 2   /* 发挥 2/3 丢矩形搜索水平单步，围绕最后看到矩形的姿态慢速扫描。 */
#define GIMBAL_AIM_SEARCH_TILT_STEP_US 1  /* 发挥 2/3 丢矩形搜索俯仰单步，仅在水平换向时叠加。 */
#define GIMBAL_AIM_SEARCH_PAN_LIMIT_US 140 /* 发挥 2/3 丢矩形搜索水平半幅，相对最后看到矩形的姿态左右扫描。 */
#define GIMBAL_AIM_SEARCH_TILT_LIMIT_US 50 /* 发挥 2/3 丢矩形搜索俯仰半幅，相对最后看到矩形的姿态上下扫描。 */
#define GIMBAL_AIM_PRED_PAN_GAIN_US_PER_DEG_X10 1 /* 丢靶预测水平增益分子，实际增益为该值/GAIN_DEN us/0.1deg。 */
#define GIMBAL_AIM_PRED_TILT_GAIN_US_PER_DEG_X10 0 /* 丢靶预测俯仰增益分子。相机约 30cm、靶心约 25cm 时先保持 0，现场需要再调。 */
#define GIMBAL_AIM_PRED_GAIN_DEN 2        /* 丢靶预测角度到舵机脉宽的增益分母。默认水平约 0.5us/0.1deg，避免一丢靶就打满。 */
#define GIMBAL_AIM_PRED_BLEND_PERCENT 45  /* 丢靶搜索锚点中路段几何预测占比。0 只用最后位置，100 只用理论位置。 */
#define GIMBAL_AIM_PRED_WINDOW_PAN_US 70  /* 丢靶时在预测锚点附近搜索的水平半幅。调大覆盖更宽，调小更稳更慢。 */
#define GIMBAL_AIM_PRED_WINDOW_TILT_US 24 /* 丢靶时在预测锚点附近搜索的俯仰半幅。相机离地约 30cm 时先小范围补偿。 */
#define GIMBAL_AIM_PRED_SETTLE_STEP_US 5  /* 丢靶后锚点每次更新最大靠近步长，限制预测姿态突跳。 */
#define GIMBAL_AIM_PRED_PAN_BIAS_US 0     /* 丢靶预测水平整体偏置。现场若预测窗口总在靶子左/右侧，用它平移。 */
#define GIMBAL_AIM_PRED_TILT_BIAS_US 0    /* 丢靶预测俯仰整体偏置。现场若预测窗口总偏高/低，用它平移。 */
#define GIMBAL_AIM_ROUTE2_AB_START_X10 450  /* 发挥 2 AB 段起点相对车头看靶水平角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE2_AB_END_X10 1350   /* 发挥 2 AB 段终点相对车头看靶水平角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE2_BC_START_X10 1350 /* 发挥 2 BC 弧线起点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE2_BC_END_X10 -690   /* 发挥 2 BC 弧线终点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE2_CD_START_X10 -690 /* 发挥 2 CD 段起点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE2_CD_END_X10 -1110  /* 发挥 2 CD 段终点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE2_DA_START_X10 -1110 /* 发挥 2 DA 弧线起点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE2_DA_END_X10 450    /* 发挥 2 DA 弧线终点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_AC_START_X10 837  /* 发挥 3 AC 段起点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_AC_END_X10 1497   /* 发挥 3 AC 段终点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_CB_START_X10 -450 /* 发挥 3 CB 弧线起点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_CB_END_X10 1110   /* 发挥 3 CB 弧线终点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_BD_START_X10 -1497 /* 发挥 3 BD 段起点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_BD_END_X10 -837   /* 发挥 3 BD 段终点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_DA_START_X10 -1110 /* 发挥 3 DA 弧线起点预测角，单位 0.1 度。 */
#define GIMBAL_AIM_ROUTE3_DA_END_X10 450    /* 发挥 3 DA 弧线终点预测角，单位 0.1 度。 */
#define ECG_LOCATE_PAN_REVERSE 0U         /* 发挥 1 水平定位方向反向。当前与 AIM 实测方向一致，若远离左侧起点则改成 1。 */
#define GIMBAL_AIM_PAN_REVERSE 0U         /* 发挥 2/3 AIM 水平追踪方向反向。若激光远离靶心，改成 0/1 互换。 */
#define GIMBAL_AIM_TILT_REVERSE 0U        /* 发挥 2/3 AIM 俯仰追踪方向反向。若上下越追越远，改成 1。 */
#define ECG_LOCATE_DEADBAND_PX 6          /* 激光到 ECG 起点的允许像素误差。调大更快开始画，调小起点更准。 */
#define ECG_LOCATE_CONFIRM_UPDATES 3U     /* 连续多少次 K230 目标更新都在死区内才确认起点。 */
#define ECG_MOUNT_PAN_US 1700U            /* 发挥 1 上车初始水平脉宽。机械中位不是 1500 时，优先调这里。 */
#define ECG_MOUNT_TILT_US 1550U           /* 发挥 1 上车初始俯仰脉宽。机械中位不是 1500 时，优先调这里。 */
#define ECG_LEFT_PAN_US 1540U             /* 心电图左端水平舵机脉宽。与右端差值越小，左右波动越小。 */
#define ECG_RIGHT_PAN_US 1460U            /* 心电图右端水平舵机脉宽。与左端差值越小，左右波动越小。 */
#define ECG_BASE_TILT_US 1500U            /* 心电图基线俯仰脉宽。 */
#define ECG_SMALL_TILT_US 1520U           /* 心电图小波峰俯仰脉宽。靠近基线可缩小上下波动。 */
#define ECG_BIG_TILT_US 1565U             /* 心电图主波峰俯仰脉宽。靠近基线可压低中间大波峰。 */
#define ECG_VALLEY_TILT_US 1460U          /* 心电图谷值俯仰脉宽。靠近基线可缩小下探幅度。 */

typedef enum {
    ROUTE_NODE_A = 0,
    ROUTE_NODE_B,
    ROUTE_NODE_C,
    ROUTE_NODE_D
} route_node_t;

typedef enum {
    CHASSIS_MODE_1 = 0,
    CHASSIS_MODE_2,
    CHASSIS_MODE_3
} chassis_mode_t;

typedef enum {
    CONTEST_TASK_BASIC_1 = 0,
    CONTEST_TASK_BASIC_2,
    CONTEST_TASK_BASIC_3,
    CONTEST_TASK_ADV_ECG,
    CONTEST_TASK_ADV_ROUTE2_AIM,
    CONTEST_TASK_ADV_ROUTE3_AIM
} contest_task_t;

typedef enum {
    SELECTION_BUTTON_NONE = 0,
    SELECTION_BUTTON_MODE1,
    SELECTION_BUTTON_MODE2,
    SELECTION_BUTTON_MODE3
} selection_button_t;

typedef enum {
    APP_STATE_IDLE = 0,
    APP_STATE_RUNNING,
    APP_STATE_STOPPED
} app_state_t;

typedef enum {
    TASK_PHASE_TRACK = 0,
    TASK_PHASE_STOP_HOLD,
    TASK_PHASE_FINISHED
} task_phase_t;

typedef enum {
    ECG_LEVEL_BASE = 0,
    ECG_LEVEL_SMALL_PEAK,
    ECG_LEVEL_BIG_PEAK,
    ECG_LEVEL_VALLEY,
    ECG_LEVEL_Q_VALLEY
} ecg_level_t;

typedef enum {
    ECG_STAGE_LOCATE = 0,
    ECG_STAGE_DRAW
} ecg_stage_t;

typedef struct {
    int32_t integral;
    int16_t last_error;
} speed_pid_t;

typedef struct {
    int32_t integral;
    int16_t last_error;
    bool initialized;
} heading_pid_t;

typedef struct {
    int16_t last_error;
    bool initialized;
} gimbal_pid_axis_t;

typedef struct {
    uint8_t kp_num;
    uint16_t kp_den;
    uint8_t ki_num;
    uint16_t ki_den;
    uint8_t kd_num;
    uint16_t kd_den;
    int16_t deadband;
    int32_t integral_limit;
    int16_t output_limit;
    int8_t direction;
} control_pid_config_t;

typedef struct {
    chassis_mode_t mode;
    uint8_t node_count;
    route_node_t nodes[5];
    uint8_t default_loops;
} route_plan_t;

typedef enum {
    SCHOOL_LEG_NONE = 0,
    SCHOOL_LEG_STRAIGHT,
    SCHOOL_LEG_ARC
} school_leg_type_t;

typedef struct {
    route_node_t start_node;
    route_node_t end_node;
    school_leg_type_t type;
    bool line_tracked;
    uint16_t length_mm;
    int16_t heading_start_deg_x10;
    int16_t heading_end_deg_x10;
} school_leg_t;

typedef struct {
    uint16_t x;
    ecg_level_t level;
} ecg_knot_t;

typedef struct {
    bool has_line;
    int16_t error;
    uint8_t active_count;
    uint8_t active_mask;
    uint8_t raw_mask;
    uint8_t max_index;
    uint8_t max_value;
} line_track_state_t;

typedef struct {
    car_app_profile_id_t profile_id;
    const char *name;
    int16_t base_speed_mode_1;
    int16_t base_speed_mode_2;
    int16_t base_speed_mode_3;
    uint8_t motor_feedforward_num;
    uint8_t line_turn_gain_num;
    uint8_t line_turn_gain_den;
    uint8_t straight_diff_gain_num;
    uint8_t straight_diff_gain_den;
    int16_t straight_diff_limit_pps;
    uint8_t speed_pid_kp_num;
    uint8_t speed_pid_ki_num;
    uint8_t speed_pid_scale_den;
    int32_t speed_pid_integral_limit;
    int16_t wheel_speed_max_pps;
    int16_t motor_line_lost_pwm;
    int16_t motor_min_effective_pwm;
    uint8_t node_active_count_min;
    uint8_t node_confirm_ticks;
    uint8_t node_release_ticks;
    int32_t node_rearm_min_travel;
    uint16_t mode1_stop_hold_ms;
    uint16_t odom_counts_per_mm_x100;
    uint8_t heading_gain_num;
    uint8_t heading_gain_den;
    int16_t heading_term_limit_pps;
    uint16_t node_event_beep_ms;
    uint16_t start_event_beep_ms;
    uint16_t stop_event_beep_ms;
} car_app_profile_t;

typedef struct {
    int16_t heading_ac_x10;
    int16_t heading_bd_x10;
    int16_t mode3_ac_heading_x10[MODE3_LOOP_MAX];
    int16_t mode3_bd_heading_x10[MODE3_LOOP_MAX];
    int16_t mode2_ab_heading_x10;
    int16_t mode2_cd_heading_x10;
    uint16_t diagonal_mm;
    uint16_t odom_counts_per_mm_x100;
    uint8_t heading_gain_num;
    uint8_t heading_gain_den;
    int16_t heading_term_limit_pps;
    uint8_t heading_kp_num;
    uint16_t heading_kp_den;
    uint8_t heading_ki_num;
    uint16_t heading_ki_den;
    uint8_t heading_kd_num;
    uint16_t heading_kd_den;
    int16_t heading_deadband_x10;
    int32_t heading_integral_limit;
    int8_t heading_steer_dir;
    uint8_t open_reacquire_min_percent;
    uint8_t open_reacquire_confirm_ticks;
    uint8_t open_max_overrun_percent;
    int16_t base_speed_mode_1;
    int16_t base_speed_mode_2;
    int16_t base_speed_mode_3;
    int16_t straight_bias_pps;
    int16_t yaw_zero_offset_deg_x10;
    int32_t mode1_preaim_start_counts;
    int16_t mode1_preaim_heading_x10;
    int16_t mode1_arc_feedforward_pps;
    int16_t target_heading_deg_x10;
    int16_t aim_pred_pan_gain_us_per_deg_x10;
    int16_t aim_pred_tilt_gain_us_per_deg_x10;
    uint8_t aim_pred_blend_percent;
    int16_t aim_pred_window_pan_us;
    int16_t aim_pred_window_tilt_us;
    int16_t aim_pred_settle_step_us;
    int16_t aim_pred_pan_bias_us;
    int16_t aim_pred_tilt_bias_us;
    control_pid_config_t position_pid;
    control_pid_config_t line_pid;
    control_pid_config_t speed_pid;
    uint8_t speed_feedforward_num;
    int16_t speed_min_effective_pwm;
} car_app_tuning_t;

typedef struct {
    app_state_t state;
    task_phase_t task_phase;
    chassis_mode_t selected_mode;
    contest_task_t contest_task;
    selection_button_t last_selection_button;
    uint8_t mode3_loops;
    uint8_t active_loops;
    uint8_t completed_loops;
    uint8_t route_index;
    uint8_t node_confirm_ticks;
    uint8_t node_release_ticks;
    uint16_t hold_ticks_remaining;
    line_track_state_t line_state;
    encoder_sample_t encoder_state;
    imu_state_t imu_state;
    vision_status_t vision_state;
    motor_command_t motor_command;
    motor_command_t manual_motor_command;
    uint16_t manual_motor_ticks_remaining;
    speed_pid_t left_speed_pid;
    speed_pid_t right_speed_pid;
    heading_pid_t heading_pid;
    heading_pid_t line_pid;
    gimbal_pid_axis_t ecg_locate_pid[2];
    gimbal_pid_axis_t gimbal_aim_pid[2];
    jy901_parser_t imu_parser;
    const car_app_profile_t *profile;
    int16_t last_line_error;
    uint16_t debug_print_divider;
    uint16_t debug_print_period_ticks;
    uint32_t current_button_mask;
    uint32_t last_pressed_button_mask;
    uint32_t prev_button_mask;
    uint32_t button_candidate_mask;
    uint8_t button_debounce_ticks;
    uint16_t mode_button_hold_ticks[3];
    bool mode_button_long_handled[3];
    bool auto_start_pending;
    uint32_t node_event_count;
    uint32_t tick_count;
    int32_t travel_count_total;
    int32_t leg_start_travel_count;
    int32_t prev_left_total_count;
    int32_t prev_right_total_count;
    int32_t last_node_trigger_travel_count;
    route_node_t last_event_node;
    bool node_detector_armed;
    bool yaw_zero_valid;
    float yaw_zero_deg;
    bool gyro_heading_valid;
    float gyro_relative_yaw_deg;
    bool route2_bc_exit_candidate_valid;
    float route2_bc_exit_candidate_yaw_deg;
    int16_t route2_bc_exit_candidate_ryaw_x10;
    int32_t route2_bc_exit_candidate_lcnt;
    uint8_t open_line_confirm_ticks;
    uint8_t line_transition_ticks;
    bool arc_entry_active;
    car_app_tuning_t tuning;
    bool line_was_ok;
    uint16_t bias_ramp_ticks;
    bool led_on;
    bool laser_power_on;
    bool ecg_active;
    ecg_stage_t ecg_stage;
    uint8_t ecg_locate_confirm_updates;
    uint16_t ecg_elapsed_ticks;
    uint16_t ecg_next_update_ticks;
    uint32_t ecg_last_target_update_count;
    uint32_t aim_last_target_update_count;
    uint16_t aim_lost_ticks;
    uint16_t aim_search_update_ticks;
    int8_t aim_search_pan_dir;
    int8_t aim_search_tilt_dir;
    int16_t aim_search_pan_offset_us;
    int16_t aim_search_tilt_offset_us;
    int32_t aim_last_seen_pan_us;
    int32_t aim_last_seen_tilt_us;
    bool aim_last_seen_valid;
    int32_t ecg_origin_pan_us;
    int32_t ecg_origin_tilt_us;
    bool beep_pending;
    uint16_t beep_frequency_hz;
    uint16_t beep_duration_ms;
} car_app_t;

static car_app_t g_app;

static void car_app_debug_print(void);
static void car_app_start(car_app_t *app);
static void car_app_stop(car_app_t *app);
static void car_app_print_button_event(const char *event);
static void car_app_sync_legacy_tuning_fields(car_app_t *app);
static void car_app_reset_ecg_locate_pid(car_app_t *app);
static void car_app_reset_gimbal_aim_pid(car_app_t *app);
static void car_app_update_aim_gimbal_pid(car_app_t *app);
static bool car_app_get_current_leg(const car_app_t *app, school_leg_t *leg);
static int32_t car_app_current_leg_travel_counts(const car_app_t *app);
static int32_t car_app_leg_target_counts(const school_leg_t *leg);

static const route_plan_t g_route_plans[] = {
    { CHASSIS_MODE_1, 3U, { ROUTE_NODE_A, ROUTE_NODE_B, ROUTE_NODE_C, ROUTE_NODE_A, ROUTE_NODE_A }, 1U },
    { CHASSIS_MODE_2, 5U, { ROUTE_NODE_A, ROUTE_NODE_B, ROUTE_NODE_C, ROUTE_NODE_D, ROUTE_NODE_A }, 1U },
    { CHASSIS_MODE_3, 5U, { ROUTE_NODE_A, ROUTE_NODE_C, ROUTE_NODE_B, ROUTE_NODE_D, ROUTE_NODE_A }, 1U }
};

static const ecg_knot_t g_ecg_knots[] = {
    { 0U, ECG_LEVEL_BASE },
    { 90U, ECG_LEVEL_BASE },
    { 150U, ECG_LEVEL_SMALL_PEAK },
    { 220U, ECG_LEVEL_BASE },
    { 330U, ECG_LEVEL_BASE },
    { 365U, ECG_LEVEL_Q_VALLEY },
    { 405U, ECG_LEVEL_BIG_PEAK },
    { 445U, ECG_LEVEL_VALLEY },
    { 535U, ECG_LEVEL_BASE },
    { 660U, ECG_LEVEL_BASE },
    { 760U, ECG_LEVEL_SMALL_PEAK },
    { 900U, ECG_LEVEL_BASE },
    { 1000U, ECG_LEVEL_BASE }
};

#define SCHOOL_TRACK_ARC_RADIUS_MM              400U  /* 赛道半圆半径，单位 mm。调大几何弧长变长；调小弧长变短，应跟实际场地一致。 */
#define SCHOOL_TRACK_STRAIGHT_MM               1000U  /* AB/CD 理论直线长度，单位 mm。调大会让对应直线目标计数变大；调小会更早切段。 */
#define SCHOOL_TRACK_DIAGONAL_MM               1281U  /* AC/BD 理论对角线长度，单位 mm。调大对角线跑更远；调小更早寻找弧线/切段。 */
#define SCHOOL_TRACK_HEADING_AB_X10               0   /* AB 理论航向，单位 0.1 度。调大目标角更正；调小目标角更负。 */
#define SCHOOL_TRACK_HEADING_BC_ENTRY_X10       -900  /* B-C 入弧理论航向，单位 0.1 度。调大会改变弧线日志目标角；通常不现场调。 */
#define SCHOOL_TRACK_HEADING_CB_ENTRY_X10          0   /* C-B 入弧理论航向，单位 0.1 度。调大会改变反向弧线入口目标角；通常不现场调。 */
#define SCHOOL_TRACK_HEADING_BD_X10            -1413  /* B-D 原始几何角，单位 0.1 度。默认会取反并按 3/19 缩放；现场优先用 PARAM,M3BD。 */
#define SCHOOL_TRACK_HEADING_CD_X10             1800  /* C-D 理论航向，单位 0.1 度。调大/调小会改变阶段二 C-D 基准，现场优先用 M2CD。 */
#define SCHOOL_TRACK_HEADING_DA_ENTRY_X10       1800  /* D-A 入弧理论航向，单位 0.1 度。影响 DA 弧线日志和入口姿态。 */
#define SCHOOL_TRACK_HEADING_AC_X10             -387  /* A-C 原始几何角，单位 0.1 度。默认按 3/19 缩放，且第 1 圈会被 MODE3_AC_LOOP1_HEADING_X10 覆盖。 */
/* Placeholder calibration: replace with measured encoder counts per mm on the real chassis. */
#define CAR_APP_PROFILE( \
    profile_tag, profile_name, mode1_speed, mode2_speed, mode3_speed, \
    feedforward_num, turn_gain_num, turn_gain_den, straight_gain_num, \
    straight_gain_den, straight_limit, pid_kp_num, pid_ki_num, \
    pid_scale_den, integral_limit, wheel_speed_max, line_lost_pwm, \
    min_effective_pwm, node_active_count, node_confirm, node_release, \
    node_rearm_distance, stop_hold_ms, odom_counts_per_mm_x100, \
    heading_gain_num, heading_gain_den, heading_term_limit_pps, \
    node_beep_ms, start_beep_ms, \
    stop_beep_ms) \
    { \
        CAR_APP_PROFILE_##profile_tag, \
        profile_name, \
        mode1_speed, \
        mode2_speed, \
        mode3_speed, \
        feedforward_num, \
        turn_gain_num, \
        turn_gain_den, \
        straight_gain_num, \
        straight_gain_den, \
        straight_limit, \
        pid_kp_num, \
        pid_ki_num, \
        pid_scale_den, \
        integral_limit, \
        wheel_speed_max, \
        line_lost_pwm, \
        min_effective_pwm, \
        node_active_count, \
        node_confirm, \
        node_release, \
        node_rearm_distance, \
        stop_hold_ms, \
        odom_counts_per_mm_x100, \
        heading_gain_num, \
        heading_gain_den, \
        heading_term_limit_pps, \
        node_beep_ms, \
        start_beep_ms, \
        stop_beep_ms \
    },
static const car_app_profile_t g_profiles[] = {
#include "car_app_profiles.def"
};
#undef CAR_APP_PROFILE

static void car_app_set_mode3_ac_all(car_app_t *app, int16_t value)
{
    uint8_t index;

    if (app == NULL) {
        return;
    }

    for (index = 0U; index < MODE3_LOOP_MAX; ++index) {
        app->tuning.mode3_ac_heading_x10[index] = value;
    }
    app->tuning.heading_ac_x10 = value;
}

static void car_app_set_mode3_bd_all(car_app_t *app, int16_t value)
{
    uint8_t index;

    if (app == NULL) {
        return;
    }

    for (index = 0U; index < MODE3_LOOP_MAX; ++index) {
        app->tuning.mode3_bd_heading_x10[index] = value;
    }
    app->tuning.heading_bd_x10 = value;
}

static bool car_app_set_mode3_ac_loop(car_app_t *app, int32_t loop, int16_t value)
{
    if (app == NULL) {
        return false;
    }

    if (loop == 0) {
        car_app_set_mode3_ac_all(app, value);
        return true;
    }

    if ((loop < (int32_t) MODE3_LOOP_MIN) || (loop > (int32_t) MODE3_LOOP_MAX)) {
        return false;
    }

    app->tuning.mode3_ac_heading_x10[(uint8_t) loop - 1U] = value;
    app->tuning.heading_ac_x10 = app->tuning.mode3_ac_heading_x10[0];
    return true;
}

static bool car_app_set_mode3_bd_loop(car_app_t *app, int32_t loop, int16_t value)
{
    if (app == NULL) {
        return false;
    }

    if (loop == 0) {
        car_app_set_mode3_bd_all(app, value);
        return true;
    }

    if ((loop < (int32_t) MODE3_LOOP_MIN) || (loop > (int32_t) MODE3_LOOP_MAX)) {
        return false;
    }

    app->tuning.mode3_bd_heading_x10[(uint8_t) loop - 1U] = value;
    app->tuning.heading_bd_x10 = app->tuning.mode3_bd_heading_x10[0];
    return true;
}

static void car_app_reset_runtime_tuning(car_app_t *app)
{
    const int16_t default_mode3_ac_x10 =
        (int16_t) (((int32_t) SCHOOL_TRACK_HEADING_AC_X10 *
                   MODE3_DIAGONAL_HEADING_NUM) /
                  MODE3_DIAGONAL_HEADING_DEN);
    const int16_t default_mode3_bd_x10 =
        (int16_t) (-(((int32_t) SCHOOL_TRACK_HEADING_BD_X10 *
                     MODE3_DIAGONAL_HEADING_NUM) /
                    MODE3_DIAGONAL_HEADING_DEN));

    if ((app == NULL) || (app->profile == NULL)) {
        return;
    }

    car_app_set_mode3_ac_all(app, default_mode3_ac_x10);
    app->tuning.mode3_ac_heading_x10[0] = MODE3_AC_LOOP1_HEADING_X10;
    app->tuning.mode3_ac_heading_x10[1] = MODE3_AC_LOOP2_HEADING_X10;
    app->tuning.mode3_ac_heading_x10[2] = MODE3_AC_LOOP3_HEADING_X10;
    app->tuning.heading_ac_x10 = app->tuning.mode3_ac_heading_x10[0];
    car_app_set_mode3_bd_all(app, default_mode3_bd_x10);
    app->tuning.mode3_bd_heading_x10[0] = MODE3_BD_LOOP1_HEADING_X10;
    app->tuning.mode3_bd_heading_x10[1] = MODE3_BD_LOOP2_HEADING_X10;
    app->tuning.mode3_bd_heading_x10[2] = MODE3_BD_LOOP3_HEADING_X10;
    app->tuning.heading_bd_x10 = app->tuning.mode3_bd_heading_x10[0];
    app->tuning.mode2_ab_heading_x10 = 0;
    app->tuning.mode2_cd_heading_x10 = MODE2_CD_HEADING_TRIM_X10;
    app->tuning.diagonal_mm = SCHOOL_TRACK_DIAGONAL_MM;
    app->tuning.odom_counts_per_mm_x100 = app->profile->odom_counts_per_mm_x100;
    app->tuning.heading_gain_num = app->profile->heading_gain_num;
    app->tuning.heading_gain_den = app->profile->heading_gain_den;
    app->tuning.heading_term_limit_pps = app->profile->heading_term_limit_pps;
    app->tuning.heading_kp_num = app->profile->heading_gain_num;
    app->tuning.heading_kp_den = app->profile->heading_gain_den;
    app->tuning.heading_ki_num = 0U;
    app->tuning.heading_ki_den = 100U;
    app->tuning.heading_kd_num = 2U;
    app->tuning.heading_kd_den = 1U;
    app->tuning.heading_deadband_x10 = 8;
    app->tuning.heading_integral_limit = 900;
    app->tuning.heading_steer_dir = 1;
    app->tuning.open_reacquire_min_percent = OPEN_LEG_REACQUIRE_MIN_PERCENT;
    app->tuning.open_reacquire_confirm_ticks = OPEN_LEG_REACQUIRE_CONFIRM_TICKS;
    app->tuning.open_max_overrun_percent = OPEN_LEG_MAX_OVERRUN_PERCENT;
    app->tuning.base_speed_mode_1 = MODE1_BASE_SPEED_PPS;
    app->tuning.base_speed_mode_2 = MODE2_BASE_SPEED_PPS;
    app->tuning.base_speed_mode_3 = MODE3_BASE_SPEED_PPS;
    app->tuning.straight_bias_pps = 30;
    app->tuning.yaw_zero_offset_deg_x10 = YAW_ZERO_OFFSET_DEG_X10;
    app->tuning.mode1_preaim_start_counts = MODE1_PREAIM_START_COUNTS;
    app->tuning.mode1_preaim_heading_x10 = MODE1_PREAIM_HEADING_X10;
    app->tuning.mode1_arc_feedforward_pps = MODE1_ARC_FEEDFORWARD_PPS;
    app->tuning.target_heading_deg_x10 = 0;
    app->tuning.aim_pred_pan_gain_us_per_deg_x10 = GIMBAL_AIM_PRED_PAN_GAIN_US_PER_DEG_X10;
    app->tuning.aim_pred_tilt_gain_us_per_deg_x10 = GIMBAL_AIM_PRED_TILT_GAIN_US_PER_DEG_X10;
    app->tuning.aim_pred_blend_percent = GIMBAL_AIM_PRED_BLEND_PERCENT;
    app->tuning.aim_pred_window_pan_us = GIMBAL_AIM_PRED_WINDOW_PAN_US;
    app->tuning.aim_pred_window_tilt_us = GIMBAL_AIM_PRED_WINDOW_TILT_US;
    app->tuning.aim_pred_settle_step_us = GIMBAL_AIM_PRED_SETTLE_STEP_US;
    app->tuning.aim_pred_pan_bias_us = GIMBAL_AIM_PRED_PAN_BIAS_US;
    app->tuning.aim_pred_tilt_bias_us = GIMBAL_AIM_PRED_TILT_BIAS_US;
    app->tuning.speed_feedforward_num = app->profile->motor_feedforward_num;
    app->tuning.speed_min_effective_pwm = HEAVY_GIMBAL_MIN_EFFECTIVE_PWM;
    app->tuning.position_pid.kp_num = 67U;
    app->tuning.position_pid.kp_den = 21U;
    app->tuning.position_pid.ki_num = 1U;
    app->tuning.position_pid.ki_den = 401U;
    app->tuning.position_pid.kd_num = 9U;
    app->tuning.position_pid.kd_den = 20U;
    app->tuning.position_pid.deadband = 2;
    app->tuning.position_pid.integral_limit = 600;
    app->tuning.position_pid.output_limit = 500;
    app->tuning.position_pid.direction = 1;
    app->tuning.line_pid.kp_num = app->profile->line_turn_gain_num;
    app->tuning.line_pid.kp_den = app->profile->line_turn_gain_den;
    app->tuning.line_pid.ki_num = 0U;
    app->tuning.line_pid.ki_den = 100U;
    app->tuning.line_pid.kd_num = 3U;
    app->tuning.line_pid.kd_den = 1U;
    app->tuning.line_pid.deadband = 0;
    app->tuning.line_pid.integral_limit = 0;
    app->tuning.line_pid.output_limit = app->profile->wheel_speed_max_pps;
    app->tuning.line_pid.direction = 1;
    app->tuning.speed_pid.kp_num = app->profile->speed_pid_kp_num;
    app->tuning.speed_pid.kp_den = app->profile->speed_pid_scale_den;
    app->tuning.speed_pid.ki_num = app->profile->speed_pid_ki_num;
    app->tuning.speed_pid.ki_den = app->profile->speed_pid_scale_den;
    app->tuning.speed_pid.kd_num = 0U;
    app->tuning.speed_pid.kd_den = 1U;
    app->tuning.speed_pid.deadband = 0;
    app->tuning.speed_pid.integral_limit = app->profile->speed_pid_integral_limit;
    app->tuning.speed_pid.output_limit = app->profile->wheel_speed_max_pps * 4;
    app->tuning.speed_pid.direction = 1;

    if ((app->contest_task == CONTEST_TASK_BASIC_1) ||
        (app->contest_task == CONTEST_TASK_BASIC_2) ||
        (app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM)) {
        if (app->contest_task == CONTEST_TASK_BASIC_1) {
            app->tuning.base_speed_mode_1 = MODE1_BASE_SPEED_PPS;
        } else if (app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM) {
            app->tuning.base_speed_mode_2 = ADV_ROUTE2_BASE_SPEED_PPS;
        } else {
            app->tuning.base_speed_mode_2 = MODE2_BASE_SPEED_PPS;
        }
        app->tuning.target_heading_deg_x10 = 0;
        app->tuning.straight_bias_pps = 26;
        app->tuning.mode1_preaim_start_counts = MODE1_PREAIM_START_COUNTS;
        app->tuning.mode1_preaim_heading_x10 = MODE1_PREAIM_HEADING_X10;
        app->tuning.mode1_arc_feedforward_pps = MODE1_ARC_FEEDFORWARD_PPS;
        app->tuning.position_pid.kp_num = 100U;
        app->tuning.position_pid.kp_den = 21U;
        app->tuning.position_pid.ki_num = 3U;
        app->tuning.position_pid.ki_den = 100U;
        app->tuning.position_pid.kd_num = 24U;
        app->tuning.position_pid.kd_den = 20U;
        app->tuning.position_pid.deadband = 1;
        app->tuning.position_pid.integral_limit = 900;
        app->tuning.position_pid.output_limit = 550;
        app->tuning.position_pid.direction = 1;
        app->tuning.line_pid.kp_num = LINE_TURN_KP_NUM;
        app->tuning.line_pid.kp_den = LINE_TURN_KP_DEN;
        app->tuning.line_pid.ki_num = 0U;
        app->tuning.line_pid.ki_den = 100U;
        app->tuning.line_pid.kd_num = LINE_TURN_KD_NUM;
        app->tuning.line_pid.kd_den = LINE_TURN_KD_DEN;
        app->tuning.line_pid.deadband = 0;
        app->tuning.line_pid.integral_limit = 0;
        app->tuning.line_pid.output_limit = LINE_TURN_OUTPUT_LIMIT_PPS;
        app->tuning.line_pid.direction = 1;
        app->tuning.speed_feedforward_num = 2U;
        app->tuning.speed_pid.kp_num = 11U;
        app->tuning.speed_pid.kp_den = 8U;
        app->tuning.speed_pid.ki_num = 3U;
        app->tuning.speed_pid.ki_den = 8U;
        app->tuning.speed_pid.kd_num = 0U;
        app->tuning.speed_pid.kd_den = 1U;
        app->tuning.speed_pid.deadband = 0;
        app->tuning.speed_pid.integral_limit = 5000;
        app->tuning.speed_pid.output_limit = 2850;
        app->tuning.speed_pid.direction = 1;
        app->tuning.speed_min_effective_pwm = HEAVY_GIMBAL_MIN_EFFECTIVE_PWM;
    }
    if ((app->contest_task == CONTEST_TASK_BASIC_3) ||
        (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM)) {
        if (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM) {
            app->tuning.base_speed_mode_3 = ADV_ROUTE3_BASE_SPEED_PPS;
        }
        app->tuning.mode1_arc_feedforward_pps = MODE1_ARC_FEEDFORWARD_PPS;
        app->tuning.line_pid.kp_num = LINE_TURN_KP_NUM;
        app->tuning.line_pid.kp_den = LINE_TURN_KP_DEN;
        app->tuning.line_pid.ki_num = 0U;
        app->tuning.line_pid.ki_den = 100U;
        app->tuning.line_pid.kd_num = LINE_TURN_KD_NUM;
        app->tuning.line_pid.kd_den = LINE_TURN_KD_DEN;
        app->tuning.line_pid.deadband = 0;
        app->tuning.line_pid.integral_limit = 0;
        app->tuning.line_pid.output_limit = LINE_TURN_OUTPUT_LIMIT_PPS;
        app->tuning.line_pid.direction = 1;
        app->tuning.speed_min_effective_pwm = HEAVY_GIMBAL_MIN_EFFECTIVE_PWM;
    }
    car_app_sync_legacy_tuning_fields(app);
}

static int16_t abs_i16(int16_t value)
{
    return (value < 0) ? (int16_t) (-value) : value;
}

static int32_t abs_i32(int32_t value)
{
    return (value < 0) ? -value : value;
}

static int32_t clamp_i32(int32_t value, int32_t min_value, int32_t max_value)
{
    if (value < min_value) {
        return min_value;
    }
    if (value > max_value) {
        return max_value;
    }
    return value;
}

static int32_t interpolate_i32(int32_t from, int32_t to, uint32_t num, uint32_t den)
{
    const int32_t delta = to - from;

    if (den == 0U) {
        return to;
    }

    if (delta >= 0) {
        return from + (int32_t) (((uint32_t) delta * num + (den / 2U)) / den);
    }

    return from - (int32_t) (((uint32_t) (-delta) * num + (den / 2U)) / den);
}

static int32_t slew_i32(int32_t current, int32_t target, int32_t max_step)
{
    int32_t delta = target - current;

    if (max_step < 0) {
        max_step = -max_step;
    }
    if (max_step == 0) {
        return target;
    }
    delta = clamp_i32(delta, -max_step, max_step);
    return current + delta;
}

static int16_t normalize_heading_deg_x10(int16_t heading_deg_x10)
{
    while (heading_deg_x10 <= -1800) {
        heading_deg_x10 += 3600;
    }
    while (heading_deg_x10 > 1800) {
        heading_deg_x10 -= 3600;
    }
    return heading_deg_x10;
}

static float normalize_heading_deg(float heading_deg)
{
    while (heading_deg <= -180.0f) {
        heading_deg += 360.0f;
    }
    while (heading_deg > 180.0f) {
        heading_deg -= 360.0f;
    }
    return heading_deg;
}

static int16_t deg_to_x10(float deg)
{
    if (deg >= 0.0f) {
        return (int16_t) (deg * 10.0f + 0.5f);
    }
    return (int16_t) (deg * 10.0f - 0.5f);
}

static int16_t car_app_relative_yaw_deg_x10(const car_app_t *app)
{
    if ((app == NULL) || (!app->imu_state.angle_valid) || (!app->yaw_zero_valid)) {
        return 0;
    }

    return normalize_heading_deg_x10(
        (int16_t) ((app->imu_state.yaw_deg - app->yaw_zero_deg) * 10.0f));
}

static int16_t car_app_heading_error_from_relative_yaw(
    const car_app_t *app, int16_t target_heading_deg_x10);

static void car_app_reset_gyro_heading(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    app->gyro_heading_valid = app->imu_state.gyro_valid;
    app->gyro_relative_yaw_deg = 0.0f;
}

static int16_t car_app_gyro_relative_yaw_deg_x10(const car_app_t *app)
{
    if ((app == NULL) || (!app->gyro_heading_valid)) {
        return 0;
    }

    return deg_to_x10(normalize_heading_deg(app->gyro_relative_yaw_deg));
}

static int16_t car_app_heading_error_from_gyro_yaw(
    const car_app_t *app, int16_t target_heading_deg_x10)
{
    if ((app == NULL) || (!app->gyro_heading_valid)) {
        return car_app_heading_error_from_relative_yaw(app, target_heading_deg_x10);
    }

    return normalize_heading_deg_x10(
        (int16_t) (target_heading_deg_x10 - car_app_gyro_relative_yaw_deg_x10(app)));
}

static int16_t car_app_heading_error_from_relative_yaw(
    const car_app_t *app, int16_t target_heading_deg_x10)
{
    if ((app == NULL) || (!app->imu_state.angle_valid) || (!app->yaw_zero_valid)) {
        return 0;
    }

    return normalize_heading_deg_x10(
        (int16_t) (target_heading_deg_x10 - car_app_relative_yaw_deg_x10(app)));
}

static uint32_t ticks_to_ms(uint32_t ticks)
{
    return (ticks * 1000U) / APP_CONTROL_HZ;
}

static bool car_app_is_stationary_task(const car_app_t *app)
{
    return (app != NULL) && (app->contest_task == CONTEST_TASK_ADV_ECG);
}

static bool car_app_task_uses_laser(const car_app_t *app)
{
    return (app != NULL) &&
           ((app->contest_task == CONTEST_TASK_ADV_ECG) ||
            (app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM) ||
            (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM));
}

static void car_app_reset_ecg_runtime(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    app->ecg_active = false;
    app->ecg_stage = ECG_STAGE_LOCATE;
    app->ecg_locate_confirm_updates = 0U;
    app->ecg_elapsed_ticks = 0U;
    app->ecg_next_update_ticks = 0U;
    app->ecg_last_target_update_count = 0U;
    app->ecg_origin_pan_us = ECG_LEFT_PAN_US;
    app->ecg_origin_tilt_us = ECG_BASE_TILT_US;
    car_app_reset_ecg_locate_pid(app);
}

static const char *car_app_task_oled_label(const car_app_t *app)
{
    if (app == NULL) {
        return "B1";
    }

    switch (app->contest_task) {
        case CONTEST_TASK_BASIC_1:
            return "B1";
        case CONTEST_TASK_BASIC_2:
            return "B2";
        case CONTEST_TASK_BASIC_3:
            return "B3";
        case CONTEST_TASK_ADV_ECG:
            return "A1 ECG";
        case CONTEST_TASK_ADV_ROUTE2_AIM:
            return "A2 AIM";
        case CONTEST_TASK_ADV_ROUTE3_AIM:
            return "A3 AIM";
        default:
            return "B1";
    }
}

static void car_app_select_task(car_app_t *app, contest_task_t task)
{
    if (app == NULL) {
        return;
    }

    app->contest_task = task;
    car_app_reset_gimbal_aim_pid(app);
    switch (task) {
        case CONTEST_TASK_BASIC_1:
        case CONTEST_TASK_ADV_ECG:
            app->selected_mode = CHASSIS_MODE_1;
            app->last_selection_button = SELECTION_BUTTON_MODE1;
            break;
        case CONTEST_TASK_BASIC_2:
        case CONTEST_TASK_ADV_ROUTE2_AIM:
            app->selected_mode = CHASSIS_MODE_2;
            app->last_selection_button = SELECTION_BUTTON_MODE2;
            break;
        case CONTEST_TASK_BASIC_3:
        case CONTEST_TASK_ADV_ROUTE3_AIM:
            app->selected_mode = CHASSIS_MODE_3;
            app->last_selection_button = SELECTION_BUTTON_MODE3;
            app->mode3_loops = MODE3_LOOP_MIN;
            break;
        default:
            break;
    }
    car_app_reset_ecg_runtime(app);
    car_app_reset_runtime_tuning(app);
}

static void speed_pid_reset(speed_pid_t *pid)
{
    pid->integral = 0;
    pid->last_error = 0;
}

static void car_app_reset_speed_pids(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    speed_pid_reset(&app->left_speed_pid);
    speed_pid_reset(&app->right_speed_pid);
}

static void heading_pid_reset(heading_pid_t *pid)
{
    pid->integral = 0;
    pid->last_error = 0;
    pid->initialized = false;
}

static void gimbal_pid_axis_reset(gimbal_pid_axis_t *pid)
{
    if (pid == NULL) {
        return;
    }

    pid->last_error = 0;
    pid->initialized = false;
}

static void car_app_reset_ecg_locate_pid(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    gimbal_pid_axis_reset(&app->ecg_locate_pid[0]);
    gimbal_pid_axis_reset(&app->ecg_locate_pid[1]);
}

static void car_app_reset_gimbal_aim_search(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    app->aim_lost_ticks = 0U;
    app->aim_search_update_ticks = 0U;
    app->aim_search_pan_dir = 1;
    app->aim_search_tilt_dir = 1;
    app->aim_search_pan_offset_us = 0;
    app->aim_search_tilt_offset_us = 0;
}

static void car_app_remember_aim_seen_pose(car_app_t *app)
{
    gimbal_state_t gimbal_state;

    if (app == NULL) {
        return;
    }

    gimbal_servo_get_state(&gimbal_state);
    app->aim_last_seen_pan_us = gimbal_state.pan_target_us;
    app->aim_last_seen_tilt_us = gimbal_state.tilt_target_us;
    app->aim_last_seen_valid = true;
}

static uint32_t car_app_current_leg_progress_num(
    const car_app_t *app, const school_leg_t *leg, uint32_t den)
{
    int32_t travel_counts;
    int32_t target_counts;

    if ((app == NULL) || (leg == NULL) || (den == 0U)) {
        return 0U;
    }

    travel_counts = car_app_current_leg_travel_counts(app);
    target_counts = car_app_leg_target_counts(leg);
    if (target_counts <= 0) {
        return 0U;
    }

    travel_counts = clamp_i32(travel_counts, 0, target_counts);
    return (uint32_t) (((uint64_t) (uint32_t) travel_counts * den) /
                       (uint32_t) target_counts);
}

static bool car_app_target_bearing_x10_for_leg(
    const car_app_t *app, const school_leg_t *leg, int16_t *bearing_x10)
{
    int16_t start_x10;
    int16_t end_x10;
    int16_t span_x10;
    uint32_t progress;

    if ((app == NULL) || (leg == NULL) || (bearing_x10 == NULL)) {
        return false;
    }

    if (app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM) {
        if ((leg->start_node == ROUTE_NODE_A) && (leg->end_node == ROUTE_NODE_B)) {
            start_x10 = GIMBAL_AIM_ROUTE2_AB_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE2_AB_END_X10;
        } else if ((leg->start_node == ROUTE_NODE_B) && (leg->end_node == ROUTE_NODE_C)) {
            start_x10 = GIMBAL_AIM_ROUTE2_BC_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE2_BC_END_X10;
        } else if ((leg->start_node == ROUTE_NODE_C) && (leg->end_node == ROUTE_NODE_D)) {
            start_x10 = GIMBAL_AIM_ROUTE2_CD_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE2_CD_END_X10;
        } else if ((leg->start_node == ROUTE_NODE_D) && (leg->end_node == ROUTE_NODE_A)) {
            start_x10 = GIMBAL_AIM_ROUTE2_DA_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE2_DA_END_X10;
        } else {
            return false;
        }
    } else if (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM) {
        if ((leg->start_node == ROUTE_NODE_A) && (leg->end_node == ROUTE_NODE_C)) {
            start_x10 = GIMBAL_AIM_ROUTE3_AC_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE3_AC_END_X10;
        } else if ((leg->start_node == ROUTE_NODE_C) && (leg->end_node == ROUTE_NODE_B)) {
            start_x10 = GIMBAL_AIM_ROUTE3_CB_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE3_CB_END_X10;
        } else if ((leg->start_node == ROUTE_NODE_B) && (leg->end_node == ROUTE_NODE_D)) {
            start_x10 = GIMBAL_AIM_ROUTE3_BD_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE3_BD_END_X10;
        } else if ((leg->start_node == ROUTE_NODE_D) && (leg->end_node == ROUTE_NODE_A)) {
            start_x10 = GIMBAL_AIM_ROUTE3_DA_START_X10;
            end_x10 = GIMBAL_AIM_ROUTE3_DA_END_X10;
        } else {
            return false;
        }
    } else {
        return false;
    }

    span_x10 = normalize_heading_deg_x10((int16_t) (end_x10 - start_x10));
    progress = car_app_current_leg_progress_num(app, leg, 1000U);
    *bearing_x10 = normalize_heading_deg_x10(
        (int16_t) (start_x10 + ((int32_t) span_x10 * (int32_t) progress) / 1000));
    return true;
}

static bool car_app_predict_aim_anchor(
    const car_app_t *app, int32_t *pan_us, int32_t *tilt_us)
{
    school_leg_t leg;
    int16_t bearing_x10;
    int32_t predicted_pan_us;
    int32_t predicted_tilt_us;

    if ((app == NULL) || (pan_us == NULL) || (tilt_us == NULL) ||
        (!car_app_get_current_leg(app, &leg)) ||
        (!car_app_target_bearing_x10_for_leg(app, &leg, &bearing_x10))) {
        return false;
    }

    predicted_pan_us =
        (int32_t) ECG_MOUNT_PAN_US +
        (((int32_t) bearing_x10 *
          (int32_t) app->tuning.aim_pred_pan_gain_us_per_deg_x10) /
         (int32_t) GIMBAL_AIM_PRED_GAIN_DEN) +
        (int32_t) app->tuning.aim_pred_pan_bias_us;
    predicted_tilt_us =
        (int32_t) ECG_MOUNT_TILT_US +
        (((int32_t) abs_i16(bearing_x10) *
          (int32_t) app->tuning.aim_pred_tilt_gain_us_per_deg_x10) /
         (int32_t) GIMBAL_AIM_PRED_GAIN_DEN) +
        (int32_t) app->tuning.aim_pred_tilt_bias_us;

    *pan_us = predicted_pan_us;
    *tilt_us = predicted_tilt_us;
    return true;
}

static void car_app_blend_aim_anchor(
    const car_app_t *app,
    int32_t predicted_pan_us,
    int32_t predicted_tilt_us,
    int32_t *anchor_pan_us,
    int32_t *anchor_tilt_us)
{
    uint8_t blend;
    int32_t base_pan_us;
    int32_t base_tilt_us;

    if ((app == NULL) || (anchor_pan_us == NULL) || (anchor_tilt_us == NULL)) {
        return;
    }

    blend = (uint8_t) clamp_i32(app->tuning.aim_pred_blend_percent, 0, 100);
    base_pan_us = app->aim_last_seen_valid ? app->aim_last_seen_pan_us : (int32_t) ECG_MOUNT_PAN_US;
    base_tilt_us = app->aim_last_seen_valid ? app->aim_last_seen_tilt_us : (int32_t) ECG_MOUNT_TILT_US;

    *anchor_pan_us =
        ((base_pan_us * (int32_t) (100U - blend)) +
         (predicted_pan_us * (int32_t) blend)) / 100;
    *anchor_tilt_us =
        ((base_tilt_us * (int32_t) (100U - blend)) +
         (predicted_tilt_us * (int32_t) blend)) / 100;
}

static void car_app_reset_gimbal_aim_pid(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    gimbal_pid_axis_reset(&app->gimbal_aim_pid[0]);
    gimbal_pid_axis_reset(&app->gimbal_aim_pid[1]);
    app->aim_last_target_update_count = 0U;
    app->aim_last_seen_valid = false;
    car_app_reset_gimbal_aim_search(app);
}

static void car_app_reset_angle_pids(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    heading_pid_reset(&app->heading_pid);
    heading_pid_reset(&app->line_pid);
}

static int16_t car_app_ecg_locate_pid_step(gimbal_pid_axis_t *pid, int16_t error_px)
{
    int32_t error = error_px;
    int32_t derivative = 0;
    int32_t output;

    if (pid == NULL) {
        return 0;
    }

    if (abs_i16(error_px) <= ECG_LOCATE_DEADBAND_PX) {
        error = 0;
    }

    if (!pid->initialized) {
        pid->last_error = (int16_t) error;
        pid->initialized = true;
    } else {
        derivative = error - (int32_t) pid->last_error;
    }

    output =
        ((error * (int32_t) GIMBAL_AIM_PID_KP_NUM) / GIMBAL_AIM_PID_KP_DEN) +
        ((derivative * (int32_t) GIMBAL_AIM_PID_KD_NUM) / GIMBAL_AIM_PID_KD_DEN);
    output = clamp_i32(output, -GIMBAL_AIM_MAX_STEP_US, GIMBAL_AIM_MAX_STEP_US);
    pid->last_error = (int16_t) error;
    return (int16_t) output;
}

static int16_t car_app_gimbal_aim_pid_step(gimbal_pid_axis_t *pid, int16_t error_px)
{
    int32_t error = error_px;
    int32_t derivative = 0;
    int32_t output;

    if (pid == NULL) {
        return 0;
    }

    if (abs_i16(error_px) <= GIMBAL_AIM_DEADBAND_PX) {
        error = 0;
    }

    if (!pid->initialized) {
        pid->last_error = (int16_t) error;
        pid->initialized = true;
    } else {
        derivative = error - (int32_t) pid->last_error;
    }

    output =
        ((error * (int32_t) GIMBAL_AIM_PID_KP_NUM) / GIMBAL_AIM_PID_KP_DEN) +
        ((derivative * (int32_t) GIMBAL_AIM_PID_KD_NUM) / GIMBAL_AIM_PID_KD_DEN);
    output = clamp_i32(output, -GIMBAL_AIM_MAX_STEP_US, GIMBAL_AIM_MAX_STEP_US);
    pid->last_error = (int16_t) error;
    return (int16_t) output;
}

static void car_app_capture_yaw_zero(car_app_t *app, float yaw_deg)
{
    if (app == NULL) {
        return;
    }

    app->yaw_zero_valid = app->imu_state.angle_valid;
    app->yaw_zero_deg = app->imu_state.angle_valid ? yaw_deg : 0.0f;
    car_app_reset_angle_pids(app);
}

static void car_app_reset_route2_bc_exit_candidate(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    app->route2_bc_exit_candidate_valid = false;
    app->route2_bc_exit_candidate_yaw_deg = 0.0f;
    app->route2_bc_exit_candidate_ryaw_x10 = 0;
    app->route2_bc_exit_candidate_lcnt = 0;
}

static int16_t control_pid_step_preview(
    const heading_pid_t *pid,
    const control_pid_config_t *cfg,
    int16_t error_value)
{
    int32_t error = error_value;
    int32_t derivative;
    int32_t output;

    if ((pid == NULL) || (cfg == NULL)) {
        return 0;
    }

    if (abs_i16(error_value) <= cfg->deadband) {
        error = 0;
    }

    derivative = error - (int32_t) pid->last_error;
    output =
        (error * (int32_t) cfg->kp_num) / (int32_t) cfg->kp_den +
        (pid->integral * (int32_t) cfg->ki_num) / (int32_t) cfg->ki_den +
        (derivative * (int32_t) cfg->kd_num) / (int32_t) cfg->kd_den;

    output = clamp_i32(output, -cfg->output_limit, cfg->output_limit);
    output *= cfg->direction;
    return (int16_t) output;
}

static int16_t control_pid_step(
    heading_pid_t *pid,
    const control_pid_config_t *cfg,
    int16_t error_value)
{
    int32_t error = error_value;
    int32_t derivative;
    int32_t output;

    if ((pid == NULL) || (cfg == NULL)) {
        return 0;
    }

    if (abs_i16(error_value) <= cfg->deadband) {
        error = 0;
    }

    if (!pid->initialized) {
        pid->last_error = (int16_t) error;
        pid->initialized = true;
    }

    if (error == 0) {
        pid->integral = 0;
    } else {
        pid->integral = clamp_i32(
            pid->integral + error,
            -cfg->integral_limit,
            cfg->integral_limit);
    }

    derivative = error - (int32_t) pid->last_error;
    output =
        (error * (int32_t) cfg->kp_num) / (int32_t) cfg->kp_den +
        (pid->integral * (int32_t) cfg->ki_num) / (int32_t) cfg->ki_den +
        (derivative * (int32_t) cfg->kd_num) / (int32_t) cfg->kd_den;
    output = clamp_i32(output, -cfg->output_limit, cfg->output_limit);
    output *= cfg->direction;
    pid->last_error = (int16_t) error;
    return (int16_t) output;
}

static void car_app_sync_legacy_tuning_fields(car_app_t *app)
{
    if (app == NULL) {
        return;
    }

    app->tuning.heading_gain_num = app->tuning.line_pid.kp_num;
    app->tuning.heading_gain_den = app->tuning.line_pid.kp_den;
    app->tuning.heading_kp_num = app->tuning.position_pid.kp_num;
    app->tuning.heading_kp_den = app->tuning.position_pid.kp_den;
    app->tuning.heading_ki_num = app->tuning.position_pid.ki_num;
    app->tuning.heading_ki_den = app->tuning.position_pid.ki_den;
    app->tuning.heading_kd_num = app->tuning.position_pid.kd_num;
    app->tuning.heading_kd_den = app->tuning.position_pid.kd_den;
    app->tuning.heading_deadband_x10 = app->tuning.position_pid.deadband;
    app->tuning.heading_integral_limit = app->tuning.position_pid.integral_limit;
    app->tuning.heading_term_limit_pps = app->tuning.position_pid.output_limit;
    app->tuning.heading_steer_dir = app->tuning.position_pid.direction;
}

static char route_node_to_char(route_node_t node)
{
    switch (node) {
        case ROUTE_NODE_A:
            return 'A';
        case ROUTE_NODE_B:
            return 'B';
        case ROUTE_NODE_C:
            return 'C';
        case ROUTE_NODE_D:
            return 'D';
        default:
            return '?';
    }
}

static uint8_t car_app_mode3_current_loop_index(const car_app_t *app)
{
    uint8_t index = 0U;

    if (app != NULL) {
        index = app->completed_loops;
    }

    if (index >= MODE3_LOOP_MAX) {
        index = MODE3_LOOP_MAX - 1U;
    }

    return index;
}

static bool school_leg_from_nodes(
    route_node_t start_node, route_node_t end_node, school_leg_t *leg)
{
    if (leg == NULL) {
        return false;
    }

    memset(leg, 0, sizeof(*leg));
    leg->start_node = start_node;
    leg->end_node = end_node;

    if ((start_node == ROUTE_NODE_A) && (end_node == ROUTE_NODE_B)) {
        leg->type = SCHOOL_LEG_STRAIGHT;
        leg->length_mm = SCHOOL_TRACK_STRAIGHT_MM;
        leg->heading_start_deg_x10 = SCHOOL_TRACK_HEADING_AB_X10;
        leg->heading_end_deg_x10 = SCHOOL_TRACK_HEADING_AB_X10;
        return true;
    }

    if ((start_node == ROUTE_NODE_B) && (end_node == ROUTE_NODE_C)) {
        leg->type = SCHOOL_LEG_ARC;
        leg->line_tracked = true;
        leg->length_mm = (uint16_t) (314U * SCHOOL_TRACK_ARC_RADIUS_MM / 100U);
        leg->heading_start_deg_x10 = SCHOOL_TRACK_HEADING_BC_ENTRY_X10;
        leg->heading_end_deg_x10 = SCHOOL_TRACK_HEADING_BC_ENTRY_X10 + 1800;
        return true;
    }

    if ((start_node == ROUTE_NODE_C) && (end_node == ROUTE_NODE_B)) {
        leg->type = SCHOOL_LEG_ARC;
        leg->line_tracked = true;
        leg->length_mm = (uint16_t) (314U * SCHOOL_TRACK_ARC_RADIUS_MM / 100U);
        leg->heading_start_deg_x10 = SCHOOL_TRACK_HEADING_CB_ENTRY_X10;
        leg->heading_end_deg_x10 = SCHOOL_TRACK_HEADING_CB_ENTRY_X10 + 1800;
        return true;
    }

    if ((start_node == ROUTE_NODE_C) && (end_node == ROUTE_NODE_D)) {
        leg->type = SCHOOL_LEG_STRAIGHT;
        leg->length_mm = SCHOOL_TRACK_STRAIGHT_MM;
        leg->heading_start_deg_x10 = SCHOOL_TRACK_HEADING_CD_X10;
        leg->heading_end_deg_x10 = SCHOOL_TRACK_HEADING_CD_X10;
        return true;
    }

    if ((start_node == ROUTE_NODE_D) && (end_node == ROUTE_NODE_A)) {
        leg->type = SCHOOL_LEG_ARC;
        leg->line_tracked = true;
        leg->length_mm = (uint16_t) (314U * SCHOOL_TRACK_ARC_RADIUS_MM / 100U);
        leg->heading_start_deg_x10 = SCHOOL_TRACK_HEADING_DA_ENTRY_X10;
        leg->heading_end_deg_x10 = 0;
        return true;
    }

    if ((start_node == ROUTE_NODE_A) && (end_node == ROUTE_NODE_C)) {
        const uint8_t loop_index = car_app_mode3_current_loop_index(&g_app);

        leg->type = SCHOOL_LEG_STRAIGHT;
        leg->length_mm = g_app.tuning.diagonal_mm;
        leg->heading_start_deg_x10 = g_app.tuning.mode3_ac_heading_x10[loop_index];
        leg->heading_end_deg_x10 = g_app.tuning.mode3_ac_heading_x10[loop_index];
        return true;
    }

    if ((start_node == ROUTE_NODE_B) && (end_node == ROUTE_NODE_D)) {
        const uint8_t loop_index = car_app_mode3_current_loop_index(&g_app);

        leg->type = SCHOOL_LEG_STRAIGHT;
        leg->length_mm = g_app.tuning.diagonal_mm;
        leg->heading_start_deg_x10 = g_app.tuning.mode3_bd_heading_x10[loop_index];
        leg->heading_end_deg_x10 = g_app.tuning.mode3_bd_heading_x10[loop_index];
        return true;
    }

    return false;
}

static const car_app_profile_t *car_app_profile_from_id(car_app_profile_id_t profile_id)
{
    uint8_t index = (uint8_t) profile_id;

    if (index >= (uint8_t) CAR_APP_PROFILE_COUNT) {
        index = (uint8_t) CAR_APP_PROFILE_SAFE;
    }

    return &g_profiles[index];
}

const char *car_app_get_profile_name(car_app_profile_id_t profile_id)
{
    return car_app_profile_from_id(profile_id)->name;
}

static int16_t car_app_mode_base_speed(
    const car_app_t *app)
{
    switch (app->selected_mode) {
        case CHASSIS_MODE_1:
            return app->tuning.base_speed_mode_1;
        case CHASSIS_MODE_2:
            return app->tuning.base_speed_mode_2;
        case CHASSIS_MODE_3:
            return app->tuning.base_speed_mode_3;
        default:
            return app->tuning.base_speed_mode_1;
    }
}

static int16_t car_app_leg_base_speed(
    const car_app_t *app, const school_leg_t *leg)
{
    int32_t base_speed;

    if ((app == NULL) || (leg == NULL)) {
        return 0;
    }

    base_speed = car_app_mode_base_speed(app);
    if (leg->line_tracked) {
        base_speed += LINE_TRACK_BASE_SPEED_BOOST_PPS;
    }

    return (int16_t) clamp_i32(base_speed, 0, app->profile->wheel_speed_max_pps);
}

static int16_t speed_pid_step(
    speed_pid_t *pid,
    const car_app_tuning_t *tuning,
    const car_app_profile_t *profile,
    int16_t target_pps,
    int16_t measured_pps)
{
    const int32_t error = (int32_t) target_pps - (int32_t) measured_pps;
    const int32_t feedforward = (int32_t) target_pps * tuning->speed_feedforward_num;
    int32_t output;

    (void) profile;
    pid->integral = clamp_i32(
        pid->integral + error,
        -tuning->speed_pid.integral_limit,
        tuning->speed_pid.integral_limit);
    output = feedforward +
             ((int32_t) tuning->speed_pid.kp_num * error) /
                 (int32_t) tuning->speed_pid.kp_den +
             ((int32_t) tuning->speed_pid.ki_num * pid->integral) /
                 (int32_t) tuning->speed_pid.ki_den +
             ((int32_t) tuning->speed_pid.kd_num * (error - (int32_t) pid->last_error)) /
                 (int32_t) tuning->speed_pid.kd_den;
    output = clamp_i32(output, -tuning->speed_pid.output_limit, tuning->speed_pid.output_limit);
    pid->last_error = (int16_t) error;

    if ((target_pps == 0) && (abs_i16(measured_pps) < 50)) {
        speed_pid_reset(pid);
        return 0;
    }

    if ((target_pps > 0) && (output < 0)) {
        output = 0;
    }

    if ((output != 0) && (abs_i16((int16_t) output) < tuning->speed_min_effective_pwm)) {
        output = (output < 0) ? -tuning->speed_min_effective_pwm : tuning->speed_min_effective_pwm;
    }

    return (int16_t) output;
}

static bool line_sensor_calculate_error(
    const line_sensor_sample_t *sample, line_track_state_t *line_state)
{
    static const int16_t weights[8] = { -600, -350, -200, -50, 50, 200, 350, 600 };
    int32_t weighted_sum = 0;
    uint8_t active_count = 0U;
    uint8_t index;
    const uint8_t active_mask = (uint8_t) (sample->digital_active_mask & 0xFFU);

    for (index = 0U; index < 8U; ++index) {
        const uint8_t bit = (uint8_t) (1U << index);

        if ((active_mask & bit) != 0U) {
            weighted_sum += weights[index];
            active_count++;
        }
    }

    line_state->active_mask = active_mask;
    line_state->active_count = active_count;
    line_state->raw_mask = sample->digital_raw;
    line_state->max_index = sample->max_index;
    line_state->max_value = sample->max_value;

    if ((!sample->online) || (active_count == 0U)) {
        line_state->has_line = false;
        line_state->error = 0;
        return false;
    }

    line_state->has_line = true;
    line_state->error = (int16_t) (weighted_sum / (int32_t) active_count);
    return true;
}

static void car_app_reset_motor_command(car_app_t *app)
{
    app->motor_command.left_target_pps = 0;
    app->motor_command.right_target_pps = 0;
    app->motor_command.left_pwm = 0;
    app->motor_command.right_pwm = 0;
    speed_pid_reset(&app->left_speed_pid);
    speed_pid_reset(&app->right_speed_pid);
    app->arc_entry_active = false;
}

static void car_app_stop_manual_motor(car_app_t *app)
{
    app->manual_motor_ticks_remaining = 0U;
    app->manual_motor_command.left_target_pps = 0;
    app->manual_motor_command.right_target_pps = 0;
    app->manual_motor_command.left_pwm = 0;
    app->manual_motor_command.right_pwm = 0;
}

static uint32_t car_app_debounce_buttons(car_app_t *app, uint32_t raw_mask)
{
    uint32_t pressed_mask = 0U;

    if (raw_mask != app->button_candidate_mask) {
        app->button_candidate_mask = raw_mask;
        app->button_debounce_ticks = 0U;
    } else if (app->button_debounce_ticks < BUTTON_DEBOUNCE_TICKS) {
        app->button_debounce_ticks++;
    }

    if ((app->button_debounce_ticks >= BUTTON_DEBOUNCE_TICKS) &&
        (app->button_candidate_mask != app->prev_button_mask)) {
        pressed_mask = app->button_candidate_mask & (~app->prev_button_mask);
        app->prev_button_mask = app->button_candidate_mask;
    }

    app->current_button_mask = app->prev_button_mask;
    app->last_pressed_button_mask = pressed_mask;
    return pressed_mask;
}

static void car_app_apply_push_capture_no_motor(car_app_t *app)
{
#if PUSH_CAPTURE_NO_MOTOR
    app->motor_command.left_pwm = 0;
    app->motor_command.right_pwm = 0;
#else
    (void) app;
#endif
}

static void car_app_queue_beep(car_app_t *app, uint16_t frequency_hz, uint16_t duration_ms)
{
    (void) frequency_hz;
    app->beep_pending = true;
    app->beep_frequency_hz = APP_BEEP_FULL_VOLUME_HZ;
    app->beep_duration_ms = duration_ms;
}

static const route_plan_t *car_app_get_plan(const car_app_t *app)
{
    return &g_route_plans[(uint8_t) app->selected_mode];
}

static bool car_app_get_current_leg(const car_app_t *app, school_leg_t *leg)
{
    const route_plan_t *plan = car_app_get_plan(app);

    if ((app == NULL) || (leg == NULL)) {
        return false;
    }

    if ((app->route_index + 1U) >= plan->node_count) {
        return false;
    }

    return school_leg_from_nodes(
        plan->nodes[app->route_index],
        plan->nodes[app->route_index + 1U],
        leg);
}

static int32_t car_app_leg_target_counts(const school_leg_t *leg)
{
    if (leg == NULL) {
        return 0;
    }

    if (g_app.contest_task == CONTEST_TASK_BASIC_1) {
        if ((leg->start_node == ROUTE_NODE_A) && (leg->end_node == ROUTE_NODE_B)) {
            return MODE1_AB_TARGET_COUNTS;
        }
        if ((leg->start_node == ROUTE_NODE_B) && (leg->end_node == ROUTE_NODE_C)) {
            return MODE1_BC_TARGET_COUNTS;
        }
    }

    return ((int32_t) leg->length_mm * (int32_t) g_app.tuning.odom_counts_per_mm_x100) / 100;
}

static int32_t car_app_current_leg_travel_counts(const car_app_t *app)
{
    return app->travel_count_total - app->leg_start_travel_count;
}

static void car_app_update_gyro_heading(car_app_t *app)
{
    school_leg_t leg;

    if ((app == NULL) ||
        (app->state != APP_STATE_RUNNING) ||
        (app->task_phase != TASK_PHASE_TRACK) ||
        (!app->imu_state.gyro_valid) ||
        (!car_app_get_current_leg(app, &leg)) ||
        leg.line_tracked) {
        return;
    }

    if (!app->gyro_heading_valid) {
        app->gyro_relative_yaw_deg = 0.0f;
        app->gyro_heading_valid = true;
    }

    app->gyro_relative_yaw_deg = normalize_heading_deg(
        app->gyro_relative_yaw_deg +
        (app->imu_state.gyro_z_dps / (float) APP_CONTROL_HZ));
}

static bool car_app_arc_entry_active_for_leg(
    const car_app_t *app, const school_leg_t *leg)
{
    if ((app == NULL) || (leg == NULL)) {
        return false;
    }

    return leg->line_tracked &&
           (leg->type == SCHOOL_LEG_ARC) &&
           (car_app_current_leg_travel_counts(app) < ARC_ENTRY_COUNTS);
}

static int16_t car_app_mode1_ab_heading_target_x10(
    const car_app_t *app)
{
    int32_t leg_counts;
    int32_t target_x10;

    if (app == NULL) {
        return 0;
    }

    leg_counts = car_app_current_leg_travel_counts(app);
    leg_counts = clamp_i32(leg_counts, 0, MODE1_AB_TARGET_COUNTS);

    target_x10 =
        ((int32_t) MODE1_AB_YAW_COMP_END_X10 * leg_counts) /
        (int32_t) MODE1_AB_TARGET_COUNTS;

    if (leg_counts >= app->tuning.mode1_preaim_start_counts) {
        target_x10 += app->tuning.mode1_preaim_heading_x10;
    }

    target_x10 += app->tuning.target_heading_deg_x10;
    return normalize_heading_deg_x10((int16_t) target_x10);
}

static int16_t car_app_current_leg_heading_target_x10(
    const car_app_t *app, const school_leg_t *leg)
{
    if ((app == NULL) || (leg == NULL)) {
        return 0;
    }

    if ((app->contest_task == CONTEST_TASK_BASIC_1) &&
        (app->route_index == 0U) &&
        (leg->start_node == ROUTE_NODE_A) &&
        (leg->end_node == ROUTE_NODE_B)) {
        return car_app_mode1_ab_heading_target_x10(app);
    }

    if (((app->contest_task == CONTEST_TASK_BASIC_2) ||
         (app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM)) &&
        (leg->type == SCHOOL_LEG_STRAIGHT) &&
        (((leg->start_node == ROUTE_NODE_A) && (leg->end_node == ROUTE_NODE_B)) ||
         ((leg->start_node == ROUTE_NODE_C) && (leg->end_node == ROUTE_NODE_D)))) {
        int16_t mode2_heading_x10 = app->tuning.mode2_ab_heading_x10;

        if ((leg->start_node == ROUTE_NODE_C) &&
            (leg->end_node == ROUTE_NODE_D)) {
            mode2_heading_x10 = app->tuning.mode2_cd_heading_x10;
        }
        return normalize_heading_deg_x10(
            (int16_t) (app->tuning.target_heading_deg_x10 + mode2_heading_x10));
    }

    if (((app->contest_task == CONTEST_TASK_BASIC_3) ||
         (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM)) &&
        (leg->type == SCHOOL_LEG_STRAIGHT)) {
        return normalize_heading_deg_x10(
            (int16_t) (leg->heading_start_deg_x10 + app->tuning.target_heading_deg_x10));
    }

    return (int16_t) (leg->heading_start_deg_x10 + app->tuning.target_heading_deg_x10);
}

static int16_t car_app_arc_feedforward_pps_for_leg(
    const car_app_t *app, const school_leg_t *leg)
{
    if ((app == NULL) ||
        (leg == NULL) ||
        (!leg->line_tracked) ||
        (leg->type != SCHOOL_LEG_ARC)) {
        return 0;
    }

    if (((leg->start_node == ROUTE_NODE_B) && (leg->end_node == ROUTE_NODE_C)) ||
        ((leg->start_node == ROUTE_NODE_D) && (leg->end_node == ROUTE_NODE_A))) {
        return app->tuning.mode1_arc_feedforward_pps;
    }

    if ((leg->start_node == ROUTE_NODE_C) && (leg->end_node == ROUTE_NODE_B)) {
        return (int16_t) -app->tuning.mode1_arc_feedforward_pps;
    }

    return 0;
}

static int32_t car_app_line_steering_term_pps(
    car_app_t *app, const school_leg_t *leg, int16_t previous_error)
{
    int16_t line_error;
    int32_t term;
    int16_t arc_feedforward_pps;

    if ((app == NULL) || (leg == NULL)) {
        return 0;
    }

    line_error = app->line_state.has_line ? app->line_state.error : previous_error;
    term = control_pid_step(
        &app->line_pid,
        &app->tuning.line_pid,
        line_error);

    arc_feedforward_pps = car_app_arc_feedforward_pps_for_leg(app, leg);
    if ((arc_feedforward_pps != 0) &&
        (app->line_transition_ticks >= LINE_TRANSITION_BLEND_TICKS) &&
        (app->line_state.active_count >= 4U) &&
        (abs_i16(line_error) <= 60)) {
        term += arc_feedforward_pps;
    }

    return clamp_i32(term, -LINE_TURN_OUTPUT_LIMIT_PPS, LINE_TURN_OUTPUT_LIMIT_PPS);
}

static bool car_app_has_line(const car_app_t *app)
{
    if (app == NULL) {
        return false;
    }

    return app->line_state.has_line;
}

static bool car_app_open_leg_has_overrun(
    const car_app_t *app, const school_leg_t *leg)
{
    int32_t target;

    if ((app == NULL) || (leg == NULL) || leg->line_tracked) {
        return false;
    }

    target = car_app_leg_target_counts(leg);
    if (target <= 0) {
        return false;
    }

    return car_app_current_leg_travel_counts(app) >=
           ((target * (int32_t) app->tuning.open_max_overrun_percent) / 100);
}

static bool car_app_line_leg_has_overrun(
    const car_app_t *app, const school_leg_t *leg)
{
    int32_t target;

    if ((app == NULL) || (leg == NULL) || (!leg->line_tracked)) {
        return false;
    }

    target = car_app_leg_target_counts(leg);
    if (target <= 0) {
        return false;
    }

    return car_app_current_leg_travel_counts(app) >=
           ((target * (int32_t) LINE_LEG_MAX_OVERRUN_PERCENT) / 100);
}

static bool car_app_route2_open_leg_ready_to_switch(car_app_t *app, const school_leg_t *leg)
{
    if ((app == NULL) || (leg == NULL)) {
        return false;
    }

    if (app->line_state.has_line) {
        if (app->open_line_confirm_ticks < MODE1_AB_LINE_CONFIRM_TICKS) {
            app->open_line_confirm_ticks++;
        }
    } else {
        app->open_line_confirm_ticks = 0U;
    }

    if ((app->open_line_confirm_ticks >= MODE1_AB_LINE_CONFIRM_TICKS) &&
        (car_app_current_leg_travel_counts(app) >=
         ((int32_t) MODE1_AB_TARGET_COUNTS * MODE1_AB_LINE_FLOOR_PERCENT / 100))) {
        return true;
    }

    return car_app_open_leg_has_overrun(app, leg);
}

static bool car_app_mode3_diagonal_ready_to_switch(car_app_t *app, const school_leg_t *leg)
{
    int32_t target;
    int32_t leg_counts;
    int32_t line_floor;

    if ((app == NULL) || (leg == NULL) || leg->line_tracked) {
        return false;
    }

    target = car_app_leg_target_counts(leg);
    if (target <= 0) {
        return false;
    }

    leg_counts = car_app_current_leg_travel_counts(app);
    line_floor = (target * MODE3_DIAGONAL_LINE_FLOOR_PERCENT) / 100;

    if (leg_counts < line_floor) {
        app->open_line_confirm_ticks = 0U;
        return false;
    }

    if (app->line_state.has_line &&
        (app->line_state.active_count >= MODE3_DIAGONAL_LINE_ACTIVE_MIN)) {
        if (app->open_line_confirm_ticks < app->tuning.open_reacquire_confirm_ticks) {
            app->open_line_confirm_ticks++;
        }
    } else {
        app->open_line_confirm_ticks = 0U;
    }

    if (app->open_line_confirm_ticks >= app->tuning.open_reacquire_confirm_ticks) {
        return true;
    }

    return false;
}

static bool car_app_mode3_arc_ready_to_switch(car_app_t *app, const school_leg_t *leg)
{
    int32_t target;
    int32_t leg_counts;

    if ((app == NULL) || (leg == NULL) || (!leg->line_tracked)) {
        return false;
    }

    target = car_app_leg_target_counts(leg);
    if (target <= 0) {
        return false;
    }

    leg_counts = car_app_current_leg_travel_counts(app);

    if (leg_counts < MODE1_BC_EXIT_MIN_COUNTS) {
        app->node_release_ticks = 0U;
        return false;
    }

    if (!app->line_state.has_line) {
        if (app->node_release_ticks < MODE1_BC_LINE_LOST_CONFIRM_TICKS) {
            app->node_release_ticks++;
        }
    } else {
        app->node_release_ticks = 0U;
    }

    if (app->node_release_ticks >= MODE1_BC_LINE_LOST_CONFIRM_TICKS) {
        return true;
    }

    return car_app_line_leg_has_overrun(app, leg);
}

static int32_t ecg_level_to_tilt(ecg_level_t level)
{
    switch (level) {
        case ECG_LEVEL_SMALL_PEAK:
            return ECG_SMALL_TILT_US;
        case ECG_LEVEL_BIG_PEAK:
            return ECG_BIG_TILT_US;
        case ECG_LEVEL_VALLEY:
            return ECG_VALLEY_TILT_US;
        case ECG_LEVEL_Q_VALLEY:
            return interpolate_i32(ECG_BASE_TILT_US, ECG_VALLEY_TILT_US, 1U, 3U);
        case ECG_LEVEL_BASE:
        default:
            return ECG_BASE_TILT_US;
    }
}

static int32_t ecg_pan_delta_at_x(uint32_t total_x)
{
    if (total_x > ECG_TOTAL_X) {
        total_x = ECG_TOTAL_X;
    }

    return interpolate_i32(
        0,
        (int32_t) ECG_RIGHT_PAN_US - (int32_t) ECG_LEFT_PAN_US,
        total_x,
        ECG_TOTAL_X);
}

static int32_t ecg_tilt_delta_at_cycle_x(uint16_t cycle_x)
{
    const uint32_t knot_count = (uint32_t) (sizeof(g_ecg_knots) / sizeof(g_ecg_knots[0]));
    uint32_t index;

    if (cycle_x >= ECG_CYCLE_X) {
        return ecg_level_to_tilt(g_ecg_knots[knot_count - 1U].level) - ECG_BASE_TILT_US;
    }

    for (index = 0U; index < (knot_count - 1U); ++index) {
        const ecg_knot_t *from = &g_ecg_knots[index];
        const ecg_knot_t *to = &g_ecg_knots[index + 1U];

        if ((cycle_x >= from->x) && (cycle_x <= to->x)) {
            const int32_t from_tilt = ecg_level_to_tilt(from->level);
            const int32_t to_tilt = ecg_level_to_tilt(to->level);
            const uint32_t den = (uint32_t) (to->x - from->x);
            const uint32_t num = (uint32_t) (cycle_x - from->x);

            return interpolate_i32(from_tilt, to_tilt, num, den) - ECG_BASE_TILT_US;
        }
    }

    return 0;
}

static bool car_app_update_ecg_locate(car_app_t *app)
{
    int16_t desired_x;
    int16_t desired_y;
    int16_t err_x;
    int16_t err_y;
    int16_t pan_delta;
    int16_t tilt_delta;
    gimbal_state_t gimbal_state;
    char log_buffer[128];

    if ((app == NULL) ||
        (app->vision_state.target_update_count == app->ecg_last_target_update_count)) {
        return false;
    }
    app->ecg_last_target_update_count = app->vision_state.target_update_count;

    if ((!app->vision_state.frame_valid) || (!app->vision_state.laser_valid)) {
        app->ecg_locate_confirm_updates = 0U;
        car_app_reset_ecg_locate_pid(app);
        return false;
    }

    desired_x = app->vision_state.frame_center_x - ECG_START_LEFT_OFFSET_PX;
    desired_y = app->vision_state.frame_center_y + ECG_BASELINE_Y_OFFSET_PX;
    err_x = (int16_t) (app->vision_state.laser_center_x - desired_x);
    err_y = (int16_t) (app->vision_state.laser_center_y - desired_y);

    if ((abs_i16(err_x) <= ECG_LOCATE_DEADBAND_PX) &&
        (abs_i16(err_y) <= ECG_LOCATE_DEADBAND_PX)) {
        if (app->ecg_locate_confirm_updates < UINT8_MAX) {
            app->ecg_locate_confirm_updates++;
        }
        if (app->ecg_locate_confirm_updates >= ECG_LOCATE_CONFIRM_UPDATES) {
            gimbal_servo_get_state(&gimbal_state);
            app->ecg_origin_pan_us = gimbal_state.pan_target_us;
            app->ecg_origin_tilt_us = gimbal_state.tilt_target_us;
            app->ecg_elapsed_ticks = 0U;
            app->ecg_next_update_ticks = 0U;
            app->ecg_stage = ECG_STAGE_DRAW;
            return true;
        }
        return false;
    }

    app->ecg_locate_confirm_updates = 0U;
    pan_delta = car_app_ecg_locate_pid_step(&app->ecg_locate_pid[0], err_x);
    if (ECG_LOCATE_PAN_REVERSE != 0U) {
        pan_delta = (int16_t) -pan_delta;
    }
    tilt_delta = car_app_ecg_locate_pid_step(&app->ecg_locate_pid[1], err_y);
    gimbal_servo_offset(pan_delta, tilt_delta);
    gimbal_servo_get_state(&gimbal_state);
    (void) snprintf(
        log_buffer,
        sizeof(log_buffer),
        "ECGLOC,fx=%d,fy=%d,lx=%d,ly=%d,dx=%d,dy=%d,ex=%d,ey=%d,pan=%d,tilt=%d\r\n",
        app->vision_state.frame_center_x,
        app->vision_state.frame_center_y,
        app->vision_state.laser_center_x,
        app->vision_state.laser_center_y,
        desired_x,
        desired_y,
        err_x,
        err_y,
        (int) gimbal_state.pan_target_us,
        (int) gimbal_state.tilt_target_us);
    board_debug_write(log_buffer);
    return false;
}

static void car_app_update_aim_gimbal_search(car_app_t *app)
{
    gimbal_state_t gimbal_state;
    int32_t predicted_pan_us;
    int32_t predicted_tilt_us;
    int32_t anchor_pan_us;
    int32_t anchor_tilt_us;
    int32_t target_pan_us;
    int32_t target_tilt_us;
    int16_t pan_limit_us;
    int16_t tilt_limit_us;
    int16_t tilt_delta = 0;

    if (app == NULL) {
        return;
    }
    if (!app->aim_last_seen_valid) {
        car_app_remember_aim_seen_pose(app);
    }

    if (app->aim_lost_ticks < UINT16_MAX) {
        app->aim_lost_ticks++;
    }
    if (app->aim_lost_ticks < GIMBAL_AIM_SEARCH_START_TICKS) {
        return;
    }
    if (app->aim_search_update_ticks > 0U) {
        app->aim_search_update_ticks--;
        return;
    }
    app->aim_search_update_ticks =
        (uint16_t) ((GIMBAL_AIM_SEARCH_UPDATE_TICKS > 0U) ?
                   (GIMBAL_AIM_SEARCH_UPDATE_TICKS - 1U) : 0U);

    if (app->aim_search_pan_dir == 0) {
        app->aim_search_pan_dir = 1;
    }
    if (app->aim_search_tilt_dir == 0) {
        app->aim_search_tilt_dir = 1;
    }

    if (car_app_predict_aim_anchor(app, &predicted_pan_us, &predicted_tilt_us)) {
        car_app_blend_aim_anchor(app, predicted_pan_us, predicted_tilt_us, &anchor_pan_us, &anchor_tilt_us);
    } else {
        anchor_pan_us = app->aim_last_seen_pan_us;
        anchor_tilt_us = app->aim_last_seen_tilt_us;
    }

    pan_limit_us = (int16_t) clamp_i32(app->tuning.aim_pred_window_pan_us, 0, 400);
    tilt_limit_us = (int16_t) clamp_i32(app->tuning.aim_pred_window_tilt_us, 0, 200);

    app->aim_search_pan_offset_us =
        (int16_t) (app->aim_search_pan_offset_us +
                   (app->aim_search_pan_dir * GIMBAL_AIM_SEARCH_PAN_STEP_US));
    if (app->aim_search_pan_offset_us >= pan_limit_us) {
        app->aim_search_pan_offset_us = pan_limit_us;
        app->aim_search_pan_dir = -1;
        tilt_delta = (int16_t) (app->aim_search_tilt_dir * GIMBAL_AIM_SEARCH_TILT_STEP_US);
    } else if (app->aim_search_pan_offset_us <= -pan_limit_us) {
        app->aim_search_pan_offset_us = (int16_t) -pan_limit_us;
        app->aim_search_pan_dir = 1;
        tilt_delta = (int16_t) (app->aim_search_tilt_dir * GIMBAL_AIM_SEARCH_TILT_STEP_US);
    }

    if (tilt_delta != 0) {
        app->aim_search_tilt_offset_us =
            (int16_t) (app->aim_search_tilt_offset_us + tilt_delta);
        if (app->aim_search_tilt_offset_us >= tilt_limit_us) {
            app->aim_search_tilt_offset_us = tilt_limit_us;
            app->aim_search_tilt_dir = -1;
        } else if (app->aim_search_tilt_offset_us <= -tilt_limit_us) {
            app->aim_search_tilt_offset_us = (int16_t) -tilt_limit_us;
            app->aim_search_tilt_dir = 1;
        }
    }

    gimbal_servo_get_state(&gimbal_state);
    target_pan_us = slew_i32(
        gimbal_state.pan_target_us,
        anchor_pan_us + app->aim_search_pan_offset_us,
        app->tuning.aim_pred_settle_step_us);
    target_tilt_us = slew_i32(
        gimbal_state.tilt_target_us,
        anchor_tilt_us + app->aim_search_tilt_offset_us,
        app->tuning.aim_pred_settle_step_us);

    gimbal_servo_set_target(
        target_pan_us,
        target_tilt_us);
}

static void car_app_update_aim_gimbal_pid(car_app_t *app)
{
    int16_t pan_delta;
    int16_t tilt_delta;

    if ((app == NULL) ||
        (app->state != APP_STATE_RUNNING) ||
        ((app->contest_task != CONTEST_TASK_ADV_ROUTE2_AIM) &&
         (app->contest_task != CONTEST_TASK_ADV_ROUTE3_AIM))) {
        car_app_reset_gimbal_aim_pid(app);
        return;
    }

    if (!app->vision_state.frame_valid) {
        gimbal_pid_axis_reset(&app->gimbal_aim_pid[0]);
        gimbal_pid_axis_reset(&app->gimbal_aim_pid[1]);
        car_app_update_aim_gimbal_search(app);
        return;
    }
    car_app_remember_aim_seen_pose(app);

    if ((app->vision_state.target_update_count == app->aim_last_target_update_count) ||
        (!app->vision_state.laser_valid)) {
        gimbal_pid_axis_reset(&app->gimbal_aim_pid[0]);
        gimbal_pid_axis_reset(&app->gimbal_aim_pid[1]);
        car_app_reset_gimbal_aim_search(app);
        return;
    }
    app->aim_last_target_update_count = app->vision_state.target_update_count;
    car_app_reset_gimbal_aim_search(app);

    pan_delta = car_app_gimbal_aim_pid_step(&app->gimbal_aim_pid[0], app->vision_state.err_x);
    if (GIMBAL_AIM_PAN_REVERSE != 0U) {
        pan_delta = (int16_t) -pan_delta;
    }
    tilt_delta = car_app_gimbal_aim_pid_step(&app->gimbal_aim_pid[1], app->vision_state.err_y);
    if (GIMBAL_AIM_TILT_REVERSE != 0U) {
        tilt_delta = (int16_t) -tilt_delta;
    }

    gimbal_servo_offset(pan_delta, tilt_delta);
}

static void car_app_update_ecg_task(car_app_t *app)
{
    const uint16_t settle_ticks = (uint16_t) ((ECG_SETTLE_MS * APP_CONTROL_HZ) / 1000U);
    const uint16_t total_ticks = (uint16_t) ((ECG_TOTAL_TIME_MS * APP_CONTROL_HZ) / 1000U);
    uint32_t draw_ticks;
    uint32_t draw_elapsed;
    uint32_t total_x;
    uint16_t cycle_x;
    int32_t pan_target_us;
    int32_t tilt_target_us;
    gimbal_state_t gimbal_state;

    if ((app == NULL) || (app->contest_task != CONTEST_TASK_ADV_ECG) ||
        (app->state != APP_STATE_RUNNING)) {
        return;
    }

    car_app_reset_motor_command(app);
    if (!app->ecg_active) {
        app->ecg_active = true;
        app->ecg_stage = ECG_STAGE_LOCATE;
        app->ecg_locate_confirm_updates = 0U;
        app->ecg_elapsed_ticks = 0U;
        app->ecg_next_update_ticks = 0U;
        app->ecg_last_target_update_count = app->vision_state.target_update_count;
        car_app_reset_ecg_locate_pid(app);
        gimbal_servo_set_enabled(true);
        gimbal_servo_sync_position(ECG_MOUNT_PAN_US, ECG_MOUNT_TILT_US);
        gimbal_servo_get_state(&gimbal_state);
        app->ecg_origin_pan_us = gimbal_state.pan_target_us;
        app->ecg_origin_tilt_us = gimbal_state.tilt_target_us;
        return;
    }

    if (app->ecg_elapsed_ticks < UINT16_MAX) {
        app->ecg_elapsed_ticks++;
    }

    if (app->ecg_stage == ECG_STAGE_LOCATE) {
        if (car_app_update_ecg_locate(app)) {
            car_app_reset_ecg_locate_pid(app);
            return;
        }
        return;
    }

    if (app->ecg_elapsed_ticks < settle_ticks) {
        return;
    }

    if (app->ecg_next_update_ticks > 0U) {
        app->ecg_next_update_ticks--;
        return;
    }
    app->ecg_next_update_ticks = (uint16_t) ((ECG_UPDATE_TICKS > 0U) ? (ECG_UPDATE_TICKS - 1U) : 0U);

    draw_ticks = (total_ticks > settle_ticks) ? (uint32_t) (total_ticks - settle_ticks) : 1U;
    draw_elapsed = (uint32_t) (app->ecg_elapsed_ticks - settle_ticks);
    if (draw_elapsed > draw_ticks) {
        draw_elapsed = draw_ticks;
    }

    total_x = (ECG_TOTAL_X * draw_elapsed + (draw_ticks / 2U)) / draw_ticks;
    cycle_x = (uint16_t) (total_x % ECG_CYCLE_X);
    if (total_x >= ECG_TOTAL_X) {
        cycle_x = ECG_CYCLE_X;
    }

    pan_target_us = app->ecg_origin_pan_us + ecg_pan_delta_at_x(total_x);
    tilt_target_us = app->ecg_origin_tilt_us + ecg_tilt_delta_at_cycle_x(cycle_x);
    gimbal_servo_set_target(pan_target_us, tilt_target_us);

    if (app->ecg_elapsed_ticks >= total_ticks) {
        app->task_phase = TASK_PHASE_FINISHED;
        app->state = APP_STATE_STOPPED;
        car_app_reset_ecg_runtime(app);
        app->led_on = false;
        app->laser_power_on = false;
        gimbal_servo_set_enabled(false);
        car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, app->profile->stop_event_beep_ms);
    }
}

static void car_app_handle_selection_buttons(car_app_t *app, uint32_t pressed_mask)
{
    if ((pressed_mask & BUTTON_MODE_1) != 0U) {
        car_app_select_task(app, CONTEST_TASK_BASIC_2);
        car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, 45U);
    }

    if ((pressed_mask & BUTTON_MODE_2) != 0U) {
        car_app_select_task(app, CONTEST_TASK_BASIC_1);
        car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, 45U);
    }

    if ((pressed_mask & BUTTON_MODE_3) != 0U) {
        if ((app->last_selection_button == SELECTION_BUTTON_MODE3) &&
            (app->contest_task == CONTEST_TASK_BASIC_3)) {
            app->mode3_loops++;
            if (app->mode3_loops > MODE3_LOOP_MAX) {
                app->mode3_loops = MODE3_LOOP_MIN;
            }
        } else {
            app->contest_task = CONTEST_TASK_BASIC_3;
            app->selected_mode = CHASSIS_MODE_3;
            app->mode3_loops = MODE3_LOOP_MIN;
            car_app_reset_runtime_tuning(app);
        }
        app->selected_mode = CHASSIS_MODE_3;
        app->last_selection_button = SELECTION_BUTTON_MODE3;
        car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, 45U);
    }
}

static void car_app_handle_mode_button_holds(car_app_t *app)
{
    static const uint32_t masks[3] = { BUTTON_MODE_1, BUTTON_MODE_2, BUTTON_MODE_3 };
    static const contest_task_t tasks[3] = {
        CONTEST_TASK_ADV_ROUTE2_AIM,
        CONTEST_TASK_ADV_ECG,
        CONTEST_TASK_ADV_ROUTE3_AIM
    };
    uint8_t index;

    if (app == NULL) {
        return;
    }

    for (index = 0U; index < 3U; ++index) {
        if ((app->current_button_mask & masks[index]) != 0U) {
            if (app->mode_button_hold_ticks[index] < UINT16_MAX) {
                app->mode_button_hold_ticks[index]++;
            }
            if ((!app->mode_button_long_handled[index]) &&
                (app->mode_button_hold_ticks[index] >= BUTTON_LONG_PRESS_TICKS)) {
                car_app_select_task(app, tasks[index]);
                app->mode_button_long_handled[index] = true;
                car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, 90U);
            }
        } else {
            app->mode_button_hold_ticks[index] = 0U;
            app->mode_button_long_handled[index] = false;
        }
    }
}

static void car_app_print_button_event(const char *event)
{
    char buffer[80];
    int length;

    if (!SERIAL_EVENT_LOG_ENABLED) {
        return;
    }

    length = snprintf(
        buffer,
        sizeof(buffer),
        "CAR_EVT,%s,mode=%u,state=%u\r\n",
        event,
        (unsigned) g_app.selected_mode + 1U,
        (unsigned) g_app.state);
    if (length > 0) {
        board_debug_write(buffer);
    }
}

static void car_app_handle_start_button(car_app_t *app, uint32_t pressed_mask)
{
    if ((pressed_mask & BUTTON_START) != 0U) {
        if (app->state != APP_STATE_RUNNING) {
            car_app_start(app);
            car_app_print_button_event("START");
        } else {
            car_app_stop(app);
            car_app_print_button_event("STOP");
        }
    }
}

static void car_app_handle_auto_start(car_app_t *app)
{
#if AUTO_START_MODE1_ON_BOOT
    if (app->auto_start_pending && (app->state == APP_STATE_IDLE)) {
        app->auto_start_pending = false;
        car_app_select_basic_mode(app, CHASSIS_MODE_1);
        car_app_start(app);
        car_app_print_button_event("AUTO_START_MODE1");
    }
#else
    (void) app;
#endif
}

static void car_app_update_travel_odometer(car_app_t *app)
{
    const int32_t left_delta = app->encoder_state.left_total_count - app->prev_left_total_count;
    const int32_t right_delta = app->encoder_state.right_total_count - app->prev_right_total_count;

    app->travel_count_total += (abs_i32(left_delta) + abs_i32(right_delta)) / 2;
    app->prev_left_total_count = app->encoder_state.left_total_count;
    app->prev_right_total_count = app->encoder_state.right_total_count;
}

static void car_app_signal_node_event(car_app_t *app, uint16_t duration_ms)
{
    app->led_on = !app->led_on;
    car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, duration_ms);
}

static void car_app_start(car_app_t *app)
{
    const route_plan_t *plan = car_app_get_plan(app);

    app->state = APP_STATE_RUNNING;
    app->task_phase = TASK_PHASE_TRACK;
    app->route_index = 0U;
    app->completed_loops = 0U;
    app->active_loops =
        (app->selected_mode == CHASSIS_MODE_3) ? app->mode3_loops : plan->default_loops;
    app->node_confirm_ticks = 0U;
    app->node_release_ticks = 0U;
    app->hold_ticks_remaining = 0U;
    app->node_event_count = 0U;
    app->travel_count_total = 0;
    app->leg_start_travel_count = 0;
    app->prev_left_total_count = app->encoder_state.left_total_count;
    app->prev_right_total_count = app->encoder_state.right_total_count;
    app->last_node_trigger_travel_count = 0;
    app->last_event_node = ROUTE_NODE_A;
    app->node_detector_armed = false;
    car_app_stop_manual_motor(app);
    car_app_reset_motor_command(app);
    app->last_line_error = 0;
    app->line_was_ok = false;
    app->line_transition_ticks = 0U;
    car_app_reset_angle_pids(app);
    car_app_reset_gimbal_aim_pid(app);
    app->led_on = true;
    app->laser_power_on = car_app_task_uses_laser(app);
    car_app_reset_ecg_runtime(app);
    gimbal_servo_set_enabled(car_app_task_uses_laser(app));
    if (car_app_task_uses_laser(app)) {
        gimbal_servo_sync_position(ECG_MOUNT_PAN_US, ECG_MOUNT_TILT_US);
    }
    app->yaw_zero_valid = app->imu_state.angle_valid;
    app->yaw_zero_deg = app->imu_state.angle_valid ?
        (app->imu_state.yaw_deg + (float) app->tuning.yaw_zero_offset_deg_x10 / 10.0f) : 0.0f;
    car_app_reset_gyro_heading(app);
    car_app_reset_route2_bc_exit_candidate(app);
    app->open_line_confirm_ticks = 0U;
    app->bias_ramp_ticks = 0U;
    app->debug_print_divider = 1U;
    car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, app->profile->start_event_beep_ms);
}

static void car_app_stop(car_app_t *app)
{
    app->state = APP_STATE_STOPPED;
    app->task_phase = TASK_PHASE_FINISHED;
    app->hold_ticks_remaining = 0U;
    app->node_confirm_ticks = 0U;
    app->node_release_ticks = 0U;
    app->node_detector_armed = false;
    car_app_stop_manual_motor(app);
    car_app_reset_motor_command(app);
    app->led_on = false;
    app->laser_power_on = false;
    car_app_reset_ecg_runtime(app);
    car_app_reset_gimbal_aim_pid(app);
    gimbal_servo_set_enabled(false);
    app->open_line_confirm_ticks = 0U;
    app->line_transition_ticks = 0U;
    car_app_reset_route2_bc_exit_candidate(app);
    car_app_queue_beep(app, APP_BEEP_FULL_VOLUME_HZ, app->profile->stop_event_beep_ms);
}

static void car_app_handle_route_node(car_app_t *app)
{
    const route_plan_t *plan = car_app_get_plan(app);
    route_node_t reached_node;
    const bool is_mode1_mid_stop =
        (app->selected_mode == CHASSIS_MODE_1) &&
        (app->route_index == 0U) &&
        (plan->nodes[1] == ROUTE_NODE_B);
    bool reached_route_end;

    if ((app->route_index + 1U) >= plan->node_count) {
        return;
    }

    reached_node = plan->nodes[app->route_index + 1U];
    app->route_index++;
    app->node_event_count++;
    app->last_event_node = reached_node;
    app->leg_start_travel_count = app->travel_count_total;
    car_app_reset_gyro_heading(app);
    app->open_line_confirm_ticks = 0U;
    reached_route_end = (app->route_index >= (plan->node_count - 1U));

    if (is_mode1_mid_stop) {
        car_app_signal_node_event(app, app->profile->node_event_beep_ms);
        app->last_line_error = 0;
        app->line_was_ok = false;
        app->line_transition_ticks = 0U;
        return;
    }

    if (reached_route_end) {
        app->completed_loops++;
        if (app->active_loops > 1U) {
            app->active_loops--;
            app->route_index = 0U;
            app->leg_start_travel_count = app->travel_count_total;
            car_app_signal_node_event(app, app->profile->node_event_beep_ms);
            return;
        }

        car_app_stop(app);
        return;
    }

    car_app_signal_node_event(app, app->profile->node_event_beep_ms);
}

static void car_app_basic1_reach_node(car_app_t *app, route_node_t node)
{
    app->node_event_count++;
    app->last_event_node = node;
    app->leg_start_travel_count = app->travel_count_total;
    car_app_reset_gyro_heading(app);
    app->last_line_error = 0;
    app->line_was_ok = false;
    app->line_transition_ticks = 0U;
    car_app_reset_angle_pids(app);
    car_app_reset_speed_pids(app);
    app->open_line_confirm_ticks = 0U;
    app->node_confirm_ticks = 0U;
    app->node_release_ticks = 0U;
    car_app_signal_node_event(app, app->profile->node_event_beep_ms);

    if ((app->contest_task == CONTEST_TASK_BASIC_1) &&
        (app->selected_mode == CHASSIS_MODE_1) &&
        (node == ROUTE_NODE_B)) {
        app->task_phase = TASK_PHASE_STOP_HOLD;
        app->hold_ticks_remaining =
            (uint16_t) (((uint32_t) app->profile->mode1_stop_hold_ms *
                         (uint32_t) APP_CONTROL_HZ) / 1000U);
        car_app_reset_motor_command(app);
    }
}

static void car_app_update_basic1_task_state(car_app_t *app)
{
    if (app->route_index == 0U) {
        if (app->line_state.has_line) {
            if (app->open_line_confirm_ticks < MODE1_AB_LINE_CONFIRM_TICKS) {
                app->open_line_confirm_ticks++;
            }
        } else {
            app->open_line_confirm_ticks = 0U;
        }

        if (app->open_line_confirm_ticks >= MODE1_AB_LINE_CONFIRM_TICKS) {
            app->route_index = 1U;
            car_app_basic1_reach_node(app, ROUTE_NODE_B);
            car_app_reset_angle_pids(app);
        } else if (car_app_current_leg_travel_counts(app) >=
                   ((int32_t) MODE1_AB_TARGET_COUNTS * 130 / 100)) {
            app->route_index = 1U;
            car_app_basic1_reach_node(app, ROUTE_NODE_B);
            car_app_reset_angle_pids(app);
        }
        return;
    }

    if (app->route_index == 1U) {
        if (!app->line_state.has_line) {
            if (app->node_release_ticks < MODE1_BC_LINE_LOST_CONFIRM_TICKS) {
                app->node_release_ticks++;
            }
        } else {
            app->node_release_ticks = 0U;
        }

        if ((car_app_current_leg_travel_counts(app) >= MODE1_BC_EXIT_MIN_COUNTS) &&
            (app->node_release_ticks >= MODE1_BC_LINE_LOST_CONFIRM_TICKS)) {
            app->route_index = 2U;
            app->node_event_count++;
            app->last_event_node = ROUTE_NODE_C;
            app->leg_start_travel_count = app->travel_count_total;
            app->completed_loops = 1U;
            car_app_stop(app);
            car_app_reset_angle_pids(app);
        }
        return;
    }

    car_app_stop(app);
}

static void car_app_route2_reach_node(car_app_t *app, route_node_t node)
{
    app->route_index++;
    app->node_event_count++;
    app->last_event_node = node;
    app->leg_start_travel_count = app->travel_count_total;
    car_app_reset_gyro_heading(app);
    app->last_line_error = 0;
    app->line_was_ok = false;
    app->line_transition_ticks = 0U;
    app->open_line_confirm_ticks = 0U;
    app->node_confirm_ticks = 0U;
    app->node_release_ticks = 0U;
    app->node_detector_armed = false;
    car_app_reset_route2_bc_exit_candidate(app);
    car_app_reset_angle_pids(app);
    car_app_reset_speed_pids(app);

    if (node == ROUTE_NODE_A) {
        app->completed_loops = 1U;
        car_app_stop(app);
        return;
    }

    car_app_signal_node_event(app, app->profile->node_event_beep_ms);
}

static void car_app_update_basic2_task_state(car_app_t *app)
{
    school_leg_t leg;
    const int32_t leg_counts = car_app_current_leg_travel_counts(app);

    if (!car_app_get_current_leg(app, &leg)) {
        car_app_stop(app);
        return;
    }

    if ((leg.start_node == ROUTE_NODE_A) && (leg.end_node == ROUTE_NODE_B)) {
        app->node_release_ticks = 0U;
        car_app_reset_route2_bc_exit_candidate(app);

        if (car_app_route2_open_leg_ready_to_switch(app, &leg)) {
            car_app_route2_reach_node(app, ROUTE_NODE_B);
        }
        return;
    }

    if ((leg.start_node == ROUTE_NODE_B) && (leg.end_node == ROUTE_NODE_C)) {
        app->open_line_confirm_ticks = 0U;

        if (leg_counts < MODE1_BC_EXIT_MIN_COUNTS) {
            app->node_release_ticks = 0U;
            car_app_reset_route2_bc_exit_candidate(app);
            return;
        }

        if (app->line_state.has_line) {
            app->node_release_ticks = 0U;
            car_app_reset_route2_bc_exit_candidate(app);
            return;
        }

        if (!app->route2_bc_exit_candidate_valid) {
            app->route2_bc_exit_candidate_valid = true;
            app->route2_bc_exit_candidate_yaw_deg = app->imu_state.yaw_deg;
            app->route2_bc_exit_candidate_ryaw_x10 = car_app_relative_yaw_deg_x10(app);
            app->route2_bc_exit_candidate_lcnt = leg_counts;
        }

        if (app->node_release_ticks < MODE1_BC_LINE_LOST_CONFIRM_TICKS) {
            app->node_release_ticks++;
        }

        if (app->node_release_ticks >= MODE1_BC_LINE_LOST_CONFIRM_TICKS) {
            car_app_capture_yaw_zero(app, app->route2_bc_exit_candidate_yaw_deg);
            car_app_route2_reach_node(app, ROUTE_NODE_C);
        }
        return;
    }

    if ((leg.start_node == ROUTE_NODE_C) && (leg.end_node == ROUTE_NODE_D)) {
        app->node_release_ticks = 0U;
        car_app_reset_route2_bc_exit_candidate(app);

        if (car_app_route2_open_leg_ready_to_switch(app, &leg)) {
            car_app_route2_reach_node(app, ROUTE_NODE_D);
        }
        return;
    }

    if ((leg.start_node == ROUTE_NODE_D) && (leg.end_node == ROUTE_NODE_A)) {
        app->open_line_confirm_ticks = 0U;
        car_app_reset_route2_bc_exit_candidate(app);

        if (!app->line_state.has_line) {
            if (app->node_release_ticks < MODE1_BC_LINE_LOST_CONFIRM_TICKS) {
                app->node_release_ticks++;
            }
        } else {
            app->node_release_ticks = 0U;
        }

        if ((leg_counts >= MODE1_BC_EXIT_MIN_COUNTS) &&
            (app->node_release_ticks >= MODE1_BC_LINE_LOST_CONFIRM_TICKS)) {
            car_app_route2_reach_node(app, ROUTE_NODE_A);
        } else if (car_app_line_leg_has_overrun(app, &leg)) {
            car_app_route2_reach_node(app, ROUTE_NODE_A);
        }
        return;
    }

    car_app_handle_route_node(app);
}

static void car_app_update_basic3_task_state(car_app_t *app)
{
    school_leg_t leg;

    if (!car_app_get_current_leg(app, &leg)) {
        car_app_stop(app);
        return;
    }

    if (leg.line_tracked) {
        app->open_line_confirm_ticks = 0U;

        if (car_app_mode3_arc_ready_to_switch(app, &leg)) {
            car_app_handle_route_node(app);
        }
        return;
    }

    app->node_release_ticks = 0U;
    app->line_transition_ticks = 0U;

    if (car_app_mode3_diagonal_ready_to_switch(app, &leg)) {
        car_app_handle_route_node(app);
    }
}

static void car_app_update_task_state(car_app_t *app)
{
    school_leg_t leg;

    if (app->state != APP_STATE_RUNNING) {
        return;
    }

    if (car_app_is_stationary_task(app)) {
        car_app_reset_motor_command(app);
        car_app_update_ecg_task(app);
        return;
    }

    if (app->task_phase == TASK_PHASE_STOP_HOLD) {
        car_app_reset_motor_command(app);
        if (app->hold_ticks_remaining > 0U) {
            app->hold_ticks_remaining--;
        }
        if (app->hold_ticks_remaining == 0U) {
            app->task_phase = TASK_PHASE_TRACK;
            app->last_line_error = 0;
            app->line_was_ok = false;
            app->line_transition_ticks = 0U;
            app->open_line_confirm_ticks = 0U;
            app->node_confirm_ticks = 0U;
            app->node_release_ticks = 0U;
            app->node_detector_armed = false;
            app->last_node_trigger_travel_count = app->travel_count_total;
        }
        return;
    }

    if (app->task_phase != TASK_PHASE_TRACK) {
        car_app_reset_motor_command(app);
        return;
    }

    if (app->contest_task == CONTEST_TASK_BASIC_1) {
        car_app_update_basic1_task_state(app);
        return;
    }

    if ((app->contest_task == CONTEST_TASK_BASIC_2) ||
        (app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM)) {
        car_app_update_basic2_task_state(app);
        return;
    }

    if ((app->contest_task == CONTEST_TASK_BASIC_3) ||
        (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM)) {
        car_app_update_basic3_task_state(app);
        return;
    }

    if (!car_app_get_current_leg(app, &leg)) {
        return;
    }

    if (leg.line_tracked) {
        app->open_line_confirm_ticks = 0U;
        app->node_release_ticks = 0U;

        if (!app->line_state.has_line) {
            car_app_handle_route_node(app);
            return;
        }

        if (car_app_line_leg_has_overrun(app, &leg)) {
            car_app_handle_route_node(app);
        }
        return;
    }

    app->node_release_ticks = 0U;
    app->open_line_confirm_ticks = 0U;
    app->line_transition_ticks = 0U;

    if (app->line_state.has_line) {
        car_app_handle_route_node(app);
        return;
    }

    if (car_app_open_leg_has_overrun(app, &leg)) {
        car_app_handle_route_node(app);
    }
}

static void car_app_update_motion(car_app_t *app)
{
    school_leg_t leg;
    int32_t target_left_pps;
    int32_t target_right_pps;
    int32_t encoder_balance_term_pps;
    int32_t steering_term_pps;
    int32_t base_speed_pps;
    int32_t min_target_pps;
    int16_t heading_error_deg_x10;
    bool arc_entry_active;

    if ((app->state != APP_STATE_RUNNING) || (app->task_phase != TASK_PHASE_TRACK)) {
        car_app_reset_motor_command(app);
        return;
    }

    if (car_app_is_stationary_task(app)) {
        car_app_reset_motor_command(app);
        return;
    }

    if (!car_app_get_current_leg(app, &leg)) {
        car_app_reset_motor_command(app);
        return;
    }
    arc_entry_active = car_app_arc_entry_active_for_leg(app, &leg);
    base_speed_pps = car_app_leg_base_speed(app, &leg);
    min_target_pps = 0;

    encoder_balance_term_pps =
        ((int32_t) (app->encoder_state.right_speed_pps - app->encoder_state.left_speed_pps) *
         app->profile->straight_diff_gain_num) /
        app->profile->straight_diff_gain_den;
    encoder_balance_term_pps = clamp_i32(
        encoder_balance_term_pps,
        -app->profile->straight_diff_limit_pps,
        app->profile->straight_diff_limit_pps);

    if (leg.line_tracked) {
        if (car_app_has_line(app)) {
            if (!app->line_was_ok) {
                app->last_line_error = app->line_state.error;
                app->line_transition_ticks = 0U;
            }
            steering_term_pps = car_app_line_steering_term_pps(
                app,
                &leg,
                app->last_line_error);
            if (app->line_transition_ticks < LINE_TRANSITION_BLEND_TICKS) {
                steering_term_pps =
                    (steering_term_pps *
                     (int32_t) (app->line_transition_ticks + 1U)) /
                    (int32_t) LINE_TRANSITION_BLEND_TICKS;
            }
            app->last_line_error = app->line_state.error;
            app->line_was_ok = true;
            if (app->line_transition_ticks < UINT8_MAX) {
                app->line_transition_ticks++;
            }
        } else if (app->line_was_ok || (app->last_line_error != 0)) {
            steering_term_pps = car_app_line_steering_term_pps(
                app,
                &leg,
                app->last_line_error);
            if (app->line_transition_ticks < LINE_TRANSITION_BLEND_TICKS) {
                steering_term_pps =
                    (steering_term_pps *
                     (int32_t) (app->line_transition_ticks + 1U)) /
                    (int32_t) LINE_TRANSITION_BLEND_TICKS;
            }
            if (app->line_transition_ticks < UINT8_MAX) {
                app->line_transition_ticks++;
            }
        } else {
            heading_error_deg_x10 = car_app_heading_error_from_gyro_yaw(
                app,
                car_app_current_leg_heading_target_x10(app, &leg));
            steering_term_pps = ((int32_t) heading_error_deg_x10 *
                                 app->tuning.heading_gain_num) /
                                app->tuning.heading_gain_den;
            steering_term_pps = clamp_i32(
                steering_term_pps,
                -app->tuning.heading_term_limit_pps,
                app->tuning.heading_term_limit_pps);
            steering_term_pps *= app->tuning.heading_steer_dir;
            app->line_was_ok = false;
            app->line_transition_ticks = 0U;
        }
    } else {
        heading_error_deg_x10 = car_app_heading_error_from_gyro_yaw(
            app,
            car_app_current_leg_heading_target_x10(app, &leg));
        steering_term_pps = control_pid_step(
            &app->heading_pid,
            &app->tuning.position_pid,
            heading_error_deg_x10);
        app->last_line_error = 0;
        app->line_was_ok = false;
        app->line_transition_ticks = 0U;
    }
    if (arc_entry_active) {
        steering_term_pps = clamp_i32(
            steering_term_pps,
            -ARC_ENTRY_STEER_LIMIT_PPS,
            ARC_ENTRY_STEER_LIMIT_PPS);
    }

    target_left_pps = base_speed_pps +
                      encoder_balance_term_pps +
                      (leg.line_tracked ? steering_term_pps : -steering_term_pps);
    target_right_pps = base_speed_pps -
                       encoder_balance_term_pps -
                       (leg.line_tracked ? steering_term_pps : -steering_term_pps);
    if (!leg.line_tracked) {
        int32_t effective_bias;
        if (app->bias_ramp_ticks < 200U) {
            effective_bias = (int32_t) app->tuning.straight_bias_pps *
                             (int32_t) app->bias_ramp_ticks / 200U;
            app->bias_ramp_ticks++;
        } else {
            effective_bias = app->tuning.straight_bias_pps;
        }
        target_left_pps += effective_bias;
        target_right_pps -= effective_bias;
    }
    target_left_pps = clamp_i32(target_left_pps, min_target_pps, app->profile->wheel_speed_max_pps);
    target_right_pps = clamp_i32(target_right_pps, min_target_pps, app->profile->wheel_speed_max_pps);
    if (arc_entry_active) {
        target_left_pps = clamp_i32(
            target_left_pps,
            min_target_pps,
            app->profile->wheel_speed_max_pps);
        target_right_pps = clamp_i32(
            target_right_pps,
            min_target_pps,
            app->profile->wheel_speed_max_pps);
        target_left_pps = (int32_t) app->motor_command.left_target_pps +
                          clamp_i32(
                              target_left_pps - (int32_t) app->motor_command.left_target_pps,
                              -ARC_ENTRY_TARGET_SLEW_PPS,
                              ARC_ENTRY_TARGET_SLEW_PPS);
        target_right_pps = (int32_t) app->motor_command.right_target_pps +
                           clamp_i32(
                               target_right_pps - (int32_t) app->motor_command.right_target_pps,
                               -ARC_ENTRY_TARGET_SLEW_PPS,
                               ARC_ENTRY_TARGET_SLEW_PPS);
        target_left_pps = clamp_i32(
            target_left_pps,
            min_target_pps,
            app->profile->wheel_speed_max_pps);
        target_right_pps = clamp_i32(
            target_right_pps,
            min_target_pps,
            app->profile->wheel_speed_max_pps);
    }

    app->arc_entry_active = arc_entry_active;
    app->motor_command.left_target_pps = (int16_t) target_left_pps;
    app->motor_command.right_target_pps = (int16_t) target_right_pps;
    app->motor_command.left_pwm = speed_pid_step(
        &app->left_speed_pid,
        &app->tuning,
        app->profile,
        app->motor_command.left_target_pps,
        app->encoder_state.left_speed_pps);
    app->motor_command.right_pwm = speed_pid_step(
        &app->right_speed_pid,
        &app->tuning,
        app->profile,
        app->motor_command.right_target_pps,
        app->encoder_state.right_speed_pps);
}

static void car_app_read_board_input(car_app_input_t *input)
{
    line_sensor_sample_t line_sample;
    uint8_t debug_rx_buffer[128];
    uint8_t imu_rx_buffer[64];
    size_t debug_rx_count;
    size_t imu_rx_count;
    size_t index;

    memset(input, 0, sizeof(*input));
    input->button_mask = board_read_button_mask();

    debug_rx_count = board_read_debug_bytes(debug_rx_buffer, sizeof(debug_rx_buffer));
    if (debug_rx_count > 0U) {
        k230_protocol_feed(debug_rx_buffer, debug_rx_count);
    }
    k230_protocol_get_vision_status(&g_app.vision_state);

    if (board_line_sensor_read(&line_sample)) {
        input->has_line_sample = true;
        input->line_sample = line_sample;
    }

    input->encoder_state = board_read_encoder();

    imu_rx_count = board_read_imu_bytes(imu_rx_buffer, sizeof(imu_rx_buffer));
    for (index = 0U; index < imu_rx_count; ++index) {
        jy901_parser_feed(&g_app.imu_parser, imu_rx_buffer[index], &g_app.imu_state);
    }
    input->imu_state = g_app.imu_state;
}

static void car_app_flush_outputs(car_app_t *app)
{
    board_apply_motor_command(&app->motor_command);
    board_set_led(app->led_on);
    board_set_laser_power(app->laser_power_on);

    if (app->beep_pending) {
        board_beep(app->beep_frequency_hz, app->beep_duration_ms);
        app->beep_pending = false;
    }
}

static k230_mode_t car_app_get_k230_mode(const car_app_t *app)
{
    if (app->state != APP_STATE_RUNNING) {
        return K230_MODE_STOP;
    }

    if (app->contest_task == CONTEST_TASK_ADV_ECG) {
        return K230_MODE_ECG;
    }

    if ((app->contest_task == CONTEST_TASK_ADV_ROUTE2_AIM) ||
        (app->contest_task == CONTEST_TASK_ADV_ROUTE3_AIM)) {
        return K230_MODE_AIM;
    }

    return K230_MODE_STOP;
}

static const char *car_app_get_k230_mode_name(k230_mode_t mode)
{
    switch (mode) {
        case K230_MODE_AIM:
            return "AIM";
        case K230_MODE_ECG:
            return "ECG";
        case K230_MODE_STOP:
        default:
            return "STOP";
    }
}

static const char *car_app_get_vision_status_name(vision_status_code_t status)
{
    switch (status) {
        case VISION_STATUS_TRACKING:
            return "TRACKING";
        case VISION_STATUS_LOCKED:
            return "LOCKED";
        case VISION_STATUS_LOST:
            return "LOST";
        case VISION_STATUS_IDLE:
        default:
            return "IDLE";
    }
}

static const char *car_app_get_leg_type_name(uint8_t leg_type)
{
    switch ((school_leg_type_t) leg_type) {
        case SCHOOL_LEG_STRAIGHT:
            return "ST";
        case SCHOOL_LEG_ARC:
            return "ARC";
        case SCHOOL_LEG_NONE:
        default:
            return "NONE";
    }
}

static void car_app_param_print_current(void)
{
    char buffer[768];
    int length = snprintf(
        buffer,
        sizeof(buffer),
        "CFG,BASE=%d,ANGLE=%d,POSPID=%u/%u,%u/%u,%u/%u,DB=%d,ILIM=%ld,OLIM=%d,DIR=%d,LINEPID=%u/%u,%u/%u,%u/%u,SPDPID=%u/%u,%u/%u,%u/%u,SFWD=%u,SMIN=%d,PREAIM=%ld/%d,ARCFF=%d,SBIAS=%d,YOFF=%d,LOGMS=%u,M2AB=%d,M2CD=%d,M3AC=%d/%d/%d,M3BD=%d/%d/%d,AIMWIN=%d/%d,AIMBLEND=%u,AIMGAIN=%d/%d,AIMBIAS=%d/%d\r\n",
        car_app_mode_base_speed(&g_app),
        g_app.tuning.target_heading_deg_x10,
        (unsigned) g_app.tuning.position_pid.kp_num,
        (unsigned) g_app.tuning.position_pid.kp_den,
        (unsigned) g_app.tuning.position_pid.ki_num,
        (unsigned) g_app.tuning.position_pid.ki_den,
        (unsigned) g_app.tuning.position_pid.kd_num,
        (unsigned) g_app.tuning.position_pid.kd_den,
        g_app.tuning.position_pid.deadband,
        (long) g_app.tuning.position_pid.integral_limit,
        g_app.tuning.position_pid.output_limit,
        g_app.tuning.position_pid.direction,
        (unsigned) g_app.tuning.line_pid.kp_num,
        (unsigned) g_app.tuning.line_pid.kp_den,
        (unsigned) g_app.tuning.line_pid.ki_num,
        (unsigned) g_app.tuning.line_pid.ki_den,
        (unsigned) g_app.tuning.line_pid.kd_num,
        (unsigned) g_app.tuning.line_pid.kd_den,
        (unsigned) g_app.tuning.speed_pid.kp_num,
        (unsigned) g_app.tuning.speed_pid.kp_den,
        (unsigned) g_app.tuning.speed_pid.ki_num,
        (unsigned) g_app.tuning.speed_pid.ki_den,
        (unsigned) g_app.tuning.speed_pid.kd_num,
        (unsigned) g_app.tuning.speed_pid.kd_den,
        (unsigned) g_app.tuning.speed_feedforward_num,
        g_app.tuning.speed_min_effective_pwm,
        (long) g_app.tuning.mode1_preaim_start_counts,
        g_app.tuning.mode1_preaim_heading_x10,
        g_app.tuning.mode1_arc_feedforward_pps,
        g_app.tuning.straight_bias_pps,
        g_app.tuning.yaw_zero_offset_deg_x10,
        (unsigned) ((g_app.debug_print_period_ticks * 1000U) / APP_CONTROL_HZ),
        g_app.tuning.mode2_ab_heading_x10,
        g_app.tuning.mode2_cd_heading_x10,
        g_app.tuning.mode3_ac_heading_x10[0],
        g_app.tuning.mode3_ac_heading_x10[1],
        g_app.tuning.mode3_ac_heading_x10[2],
        g_app.tuning.mode3_bd_heading_x10[0],
        g_app.tuning.mode3_bd_heading_x10[1],
        g_app.tuning.mode3_bd_heading_x10[2],
        g_app.tuning.aim_pred_window_pan_us,
        g_app.tuning.aim_pred_window_tilt_us,
        (unsigned) g_app.tuning.aim_pred_blend_percent,
        g_app.tuning.aim_pred_pan_gain_us_per_deg_x10,
        g_app.tuning.aim_pred_tilt_gain_us_per_deg_x10,
        g_app.tuning.aim_pred_pan_bias_us,
        g_app.tuning.aim_pred_tilt_bias_us);

    if (length > 0) {
        board_debug_write(buffer);
    }
}

static void car_app_param_ack(const char *name, int32_t value)
{
    char buffer[64];
    int length = snprintf(buffer, sizeof(buffer), "PARAM_OK,%s=%ld\r\n", name, (long) value);

    if (length > 0) {
        board_debug_write(buffer);
    }
}

static void car_app_param_ack_loop(const char *name, int32_t loop, int32_t value)
{
    char buffer[80];
    int length = snprintf(
        buffer,
        sizeof(buffer),
        "PARAM_OK,%s,%ld=%ld\r\n",
        name,
        (long) loop,
        (long) value);

    if (length > 0) {
        board_debug_write(buffer);
    }
}

static void car_app_param_ack_m3diag(int32_t loop, int32_t ac_x10, int32_t bd_x10)
{
    char buffer[96];
    int length = snprintf(
        buffer,
        sizeof(buffer),
        "PARAM_OK,M3DIAG,%ld,AC=%ld,BD=%ld\r\n",
        (long) loop,
        (long) ac_x10,
        (long) bd_x10);

    if (length > 0) {
        board_debug_write(buffer);
    }
}

static void car_app_param_ack_m2st(int32_t ab_x10, int32_t cd_x10)
{
    char buffer[80];
    int length = snprintf(
        buffer,
        sizeof(buffer),
        "PARAM_OK,M2ST,AB=%ld,CD=%ld\r\n",
        (long) ab_x10,
        (long) cd_x10);

    if (length > 0) {
        board_debug_write(buffer);
    }
}

static void car_app_print_mode2_straight_tuning(void)
{
    char buffer[80];
    int length = snprintf(
        buffer,
        sizeof(buffer),
        "M2ST,AB=%d,CD=%d\r\n",
        g_app.tuning.mode2_ab_heading_x10,
        g_app.tuning.mode2_cd_heading_x10);

    if (length > 0) {
        board_debug_write(buffer);
    }
}

static void car_app_print_mode3_diagonal_tuning(void)
{
    char buffer[96];
    uint8_t index;

    for (index = 0U; index < MODE3_LOOP_MAX; ++index) {
        int length = snprintf(
            buffer,
            sizeof(buffer),
            "M3DIAG,%u,AC=%d,BD=%d\r\n",
            (unsigned) index + 1U,
            g_app.tuning.mode3_ac_heading_x10[index],
            g_app.tuning.mode3_bd_heading_x10[index]);

        if (length > 0) {
            board_debug_write(buffer);
        }
    }
}

static void car_app_param_error(const char *reason)
{
    board_debug_write("PARAM_ERR,");
    board_debug_write(reason);
    board_debug_write("\r\n");
}

static bool parse_param_i32(const char **cursor, int32_t *value)
{
    char *endptr;
    long parsed;

    if ((cursor == NULL) || (*cursor == NULL) || (value == NULL)) {
        return false;
    }

    parsed = strtol(*cursor, &endptr, 10);
    if (endptr == *cursor) {
        return false;
    }

    *value = (int32_t) parsed;
    *cursor = endptr;
    return true;
}

static bool parse_param_comma(const char **cursor)
{
    if ((cursor == NULL) || (*cursor == NULL) || (**cursor != ',')) {
        return false;
    }

    (*cursor)++;
    return true;
}

static bool parse_param_series(const char **cursor, int32_t *values, size_t count)
{
    size_t index;

    if ((cursor == NULL) || (*cursor == NULL) || (values == NULL) || (count == 0U)) {
        return false;
    }

    for (index = 0U; index < count; ++index) {
        if (!parse_param_i32(cursor, &values[index])) {
            return false;
        }
        if ((index + 1U) < count) {
            if (!parse_param_comma(cursor)) {
                return false;
            }
        }
    }

    return true;
}

bool car_app_handle_param_command(const char *line)
{
    const char *cursor;
    int32_t first;
    int32_t second;
    int32_t third;

    if (line == NULL) {
        return false;
    }

    if (strcmp(line, "CFG,SHOW") == 0) {
        car_app_param_print_current();
        return true;
    }

    if (strncmp(line, "CFG,BASE,", 9U) == 0) {
        cursor = line + 9U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("CFG_BASE");
            return true;
        }
        first = clamp_i32(first, 0, 1800);
        if (g_app.selected_mode == CHASSIS_MODE_1) {
            g_app.tuning.base_speed_mode_1 = (int16_t) first;
        } else if (g_app.selected_mode == CHASSIS_MODE_2) {
            g_app.tuning.base_speed_mode_2 = (int16_t) first;
        } else {
            g_app.tuning.base_speed_mode_3 = (int16_t) first;
        }
        board_debug_write("PARAM_OK,CFG_BASE\r\n");
        return true;
    }

    if (strncmp(line, "CFG,ANGLE,", 10U) == 0) {
        cursor = line + 10U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("CFG_ANGLE");
            return true;
        }
        g_app.tuning.target_heading_deg_x10 = (int16_t) clamp_i32(first, -1800, 1800);
        board_debug_write("PARAM_OK,CFG_ANGLE\r\n");
        return true;
    }

    if (strncmp(line, "CFG,POSPID,", 11U) == 0) {
        int32_t vals[10];

        cursor = line + 11U;
        if (!parse_param_series(&cursor, vals, 10U)) {
            car_app_param_error("CFG_POSPID");
            return true;
        }
        g_app.tuning.position_pid.kp_num = (uint8_t) clamp_i32(vals[0], 0, 100);
        g_app.tuning.position_pid.kp_den = (uint16_t) clamp_i32(vals[1], 1, 500);
        g_app.tuning.position_pid.ki_num = (uint8_t) clamp_i32(vals[2], 0, 100);
        g_app.tuning.position_pid.ki_den = (uint16_t) clamp_i32(vals[3], 1, 500);
        g_app.tuning.position_pid.kd_num = (uint8_t) clamp_i32(vals[4], 0, 100);
        g_app.tuning.position_pid.kd_den = (uint16_t) clamp_i32(vals[5], 1, 500);
        g_app.tuning.position_pid.deadband = (int16_t) clamp_i32(vals[6], 0, 100);
        g_app.tuning.position_pid.integral_limit = clamp_i32(vals[7], 0, 20000);
        g_app.tuning.position_pid.output_limit = (int16_t) clamp_i32(vals[8], 0, 1000);
        g_app.tuning.position_pid.direction = (int8_t) ((vals[9] >= 0) ? 1 : -1);
        car_app_sync_legacy_tuning_fields(&g_app);
        car_app_reset_angle_pids(&g_app);
        board_debug_write("PARAM_OK,CFG_POSPID\r\n");
        return true;
    }

    if (strncmp(line, "CFG,LINEPID,", 12U) == 0) {
        int32_t vals[10];

        cursor = line + 12U;
        if (!parse_param_series(&cursor, vals, 10U)) {
            car_app_param_error("CFG_LINEPID");
            return true;
        }
        g_app.tuning.line_pid.kp_num = (uint8_t) clamp_i32(vals[0], 0, 100);
        g_app.tuning.line_pid.kp_den = (uint16_t) clamp_i32(vals[1], 1, 500);
        g_app.tuning.line_pid.ki_num = (uint8_t) clamp_i32(vals[2], 0, 100);
        g_app.tuning.line_pid.ki_den = (uint16_t) clamp_i32(vals[3], 1, 500);
        g_app.tuning.line_pid.kd_num = (uint8_t) clamp_i32(vals[4], 0, 100);
        g_app.tuning.line_pid.kd_den = (uint16_t) clamp_i32(vals[5], 1, 500);
        g_app.tuning.line_pid.deadband = (int16_t) clamp_i32(vals[6], 0, 100);
        g_app.tuning.line_pid.integral_limit = clamp_i32(vals[7], 0, 20000);
        g_app.tuning.line_pid.output_limit = (int16_t) clamp_i32(vals[8], 0, 1800);
        g_app.tuning.line_pid.direction = (int8_t) ((vals[9] >= 0) ? 1 : -1);
        car_app_sync_legacy_tuning_fields(&g_app);
        heading_pid_reset(&g_app.line_pid);
        board_debug_write("PARAM_OK,CFG_LINEPID\r\n");
        return true;
    }

    if (strncmp(line, "CFG,SPDPID,", 11U) == 0) {
        int32_t vals[11];

        cursor = line + 11U;
        if (!parse_param_series(&cursor, vals, 11U)) {
            car_app_param_error("CFG_SPDPID");
            return true;
        }
        g_app.tuning.speed_pid.kp_num = (uint8_t) clamp_i32(vals[0], 0, 100);
        g_app.tuning.speed_pid.kp_den = (uint16_t) clamp_i32(vals[1], 1, 500);
        g_app.tuning.speed_pid.ki_num = (uint8_t) clamp_i32(vals[2], 0, 100);
        g_app.tuning.speed_pid.ki_den = (uint16_t) clamp_i32(vals[3], 1, 500);
        g_app.tuning.speed_pid.kd_num = (uint8_t) clamp_i32(vals[4], 0, 100);
        g_app.tuning.speed_pid.kd_den = (uint16_t) clamp_i32(vals[5], 1, 500);
        g_app.tuning.speed_pid.deadband = (int16_t) clamp_i32(vals[6], 0, 100);
        g_app.tuning.speed_pid.integral_limit = clamp_i32(vals[7], 0, 20000);
        g_app.tuning.speed_pid.output_limit = (int16_t) clamp_i32(vals[8], 0, 3000);
        g_app.tuning.speed_feedforward_num = (uint8_t) clamp_i32(vals[9], 0, 10);
        g_app.tuning.speed_min_effective_pwm = (int16_t) clamp_i32(vals[10], 0, 3000);
        board_debug_write("PARAM_OK,CFG_SPDPID\r\n");
        return true;
    }

    if (strcmp(line, "PARAM,SHOW") == 0) {
        car_app_param_print_current();
        return true;
    }

    if (strcmp(line, "PARAM,HELP") == 0) {
        board_debug_write("CFG_HELP,SHOW BASE,pps ANGLE,deg_x10 POSPID,kp,kpd,ki,kid,kd,kdd,db,ilim,olim,dir LINEPID,kp,kpd,ki,kid,kd,kdd,db,ilim,olim,dir SPDPID,kp,kpd,ki,kid,kd,kdd,db,ilim,olim,ff,minpwm M2AB,deg_x10 M2CD,deg_x10 M2ST,ab,cd M2SHOW M3AC,loop,deg_x10 M3BD,loop,deg_x10 M3DIAG,loop,ac,bd M3SHOW AIMWIN,pan,tilt AIMBLEND,pct AIMGAIN,pan_gain,tilt_gain AIMBIAS,pan,tilt\r\n");
        return true;
    }

    if (strcmp(line, "PARAM,RESET") == 0) {
        car_app_reset_runtime_tuning(&g_app);
        board_debug_write("PARAM_OK,RESET\r\n");
        car_app_param_print_current();
        return true;
    }

    if (strcmp(line, "PARAM,M2SHOW") == 0) {
        car_app_print_mode2_straight_tuning();
        return true;
    }

    if (strncmp(line, "PARAM,M2AB,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("M2AB");
            return true;
        }
        g_app.tuning.mode2_ab_heading_x10 = (int16_t) clamp_i32(first, -1800, 1800);
        car_app_param_ack("M2AB", g_app.tuning.mode2_ab_heading_x10);
        return true;
    }

    if (strncmp(line, "PARAM,M2CD,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("M2CD");
            return true;
        }
        g_app.tuning.mode2_cd_heading_x10 = (int16_t) clamp_i32(first, -1800, 1800);
        car_app_param_ack("M2CD", g_app.tuning.mode2_cd_heading_x10);
        return true;
    }

    if (strncmp(line, "PARAM,M2ST,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("M2ST");
            return true;
        }
        first = clamp_i32(first, -1800, 1800);
        second = clamp_i32(second, -1800, 1800);
        g_app.tuning.mode2_ab_heading_x10 = (int16_t) first;
        g_app.tuning.mode2_cd_heading_x10 = (int16_t) second;
        car_app_param_ack_m2st(first, second);
        return true;
    }

    if (strcmp(line, "PARAM,M3SHOW") == 0) {
        car_app_print_mode3_diagonal_tuning();
        return true;
    }

    if (strncmp(line, "PARAM,M3AC,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("M3AC");
            return true;
        }
        second = clamp_i32(second, -1800, 1800);
        if (!car_app_set_mode3_ac_loop(&g_app, first, (int16_t) second)) {
            car_app_param_error("M3AC_LOOP");
            return true;
        }
        car_app_param_ack_loop("M3AC", first, second);
        return true;
    }

    if (strncmp(line, "PARAM,M3BD,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("M3BD");
            return true;
        }
        second = clamp_i32(second, -1800, 1800);
        if (!car_app_set_mode3_bd_loop(&g_app, first, (int16_t) second)) {
            car_app_param_error("M3BD_LOOP");
            return true;
        }
        car_app_param_ack_loop("M3BD", first, second);
        return true;
    }

    if (strncmp(line, "PARAM,M3DIAG,", 13U) == 0) {
        cursor = line + 13U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &third)) {
            car_app_param_error("M3DIAG");
            return true;
        }
        second = clamp_i32(second, -1800, 1800);
        third = clamp_i32(third, -1800, 1800);
        if (!car_app_set_mode3_ac_loop(&g_app, first, (int16_t) second) ||
            !car_app_set_mode3_bd_loop(&g_app, first, (int16_t) third)) {
            car_app_param_error("M3DIAG_LOOP");
            return true;
        }
        car_app_param_ack_m3diag(first, second, third);
        return true;
    }

    if (strncmp(line, "PARAM,AC,", 9U) == 0) {
        cursor = line + 9U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("AC");
            return true;
        }
        car_app_set_mode3_ac_all(&g_app, (int16_t) clamp_i32(first, -1800, 1800));
        car_app_param_ack("AC", g_app.tuning.heading_ac_x10);
        return true;
    }

    if (strncmp(line, "PARAM,BD,", 9U) == 0) {
        cursor = line + 9U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("BD");
            return true;
        }
        car_app_set_mode3_bd_all(&g_app, (int16_t) clamp_i32(first, -1800, 1800));
        car_app_param_ack("BD", g_app.tuning.heading_bd_x10);
        return true;
    }

    if (strncmp(line, "PARAM,DIAG,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("DIAG");
            return true;
        }
        g_app.tuning.diagonal_mm = (uint16_t) clamp_i32(first, 500, 2000);
        car_app_param_ack("DIAG", g_app.tuning.diagonal_mm);
        return true;
    }

    if (strncmp(line, "PARAM,ODOM,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("ODOM");
            return true;
        }
        g_app.tuning.odom_counts_per_mm_x100 = (uint16_t) clamp_i32(first, 1, 10000);
        car_app_param_ack("ODOM", g_app.tuning.odom_counts_per_mm_x100);
        return true;
    }

    if (strncmp(line, "PARAM,HGAIN,", 12U) == 0) {
        cursor = line + 12U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second) ||
            (second == 0)) {
            car_app_param_error("HGAIN");
            return true;
        }
        g_app.tuning.line_pid.kp_num = (uint8_t) clamp_i32(first, 0, 100);
        g_app.tuning.line_pid.kp_den = (uint16_t) clamp_i32(second, 1, 100);
        car_app_sync_legacy_tuning_fields(&g_app);
        heading_pid_reset(&g_app.line_pid);
        board_debug_write("PARAM_OK,HGAIN\r\n");
        return true;
    }

    if (strncmp(line, "PARAM,HPID,", 11U) == 0) {
        int32_t third;
        int32_t fourth;
        int32_t fifth;
        int32_t sixth;

        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &third) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &fourth) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &fifth) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &sixth) ||
            (second == 0) ||
            (fourth == 0) ||
            (sixth == 0)) {
            car_app_param_error("HPID");
            return true;
        }

        g_app.tuning.position_pid.kp_num = (uint8_t) clamp_i32(first, 0, 100);
        g_app.tuning.position_pid.kp_den = (uint16_t) clamp_i32(second, 1, 500);
        g_app.tuning.position_pid.ki_num = (uint8_t) clamp_i32(third, 0, 100);
        g_app.tuning.position_pid.ki_den = (uint16_t) clamp_i32(fourth, 1, 500);
        g_app.tuning.position_pid.kd_num = (uint8_t) clamp_i32(fifth, 0, 100);
        g_app.tuning.position_pid.kd_den = (uint16_t) clamp_i32(sixth, 1, 500);
        car_app_sync_legacy_tuning_fields(&g_app);
        car_app_reset_angle_pids(&g_app);
        board_debug_write("PARAM_OK,HPID\r\n");
        return true;
    }

    if (strncmp(line, "PARAM,HDB,", 10U) == 0) {
        cursor = line + 10U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("HDB");
            return true;
        }
        g_app.tuning.position_pid.deadband = (int16_t) clamp_i32(first, 0, 100);
        car_app_sync_legacy_tuning_fields(&g_app);
        car_app_reset_angle_pids(&g_app);
        car_app_param_ack("HDB", g_app.tuning.position_pid.deadband);
        return true;
    }

    if (strncmp(line, "PARAM,HILIM,", 12U) == 0) {
        cursor = line + 12U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("HILIM");
            return true;
        }
        g_app.tuning.position_pid.integral_limit = clamp_i32(first, 0, 20000);
        car_app_sync_legacy_tuning_fields(&g_app);
        car_app_reset_angle_pids(&g_app);
        car_app_param_ack("HILIM", g_app.tuning.position_pid.integral_limit);
        return true;
    }

    if (strncmp(line, "PARAM,HLIM,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("HLIM");
            return true;
        }
        g_app.tuning.position_pid.output_limit = (int16_t) clamp_i32(first, 0, 1000);
        car_app_sync_legacy_tuning_fields(&g_app);
        car_app_param_ack("HLIM", g_app.tuning.position_pid.output_limit);
        return true;
    }

    if (strncmp(line, "PARAM,HDIR,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first) || ((first != 1) && (first != -1))) {
            car_app_param_error("HDIR");
            return true;
        }
        g_app.tuning.position_pid.direction = (int8_t) first;
        car_app_sync_legacy_tuning_fields(&g_app);
        car_app_reset_angle_pids(&g_app);
        car_app_param_ack("HDIR", g_app.tuning.position_pid.direction);
        return true;
    }

    if (strncmp(line, "PARAM,PREAIM,", 13U) == 0) {
        cursor = line + 13U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("PREAIM");
            return true;
        }
        g_app.tuning.mode1_preaim_start_counts = clamp_i32(first, 0, MODE1_AB_TARGET_COUNTS);
        g_app.tuning.mode1_preaim_heading_x10 = (int16_t) clamp_i32(second, -300, 300);
        g_app.tuning.target_heading_deg_x10 = 0;
        car_app_reset_angle_pids(&g_app);
        board_debug_write("PARAM_OK,PREAIM\r\n");
        return true;
    }

    if (strncmp(line, "PARAM,ARCFF,", 12U) == 0) {
        cursor = line + 12U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("ARCFF");
            return true;
        }
        g_app.tuning.mode1_arc_feedforward_pps = (int16_t) clamp_i32(first, -500, 500);
        car_app_param_ack("ARCFF", g_app.tuning.mode1_arc_feedforward_pps);
        return true;
    }

    if (strncmp(line, "PARAM,LOGMS,", 12U) == 0) {
        cursor = line + 12U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("LOGMS");
            return true;
        }
        first = clamp_i32(first, DEBUG_PRINT_MS_MIN, DEBUG_PRINT_MS_MAX);
        g_app.debug_print_period_ticks = (uint16_t) clamp_i32(
            (first * (int32_t) APP_CONTROL_HZ) / 1000,
            1,
            60000);
        g_app.debug_print_divider = 1U;
        car_app_param_ack("LOGMS", (g_app.debug_print_period_ticks * 1000U) / APP_CONTROL_HZ);
        return true;
    }

    if (strncmp(line, "PARAM,AIMWIN,", 13U) == 0) {
        cursor = line + 13U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("AIMWIN");
            return true;
        }
        g_app.tuning.aim_pred_window_pan_us = (int16_t) clamp_i32(first, 0, 400);
        g_app.tuning.aim_pred_window_tilt_us = (int16_t) clamp_i32(second, 0, 200);
        car_app_param_ack("AIMWIN", g_app.tuning.aim_pred_window_pan_us);
        return true;
    }

    if (strncmp(line, "PARAM,AIMBLEND,", 15U) == 0) {
        cursor = line + 15U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("AIMBLEND");
            return true;
        }
        g_app.tuning.aim_pred_blend_percent = (uint8_t) clamp_i32(first, 0, 100);
        car_app_param_ack("AIMBLEND", g_app.tuning.aim_pred_blend_percent);
        return true;
    }

    if (strncmp(line, "PARAM,AIMGAIN,", 14U) == 0) {
        cursor = line + 14U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("AIMGAIN");
            return true;
        }
        g_app.tuning.aim_pred_pan_gain_us_per_deg_x10 = (int16_t) clamp_i32(first, -20, 20);
        g_app.tuning.aim_pred_tilt_gain_us_per_deg_x10 = (int16_t) clamp_i32(second, -20, 20);
        car_app_param_ack("AIMGAIN", g_app.tuning.aim_pred_pan_gain_us_per_deg_x10);
        return true;
    }

    if (strncmp(line, "PARAM,AIMBIAS,", 14U) == 0) {
        cursor = line + 14U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("AIMBIAS");
            return true;
        }
        g_app.tuning.aim_pred_pan_bias_us = (int16_t) clamp_i32(first, -300, 300);
        g_app.tuning.aim_pred_tilt_bias_us = (int16_t) clamp_i32(second, -300, 300);
        car_app_param_ack("AIMBIAS", g_app.tuning.aim_pred_pan_bias_us);
        return true;
    }

    if (strncmp(line, "PARAM,OPENMIN,", 14U) == 0) {
        cursor = line + 14U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("OPENMIN");
            return true;
        }
        g_app.tuning.open_reacquire_min_percent = (uint8_t) clamp_i32(first, 0, 100);
        car_app_param_ack("OPENMIN", g_app.tuning.open_reacquire_min_percent);
        return true;
    }

    if (strncmp(line, "PARAM,OPENMAX,", 14U) == 0) {
        cursor = line + 14U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("OPENMAX");
            return true;
        }
        g_app.tuning.open_max_overrun_percent = (uint8_t) clamp_i32(first, 100, 200);
        car_app_param_ack("OPENMAX", g_app.tuning.open_max_overrun_percent);
        return true;
    }

    if (strncmp(line, "PARAM,ORECAP,", 13U) == 0) {
        cursor = line + 13U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("ORECAP");
            return true;
        }
        g_app.tuning.open_reacquire_confirm_ticks = (uint8_t) clamp_i32(first, 1, 20);
        car_app_param_ack("ORECAP", g_app.tuning.open_reacquire_confirm_ticks);
        return true;
    }

    if (strncmp(line, "PARAM,BASE,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_param_error("BASE");
            return true;
        }
        second = clamp_i32(second, 0, 1800);
        if (first == 1) {
            g_app.tuning.base_speed_mode_1 = (int16_t) second;
        } else if (first == 2) {
            g_app.tuning.base_speed_mode_2 = (int16_t) second;
        } else if (first == 3) {
            g_app.tuning.base_speed_mode_3 = (int16_t) second;
        } else {
            car_app_param_error("BASE_MODE");
            return true;
        }
        board_debug_write("PARAM_OK,BASE\r\n");
        return true;
    }

    if (strncmp(line, "PARAM,SBIAS,", 12U) == 0) {
        cursor = line + 12U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("SBIAS");
            return true;
        }
        g_app.tuning.straight_bias_pps = (int16_t) clamp_i32(first, -300, 300);
        car_app_param_ack("SBIAS", g_app.tuning.straight_bias_pps);
        return true;
    }

    if (strncmp(line, "PARAM,YOFF,", 11U) == 0) {
        cursor = line + 11U;
        if (!parse_param_i32(&cursor, &first)) {
            car_app_param_error("YOFF");
            return true;
        }
        g_app.tuning.yaw_zero_offset_deg_x10 = (int16_t) clamp_i32(first, -300, 300);
        car_app_param_ack("YOFF", g_app.tuning.yaw_zero_offset_deg_x10);
        return true;
    }

    car_app_param_error("UNKNOWN");
    return true;
}

static void car_app_control_ack(const char *text)
{
    board_debug_write("CAR_OK,");
    board_debug_write(text);
    board_debug_write("\r\n");
}

static void car_app_control_error(const char *reason)
{
    board_debug_write("CAR_ERR,");
    board_debug_write(reason);
    board_debug_write("\r\n");
}

bool car_app_handle_control_command(const char *line)
{
    const char *cursor;
    int32_t value;

    if (line == NULL) {
        return false;
    }

    if (strcmp(line, "CAR,HELP") == 0) {
        board_debug_write("CAR_HELP,CAR,START CAR,STOP CAR,MODE,1 CAR,MODE,2 CAR,MODE,3 CAR,MODE,4 CAR,MODE,5 CAR,MODE,6 CAR,LASER,0/1 CAR,STATUS MOTOR,left_pwm,right_pwm,ms MOTORSTOP\r\n");
        return true;
    }

    if (strcmp(line, "CAR,START") == 0) {
        if (g_app.state != APP_STATE_RUNNING) {
            car_app_start(&g_app);
        }
        car_app_control_ack("START");
        return true;
    }

    if (strcmp(line, "CAR,STOP") == 0) {
        car_app_stop_manual_motor(&g_app);
        if (g_app.state == APP_STATE_RUNNING) {
            car_app_stop(&g_app);
        } else {
            car_app_reset_motor_command(&g_app);
        }
        car_app_control_ack("STOP");
        return true;
    }

    if (strncmp(line, "CAR,MOTOR,", 10U) == 0) {
        int32_t second;
        int32_t third = 1000;

        cursor = line + 10U;
        if (!parse_param_i32(&cursor, &value) ||
            !parse_param_comma(&cursor) ||
            !parse_param_i32(&cursor, &second)) {
            car_app_control_error("MOTOR");
            return true;
        }
        if (*cursor == ',') {
            cursor++;
            if (!parse_param_i32(&cursor, &third)) {
                car_app_control_error("MOTOR_MS");
                return true;
            }
        }

        g_app.state = APP_STATE_STOPPED;
        g_app.task_phase = TASK_PHASE_FINISHED;
        car_app_reset_motor_command(&g_app);
        g_app.manual_motor_command.left_target_pps = 0;
        g_app.manual_motor_command.right_target_pps = 0;
        g_app.manual_motor_command.left_pwm = (int16_t) clamp_i32(value, -3000, 3000);
        g_app.manual_motor_command.right_pwm = (int16_t) clamp_i32(second, -3000, 3000);
        g_app.manual_motor_ticks_remaining =
            (uint16_t) clamp_i32(((third <= 0) ? 1000 : third) * (int32_t) APP_CONTROL_HZ / 1000, 1, 60000);
        car_app_control_ack("MOTOR");
        return true;
    }

    if (strcmp(line, "CAR,MOTORSTOP") == 0) {
        car_app_stop_manual_motor(&g_app);
        car_app_reset_motor_command(&g_app);
        car_app_control_ack("MOTORSTOP");
        return true;
    }

    if (strncmp(line, "CAR,LASER,", 10U) == 0) {
        cursor = line + 10U;
        if (!parse_param_i32(&cursor, &value)) {
            car_app_control_error("LASER");
            return true;
        }
        g_app.laser_power_on = (value != 0);
        board_set_laser_power(g_app.laser_power_on);
        car_app_control_ack(g_app.laser_power_on ? "LASER,1" : "LASER,0");
        return true;
    }

    if (strncmp(line, "CAR,MODE,", 9U) == 0) {
        if (g_app.state == APP_STATE_RUNNING) {
            car_app_control_error("MODE_WHILE_RUNNING");
            return true;
        }
        cursor = line + 9U;
        if (!parse_param_i32(&cursor, &value)) {
            car_app_control_error("MODE");
            return true;
        }
        if (value == 1) {
            car_app_select_task(&g_app, CONTEST_TASK_BASIC_1);
        } else if (value == 2) {
            car_app_select_task(&g_app, CONTEST_TASK_BASIC_2);
        } else if (value == 3) {
            car_app_select_task(&g_app, CONTEST_TASK_BASIC_3);
        } else if (value == 4) {
            car_app_select_task(&g_app, CONTEST_TASK_ADV_ECG);
        } else if (value == 5) {
            car_app_select_task(&g_app, CONTEST_TASK_ADV_ROUTE2_AIM);
        } else if (value == 6) {
            car_app_select_task(&g_app, CONTEST_TASK_ADV_ROUTE3_AIM);
        } else {
            car_app_control_error("MODE_RANGE");
            return true;
        }
        car_app_control_ack("MODE");
        return true;
    }

    if (strcmp(line, "CAR,STATUS") == 0) {
        car_app_debug_print();
        return true;
    }

    car_app_control_error("UNKNOWN");
    return true;
}

void car_app_set_profile(car_app_profile_id_t profile_id)
{
    g_app.profile = car_app_profile_from_id(profile_id);
    car_app_reset_runtime_tuning(&g_app);
}

car_app_profile_id_t car_app_get_profile(void)
{
    return g_app.profile->profile_id;
}

void car_app_get_snapshot(car_app_snapshot_t *snapshot)
{
    const route_plan_t *plan = car_app_get_plan(&g_app);
    const k230_mode_t k230_mode = car_app_get_k230_mode(&g_app);
    school_leg_t leg;
    int16_t heading_error_deg_x10 = 0;
    const uint8_t total_loops =
        (g_app.selected_mode == CHASSIS_MODE_3) ? g_app.mode3_loops : plan->default_loops;
    const uint8_t current_loop =
        (g_app.completed_loops >= total_loops) ? total_loops : (g_app.completed_loops + 1U);

    memset(snapshot, 0, sizeof(*snapshot));
    snapshot->tick_count = g_app.tick_count;
    snapshot->time_ms = ticks_to_ms(g_app.tick_count);
    snapshot->profile_id = g_app.profile->profile_id;
    snapshot->profile_name = g_app.profile->name;
    snapshot->mode = (uint8_t) g_app.selected_mode + 1U;
    snapshot->k230_mode = (uint8_t) k230_mode;
    snapshot->vision_state = g_app.vision_state;
    snapshot->state = (uint8_t) g_app.state;
    snapshot->phase = (uint8_t) g_app.task_phase;
    snapshot->button_mask = g_app.current_button_mask;
    snapshot->pressed_button_mask = g_app.last_pressed_button_mask;
    snapshot->route_index = g_app.route_index;
    snapshot->route_total = plan->node_count - 1U;
    snapshot->current_loop = current_loop;
    snapshot->total_loops = total_loops;
    snapshot->last_node = route_node_to_char(g_app.last_event_node);
    snapshot->leg_start_node = '-';
    snapshot->leg_end_node = '-';
    snapshot->leg_type = (uint8_t) SCHOOL_LEG_NONE;
    snapshot->leg_line_tracked = 0U;
    snapshot->leg_heading_start_deg_x10 = 0;
    snapshot->leg_heading_end_deg_x10 = 0;
    snapshot->leg_length_mm = 0U;
    snapshot->leg_progress_count = 0;
    snapshot->leg_target_count = 0;
    snapshot->heading_target_deg_x10 = 0;
    snapshot->heading_error_deg_x10 = 0;
    snapshot->relative_yaw_deg_x10 = car_app_relative_yaw_deg_x10(&g_app);
    snapshot->gyro_relative_yaw_deg_x10 = car_app_gyro_relative_yaw_deg_x10(&g_app);
    snapshot->yaw_zero_deg_x10 = g_app.yaw_zero_valid ?
        (int16_t) (g_app.yaw_zero_deg * 10.0f) : 0;
    snapshot->route2_bc_exit_candidate_valid =
        g_app.route2_bc_exit_candidate_valid ? 1U : 0U;
    snapshot->route2_bc_exit_candidate_ryaw_x10 =
        g_app.route2_bc_exit_candidate_ryaw_x10;
    snapshot->route2_bc_exit_candidate_lcnt =
        g_app.route2_bc_exit_candidate_lcnt;
    snapshot->open_line_confirm_ticks = g_app.open_line_confirm_ticks;
    snapshot->arc_entry_active = g_app.arc_entry_active ? 1U : 0U;
    if (car_app_get_current_leg(&g_app, &leg)) {
        snapshot->leg_start_node = route_node_to_char(leg.start_node);
        snapshot->leg_end_node = route_node_to_char(leg.end_node);
        snapshot->leg_type = (uint8_t) leg.type;
        snapshot->leg_line_tracked = leg.line_tracked ? 1U : 0U;
        snapshot->leg_heading_start_deg_x10 = leg.heading_start_deg_x10;
        snapshot->leg_heading_end_deg_x10 = leg.heading_end_deg_x10;
        snapshot->leg_length_mm = leg.length_mm;
        snapshot->leg_progress_count = car_app_current_leg_travel_counts(&g_app);
        snapshot->leg_target_count = car_app_leg_target_counts(&leg);
        snapshot->heading_target_deg_x10 = car_app_current_leg_heading_target_x10(
            &g_app,
            &leg);
        if (!leg.line_tracked) {
            heading_error_deg_x10 = car_app_heading_error_from_gyro_yaw(
                &g_app,
                snapshot->heading_target_deg_x10);
        }
        snapshot->heading_error_deg_x10 = heading_error_deg_x10;
    }
    snapshot->node_event_count = g_app.node_event_count;
    snapshot->hold_ms_remaining = ticks_to_ms(g_app.hold_ticks_remaining);
    snapshot->line_ok = g_app.line_state.has_line;
    snapshot->line_active_mask = g_app.line_state.active_mask;
    snapshot->line_raw_mask = g_app.line_state.raw_mask;
    snapshot->line_active_count = g_app.line_state.active_count;
    snapshot->line_max_index = g_app.line_state.max_index;
    snapshot->line_max_value = g_app.line_state.max_value;
    snapshot->line_error = g_app.line_state.error;
    snapshot->left_speed_pps = g_app.encoder_state.left_speed_pps;
    snapshot->right_speed_pps = g_app.encoder_state.right_speed_pps;
    snapshot->straight_term_pps = 0;
    snapshot->turn_term_pps = 0;
    snapshot->straight_bias_pps = g_app.tuning.straight_bias_pps;
    if ((g_app.state == APP_STATE_RUNNING) &&
        (g_app.task_phase == TASK_PHASE_TRACK) &&
        car_app_get_current_leg(&g_app, &leg)) {
        int32_t straight_term_pps =
            ((int32_t) (g_app.encoder_state.right_speed_pps - g_app.encoder_state.left_speed_pps) *
             g_app.profile->straight_diff_gain_num) /
            g_app.profile->straight_diff_gain_den;
        straight_term_pps = clamp_i32(
            straight_term_pps,
            -g_app.profile->straight_diff_limit_pps,
            g_app.profile->straight_diff_limit_pps);
        snapshot->straight_term_pps = (int16_t) straight_term_pps;

        if (leg.line_tracked) {
            int32_t turn_term_pps = car_app_line_steering_term_pps(
                &g_app,
                &leg,
                g_app.last_line_error);
            snapshot->turn_term_pps = (int16_t) clamp_i32(turn_term_pps, -32768, 32767);
        } else {
            snapshot->turn_term_pps = control_pid_step_preview(
                &g_app.heading_pid,
                &g_app.tuning.position_pid,
                heading_error_deg_x10);
        }
    }
    snapshot->left_target_pps = g_app.motor_command.left_target_pps;
    snapshot->right_target_pps = g_app.motor_command.right_target_pps;
    snapshot->left_pwm = g_app.motor_command.left_pwm;
    snapshot->right_pwm = g_app.motor_command.right_pwm;
    snapshot->roll_deg = g_app.imu_state.roll_deg;
    snapshot->pitch_deg = g_app.imu_state.pitch_deg;
    snapshot->yaw_deg = g_app.imu_state.yaw_deg;
    snapshot->gyro_z_dps = g_app.imu_state.gyro_z_dps;
    snapshot->led_on = g_app.led_on;
    snapshot->beep_pending = g_app.beep_pending;
    snapshot->beep_frequency_hz = g_app.beep_frequency_hz;
    snapshot->beep_duration_ms = g_app.beep_duration_ms;
    gimbal_servo_get_state(&snapshot->gimbal_state);
}

size_t car_app_format_log_line(
    char *buffer, size_t capacity, const car_app_snapshot_t *snapshot)
{
    const char *k230_mode_name;
    const char *vision_status_name;
    const char *leg_type_name;
    int yaw_tenth;
    int yaw_frac;
    int roll_tenth;
    int roll_frac;
    int pitch_tenth;
    int pitch_frac;
    int gz_tenth;
    int gz_frac;
    int length;

    k230_mode_name = car_app_get_k230_mode_name((k230_mode_t) snapshot->k230_mode);
    vision_status_name = car_app_get_vision_status_name(snapshot->vision_state.status);
    leg_type_name = car_app_get_leg_type_name(snapshot->leg_type);
    yaw_tenth = (int) (snapshot->yaw_deg * 10.0f);
    yaw_frac = yaw_tenth % 10;
    if (yaw_frac < 0) {
        yaw_frac = -yaw_frac;
    }
    roll_tenth = (int) (snapshot->roll_deg * 10.0f);
    roll_frac = roll_tenth % 10;
    if (roll_frac < 0) {
        roll_frac = -roll_frac;
    }
    pitch_tenth = (int) (snapshot->pitch_deg * 10.0f);
    pitch_frac = pitch_tenth % 10;
    if (pitch_frac < 0) {
        pitch_frac = -pitch_frac;
    }
    gz_tenth = (int) (snapshot->gyro_z_dps * 10.0f);
    gz_frac = gz_tenth % 10;
    if (gz_frac < 0) {
        gz_frac = -gz_frac;
    }

    length = snprintf(
        buffer,
        capacity,
        "%s,t_ms=%lu,profile=%s,mode=%u,k230=%s,state=%u,phase=%u,btn=0x%02lX,pbtn=0x%02lX,seg=%u/%u,loop=%u/%u,m2=%d/%d,m3loop=%u,m3ac=%d/%d/%d,m3bd=%d/%d/%d,last=%c,leg=%c%c,ltype=%s,lline=%u,llen=%u,lhd=%d/%d,lcnt=%ld/%ld,hdg=%d/%d,ryaw=%d,gyaw=%d,yzero=%d,bcand=%u/%d/%ld,orecap=%u,entry=%u,evt=%lu,hold_ms=%lu,line_ok=%u,line=0x%02X,lraw=0x%02X,lact=%u,lmax=%u/%u,err=%d,vok=%u,vstat=%s,verr=%d/%d,spd=%d/%d,term=%d/%d,sbias=%d,tar=%d/%d,pwm=%d/%d,rpy=%d.%d/%d.%d/%d.%d,gz=%d.%d,gim_en=%u,gim_us=%ld/%ld,gim_tar_us=%ld/%ld\r\n",
        CAR_APP_LOG_PREFIX,
        (unsigned long) snapshot->time_ms,
        snapshot->profile_name,
        (unsigned) snapshot->mode,
        k230_mode_name,
        (unsigned) snapshot->state,
        (unsigned) snapshot->phase,
        (unsigned long) snapshot->button_mask,
        (unsigned long) snapshot->pressed_button_mask,
        (unsigned) snapshot->route_index,
        (unsigned) snapshot->route_total,
        (unsigned) snapshot->current_loop,
        (unsigned) snapshot->total_loops,
        g_app.tuning.mode2_ab_heading_x10,
        g_app.tuning.mode2_cd_heading_x10,
        (unsigned) g_app.mode3_loops,
        g_app.tuning.mode3_ac_heading_x10[0],
        g_app.tuning.mode3_ac_heading_x10[1],
        g_app.tuning.mode3_ac_heading_x10[2],
        g_app.tuning.mode3_bd_heading_x10[0],
        g_app.tuning.mode3_bd_heading_x10[1],
        g_app.tuning.mode3_bd_heading_x10[2],
        snapshot->last_node,
        snapshot->leg_start_node,
        snapshot->leg_end_node,
        leg_type_name,
        (unsigned) snapshot->leg_line_tracked,
        (unsigned) snapshot->leg_length_mm,
        snapshot->leg_heading_start_deg_x10,
        snapshot->leg_heading_end_deg_x10,
        (long) snapshot->leg_progress_count,
        (long) snapshot->leg_target_count,
        snapshot->heading_target_deg_x10,
        snapshot->heading_error_deg_x10,
        snapshot->relative_yaw_deg_x10,
        snapshot->gyro_relative_yaw_deg_x10,
        snapshot->yaw_zero_deg_x10,
        (unsigned) snapshot->route2_bc_exit_candidate_valid,
        snapshot->route2_bc_exit_candidate_ryaw_x10,
        (long) snapshot->route2_bc_exit_candidate_lcnt,
        (unsigned) snapshot->open_line_confirm_ticks,
        (unsigned) snapshot->arc_entry_active,
        (unsigned long) snapshot->node_event_count,
        (unsigned long) snapshot->hold_ms_remaining,
        snapshot->line_ok ? 1U : 0U,
        (unsigned) snapshot->line_active_mask,
        (unsigned) snapshot->line_raw_mask,
        (unsigned) snapshot->line_active_count,
        (unsigned) snapshot->line_max_index,
        (unsigned) snapshot->line_max_value,
        snapshot->line_error,
        snapshot->vision_state.online ? 1U : 0U,
        vision_status_name,
        snapshot->vision_state.err_x,
        snapshot->vision_state.err_y,
        snapshot->left_speed_pps,
        snapshot->right_speed_pps,
        snapshot->straight_term_pps,
        snapshot->turn_term_pps,
        snapshot->straight_bias_pps,
        snapshot->left_target_pps,
        snapshot->right_target_pps,
        snapshot->left_pwm,
        snapshot->right_pwm,
        roll_tenth / 10,
        roll_frac,
        pitch_tenth / 10,
        pitch_frac,
        yaw_tenth / 10,
        yaw_frac,
        gz_tenth / 10,
        gz_frac,
        snapshot->gimbal_state.enabled ? 1U : 0U,
        (long) snapshot->gimbal_state.pan_position_us,
        (long) snapshot->gimbal_state.tilt_position_us,
        (long) snapshot->gimbal_state.pan_target_us,
        (long) snapshot->gimbal_state.tilt_target_us);

    return (length > 0) ? (size_t) length : 0U;
}

static void car_app_debug_print(void)
{
    car_app_snapshot_t snapshot;
    char buffer[896];

    car_app_get_snapshot(&snapshot);
    if (car_app_format_log_line(buffer, sizeof(buffer), &snapshot) > 0U) {
        board_debug_write(buffer);
    }
}

void car_app_init(void)
{
    memset(&g_app, 0, sizeof(g_app));
    g_app.state = APP_STATE_IDLE;
    g_app.task_phase = TASK_PHASE_FINISHED;
    g_app.selected_mode = CHASSIS_MODE_1;
    g_app.contest_task = CONTEST_TASK_BASIC_1;
    g_app.last_selection_button = SELECTION_BUTTON_NONE;
    g_app.mode3_loops = 1U;
#if AUTO_START_MODE1_ON_BOOT
    g_app.auto_start_pending = true;
#else
    g_app.auto_start_pending = false;
#endif
    g_app.last_event_node = ROUTE_NODE_A;
    g_app.debug_print_divider = DEBUG_PRINT_DIVIDER;
    g_app.debug_print_period_ticks = DEBUG_PRINT_DIVIDER;
    g_app.profile = car_app_profile_from_id(CAR_APP_PROFILE_SAFE);
    speed_pid_reset(&g_app.left_speed_pid);
    speed_pid_reset(&g_app.right_speed_pid);
    jy901_parser_init(&g_app.imu_parser);
    gimbal_servo_init();
    k230_protocol_init();
    car_app_reset_runtime_tuning(&g_app);
    oled_init();
    oled_show_waiting();
}

void car_app_step(const car_app_input_t *input)
{
    uint32_t pressed_mask;

    if (input == NULL) {
        return;
    }

    pressed_mask = car_app_debounce_buttons(&g_app, input->button_mask);

    if (input->has_line_sample) {
        (void) line_sensor_calculate_error(&input->line_sample, &g_app.line_state);
    } else {
        g_app.line_state.has_line = false;
        g_app.line_state.error = 0;
        g_app.line_state.active_count = 0U;
        g_app.line_state.active_mask = 0U;
        g_app.line_state.raw_mask = 0U;
        g_app.line_state.max_index = 0U;
        g_app.line_state.max_value = 0U;
    }

    g_app.encoder_state = input->encoder_state;
    g_app.imu_state = input->imu_state;

    if (g_app.state != APP_STATE_RUNNING) {
        car_app_handle_selection_buttons(&g_app, pressed_mask);
        car_app_handle_mode_button_holds(&g_app);
    }

    car_app_handle_start_button(&g_app, pressed_mask);

    car_app_handle_auto_start(&g_app);
    car_app_update_travel_odometer(&g_app);
    car_app_update_task_state(&g_app);
    car_app_update_gyro_heading(&g_app);
    car_app_update_motion(&g_app);
    car_app_update_aim_gimbal_pid(&g_app);
    if (g_app.manual_motor_ticks_remaining > 0U) {
        g_app.motor_command = g_app.manual_motor_command;
        g_app.manual_motor_ticks_remaining--;
    }
    car_app_apply_push_capture_no_motor(&g_app);
    g_app.tick_count++;
}

void car_app_tick(void)
{
    car_app_input_t input;

    car_app_read_board_input(&input);
    board_beep_service();
    gimbal_servo_service_200hz();
    car_app_step(&input);
    car_app_flush_outputs(&g_app);
    if (SERIAL_K230_MODE_OUTPUT_ENABLED) {
        (void) k230_protocol_set_mode(car_app_get_k230_mode(&g_app));
    }

    if (SERIAL_PERIODIC_LOG_ENABLED && (g_app.state == APP_STATE_RUNNING)) {
        if (g_app.debug_print_divider > 0U) {
            g_app.debug_print_divider--;
        }
        if (g_app.debug_print_divider == 0U) {
            car_app_debug_print();
            g_app.debug_print_divider = g_app.debug_print_period_ticks;
        }
    } else {
        g_app.debug_print_divider = g_app.debug_print_period_ticks;
    }
    if ((g_app.tick_count % OLED_REFRESH_DIVIDER) == 0U) {
        const uint8_t oled_total_loops =
            (g_app.selected_mode == CHASSIS_MODE_3) ? g_app.mode3_loops : g_app.active_loops;

        oled_show_task(
            car_app_task_oled_label(&g_app),
            (uint8_t) g_app.state,
            (uint8_t) g_app.task_phase,
            g_app.completed_loops + 1U,
            oled_total_loops);
    }
}
