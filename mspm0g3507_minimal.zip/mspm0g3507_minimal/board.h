#ifndef BOARD_H_
#define BOARD_H_

#include "app_types.h"

void board_delay_cycles(volatile uint32_t cycles);
void board_init(void);
void board_debug_write(const char *text);
size_t board_read_debug_bytes(uint8_t *buffer, size_t capacity);
uint32_t board_read_button_mask(void);
bool board_line_sensor_read(line_sensor_sample_t *sample);
encoder_sample_t board_read_encoder(void);
size_t board_read_imu_bytes(uint8_t *buffer, size_t capacity);
void board_apply_motor_command(const motor_command_t *command);
bool board_servo_gimbal_init(void);
bool board_servo_gimbal_set_us(uint16_t pan_us, uint16_t tilt_us);
bool board_servo_gimbal_set_channel_us(uint8_t channel, uint16_t pulse_us);
void board_set_led(bool enabled);
void board_set_laser_power(bool enabled);
void board_beep(uint16_t frequency_hz, uint16_t duration_ms);
void board_beep_service(void);

#endif /* BOARD_H_ */
