#ifndef APP_TYPES_H_
#define APP_TYPES_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define APP_CONTROL_HZ 200U /* 控制循环标称频率，单位 Hz。调大 PID/速度估算更频繁但 CPU 负担变大；调小响应变慢且所有 tick 参数需重新折算。 */

typedef enum {
    BUTTON_MODE_1 = 1U << 0,
    BUTTON_MODE_2 = 1U << 1,
    BUTTON_MODE_3 = 1U << 2,
    BUTTON_START  = 1U << 3
} button_mask_t;

typedef struct {
    bool online;
    uint8_t digital_raw;
    uint8_t digital_active_mask;
    uint8_t active_count;
    int16_t line_error;
    uint8_t max_index;
    uint8_t max_value;
    uint16_t analog[8];
} line_sensor_sample_t;

typedef struct {
    int32_t left_total_count;
    int32_t right_total_count;
    int16_t left_speed_pps;
    int16_t right_speed_pps;
} encoder_sample_t;

typedef struct {
    float roll_deg;
    float pitch_deg;
    float yaw_deg;
    float gyro_x_dps;
    float gyro_y_dps;
    float gyro_z_dps;
    bool angle_valid;
    bool gyro_valid;
} imu_state_t;

typedef struct {
    int16_t left_target_pps;
    int16_t right_target_pps;
    int16_t left_pwm;
    int16_t right_pwm;
} motor_command_t;

typedef struct {
    bool enabled;
    int32_t pan_position_us;
    int32_t tilt_position_us;
    int32_t pan_target_us;
    int32_t tilt_target_us;
} gimbal_state_t;

typedef enum {
    VISION_STATUS_IDLE = 0,
    VISION_STATUS_TRACKING,
    VISION_STATUS_LOCKED,
    VISION_STATUS_LOST
} vision_status_code_t;

typedef struct {
    bool online;
    vision_status_code_t status;
    int16_t err_x;
    int16_t err_y;
    bool frame_valid;
    bool laser_valid;
    int16_t frame_center_x;
    int16_t frame_center_y;
    int16_t laser_center_x;
    int16_t laser_center_y;
    uint16_t frame_width;
    uint16_t frame_height;
    uint8_t frame_score;
    uint32_t update_count;
    uint32_t target_update_count;
} vision_status_t;

#endif /* APP_TYPES_H_ */
