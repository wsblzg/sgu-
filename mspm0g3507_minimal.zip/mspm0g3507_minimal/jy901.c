#include <string.h>

#include "jy901.h"

static float jy901_raw_to_angle(int16_t raw)
{
    return ((float) raw * 180.0f) / 32768.0f;
}

static float jy901_raw_to_gyro(int16_t raw)
{
    return ((float) raw * 2000.0f) / 32768.0f;
}

static uint8_t jy901_checksum(const uint8_t *frame)
{
    uint16_t sum = 0U;
    uint8_t index;

    for (index = 0U; index < 10U; ++index) {
        sum = (uint16_t) (sum + frame[index]);
    }

    return (uint8_t) sum;
}

void jy901_parser_init(jy901_parser_t *parser)
{
    memset(parser, 0, sizeof(*parser));
}

static void jy901_decode_payload(const uint8_t *frame, imu_state_t *imu_state)
{
    const uint8_t frame_type = frame[1];
    const int16_t x = (int16_t) ((uint16_t) frame[3] << 8U | frame[2]);
    const int16_t y = (int16_t) ((uint16_t) frame[5] << 8U | frame[4]);
    const int16_t z = (int16_t) ((uint16_t) frame[7] << 8U | frame[6]);

    if (frame_type == 0x52U) {
        imu_state->gyro_x_dps = jy901_raw_to_gyro(x);
        imu_state->gyro_y_dps = jy901_raw_to_gyro(y);
        imu_state->gyro_z_dps = jy901_raw_to_gyro(z);
        imu_state->gyro_valid = true;
    } else if (frame_type == 0x53U) {
        imu_state->roll_deg = jy901_raw_to_angle(x);
        imu_state->pitch_deg = jy901_raw_to_angle(y);
        imu_state->yaw_deg = jy901_raw_to_angle(z);
        imu_state->angle_valid = true;
    }
}

void jy901_parser_feed(jy901_parser_t *parser, uint8_t byte, imu_state_t *imu_state)
{
    if (parser->index == 0U) {
        if (byte != 0x55U) {
            return;
        }
    }

    parser->bytes[parser->index++] = byte;

    if (parser->index < 11U) {
        return;
    }

    if (jy901_checksum(parser->bytes) == parser->bytes[10]) {
        jy901_decode_payload(parser->bytes, imu_state);
    }

    parser->index = 0U;
}
