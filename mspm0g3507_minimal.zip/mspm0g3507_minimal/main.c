#include "ti_msp_dl_config.h"
#include "board.h"
#include "car_app.h"

#define APP_LOOP_DELAY_CYCLES 4000U /* 主循环每次 car_app_tick 后的延时周期。调大控制频率降低、车响应慢；调小频率升高但 CPU/外设负担增加。 */

int main(void)
{
    SYSCFG_DL_init();
    board_init();
    car_app_init();

    while (1) {
        car_app_tick();
        board_delay_cycles(APP_LOOP_DELAY_CYCLES);
    }
}
