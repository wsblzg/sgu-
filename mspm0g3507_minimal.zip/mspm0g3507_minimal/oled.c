#include <stdio.h>
#include <string.h>

#include "ti_msp_dl_config.h"
#include "board_config.h"
#include "oled.h"

#define OLED_ADDR      0x3CU  /* OLED I2C 地址。地址不匹配会无显示；只在屏幕地址不同如 0x3D 时修改。 */
#define OLED_CTRL_CMD  0x00U  /* OLED 命令控制字。芯片协议常量，不调。 */
#define OLED_CTRL_DATA 0x40U  /* OLED 数据控制字。芯片协议常量，不调。 */
#define OLED_WIDTH     128    /* OLED 宽度像素。调错会导致换行/清屏错位，需匹配实际屏幕。 */
#define OLED_PAGES     8U     /* OLED 页数，8 页对应 64 像素高。调错会导致显示范围异常。 */

/* ---- software I2C on PB10=SDA, PB11=SCL ---- */
#define I2C_SDA_PORT   GPIOB          /* OLED 软件 I2C SDA 端口。换线需同步 PORT/PIN/IOMUX。 */
#define I2C_SDA_PIN    DL_GPIO_PIN_10 /* OLED 软件 I2C SDA 引脚。改错会导致 OLED 无响应。 */
#define I2C_SDA_IOMUX  IOMUX_PINCM27  /* OLED SDA IOMUX。需与引脚匹配，不是调参项。 */
#define I2C_SCL_PORT   GPIOB          /* OLED 软件 I2C SCL 端口。换线需同步 PORT/PIN/IOMUX。 */
#define I2C_SCL_PIN    DL_GPIO_PIN_11 /* OLED 软件 I2C SCL 引脚。改错会导致 OLED 无响应。 */
#define I2C_SCL_IOMUX  IOMUX_PINCM28  /* OLED SCL IOMUX。需与引脚匹配，不是调参项。 */

static void i2c_sda_out(void)
{
    DL_GPIO_initDigitalOutputFeatures(I2C_SDA_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_DRIVE_STRENGTH_HIGH, DL_GPIO_HIZ_DISABLE);
    DL_GPIO_enableOutput(I2C_SDA_PORT, I2C_SDA_PIN);
}

static void i2c_sda_in(void)
{
    DL_GPIO_disableOutput(I2C_SDA_PORT, I2C_SDA_PIN);
    DL_GPIO_initDigitalInputFeatures(I2C_SDA_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
}

static void i2c_scl_lo(void) { DL_GPIO_clearPins(I2C_SCL_PORT, I2C_SCL_PIN); }
static void i2c_scl_hi(void) { DL_GPIO_setPins(I2C_SCL_PORT, I2C_SCL_PIN); }
static void i2c_sda_lo(void) { DL_GPIO_clearPins(I2C_SDA_PORT, I2C_SDA_PIN); }
static void i2c_sda_hi(void) { DL_GPIO_setPins(I2C_SDA_PORT, I2C_SDA_PIN); }
static bool i2c_sda_read(void) {
    return (DL_GPIO_readPins(I2C_SDA_PORT, I2C_SDA_PIN) != 0U);
}

static void i2c_delay(void)
{
    for (volatile uint32_t d = 0U; d < 8U; d++) { __asm volatile(""); }
}

static void i2c_start(void)
{
    i2c_sda_out();
    i2c_sda_hi();
    i2c_scl_hi();
    i2c_delay();
    i2c_sda_lo();
    i2c_delay();
    i2c_scl_lo();
}

static void i2c_stop(void)
{
    i2c_sda_out();
    i2c_sda_lo();
    i2c_scl_hi();
    i2c_delay();
    i2c_sda_hi();
    i2c_delay();
}

static bool i2c_write_byte(uint8_t byte)
{
    i2c_sda_out();
    for (uint8_t m = 0x80U; m != 0U; m >>= 1U) {
        if (byte & m) i2c_sda_hi(); else i2c_sda_lo();
        i2c_delay();
        i2c_scl_hi();
        i2c_delay();
        i2c_scl_lo();
    }
    /* ACK */
    i2c_sda_in();
    i2c_delay();
    i2c_scl_hi();
    i2c_delay();
    bool ack = !i2c_sda_read();
    i2c_scl_lo();
    i2c_sda_out();
    return ack;
}

static void oled_write(uint8_t ctrl, const uint8_t *data, size_t len)
{
    i2c_start();
    i2c_write_byte((OLED_ADDR << 1U) | 0U);
    i2c_write_byte(ctrl);
    for (size_t i = 0U; i < len; i++) {
        i2c_write_byte(data[i]);
    }
    i2c_stop();
}

static void oled_cmd(uint8_t cmd)
{
    oled_write(OLED_CTRL_CMD, &cmd, 1U);
}

static void oled_set_page(uint8_t page)
{
    oled_cmd(0xB0U | page);
    oled_cmd(0x00U);
    oled_cmd(0x10U);
}

static void oled_clear(void)
{
    uint8_t buf[OLED_WIDTH];

    memset(buf, 0, sizeof(buf));
    for (uint8_t page = 0U; page < OLED_PAGES; page++) {
        oled_set_page(page);
        oled_write(OLED_CTRL_DATA, buf, OLED_WIDTH);
    }
}

/* ---- init ---- */
static void i2c_gpio_init(void)
{
    DL_GPIO_initDigitalOutputFeatures(I2C_SCL_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_DRIVE_STRENGTH_HIGH, DL_GPIO_HIZ_DISABLE);
    DL_GPIO_initDigitalOutputFeatures(I2C_SDA_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_DRIVE_STRENGTH_HIGH, DL_GPIO_HIZ_DISABLE);
    DL_GPIO_setPins(I2C_SCL_PORT, I2C_SCL_PIN);
    DL_GPIO_setPins(I2C_SDA_PORT, I2C_SDA_PIN);
    DL_GPIO_enableOutput(I2C_SCL_PORT, I2C_SCL_PIN);
    DL_GPIO_enableOutput(I2C_SDA_PORT, I2C_SDA_PIN);
}

void oled_init(void)
{
    static const uint8_t init[] = {
        0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0x00, 0x40,
        0x8D, 0x14, 0x20, 0x00, 0xA1, 0xC8, 0xDA, 0x12,
        0x81, 0x8F, 0xD9, 0xF1, 0xDB, 0x40, 0xA4, 0xA6, 0xAF,
    };

    i2c_gpio_init();
    for (size_t i = 0U; i < sizeof(init); i++) {
        oled_cmd(init[i]);
    }
    oled_clear();
}

/* ---- font ---- */
static const uint8_t font5x8[95][5] = {
    {0x00,0x00,0x00,0x00,0x00}, {0x00,0x00,0x5F,0x00,0x00},
    {0x00,0x07,0x00,0x07,0x00}, {0x14,0x7F,0x14,0x7F,0x14},
    {0x24,0x2A,0x7F,0x2A,0x12}, {0x23,0x13,0x08,0x64,0x62},
    {0x36,0x49,0x55,0x22,0x50}, {0x00,0x05,0x03,0x00,0x00},
    {0x00,0x1C,0x22,0x41,0x00}, {0x00,0x41,0x22,0x1C,0x00},
    {0x08,0x2A,0x1C,0x2A,0x08}, {0x08,0x08,0x3E,0x08,0x08},
    {0x00,0x50,0x30,0x00,0x00}, {0x08,0x08,0x08,0x08,0x08},
    {0x00,0x60,0x60,0x00,0x00}, {0x20,0x10,0x08,0x04,0x02},
    {0x3E,0x51,0x49,0x45,0x3E}, {0x00,0x42,0x7F,0x40,0x00},
    {0x42,0x61,0x51,0x49,0x46}, {0x21,0x41,0x45,0x4B,0x31},
    {0x18,0x14,0x12,0x7F,0x10}, {0x27,0x45,0x45,0x45,0x39},
    {0x3C,0x4A,0x49,0x49,0x30}, {0x01,0x71,0x09,0x05,0x03},
    {0x36,0x49,0x49,0x49,0x36}, {0x06,0x49,0x49,0x29,0x1E},
    {0x00,0x36,0x36,0x00,0x00}, {0x00,0x56,0x36,0x00,0x00},
    {0x00,0x08,0x14,0x22,0x41}, {0x14,0x14,0x14,0x14,0x14},
    {0x41,0x22,0x14,0x08,0x00}, {0x02,0x01,0x51,0x09,0x06},
    {0x32,0x49,0x79,0x41,0x3E}, {0x7E,0x11,0x11,0x11,0x7E},
    {0x7F,0x49,0x49,0x49,0x36}, {0x3E,0x41,0x41,0x41,0x22},
    {0x7F,0x41,0x41,0x22,0x1C}, {0x7F,0x49,0x49,0x49,0x41},
    {0x7F,0x09,0x09,0x01,0x01}, {0x3E,0x41,0x41,0x51,0x32},
    {0x7F,0x08,0x08,0x08,0x7F}, {0x00,0x41,0x7F,0x41,0x00},
    {0x20,0x40,0x41,0x3F,0x01}, {0x7F,0x08,0x14,0x22,0x41},
    {0x7F,0x40,0x40,0x40,0x40}, {0x7F,0x02,0x04,0x02,0x7F},
    {0x7F,0x04,0x08,0x10,0x7F}, {0x3E,0x41,0x41,0x41,0x3E},
    {0x7F,0x09,0x09,0x09,0x06}, {0x3E,0x41,0x51,0x21,0x5E},
    {0x7F,0x09,0x19,0x29,0x46}, {0x46,0x49,0x49,0x49,0x31},
    {0x01,0x01,0x7F,0x01,0x01}, {0x3F,0x40,0x40,0x40,0x3F},
    {0x1F,0x20,0x40,0x20,0x1F}, {0x7F,0x20,0x18,0x20,0x7F},
    {0x63,0x14,0x08,0x14,0x63}, {0x03,0x04,0x78,0x04,0x03},
    {0x61,0x51,0x49,0x45,0x43}, {0x00,0x7F,0x41,0x41,0x00},
    {0x02,0x04,0x08,0x10,0x20}, {0x00,0x41,0x41,0x7F,0x00},
    {0x04,0x02,0x01,0x02,0x04}, {0x40,0x40,0x40,0x40,0x40},
    {0x00,0x01,0x02,0x04,0x00}, {0x20,0x54,0x54,0x54,0x78},
    {0x7F,0x48,0x44,0x44,0x38}, {0x38,0x44,0x44,0x44,0x20},
    {0x38,0x44,0x44,0x48,0x7F}, {0x38,0x54,0x54,0x54,0x18},
    {0x08,0x7E,0x09,0x01,0x02}, {0x08,0x14,0x54,0x54,0x3C},
    {0x7F,0x08,0x04,0x04,0x78}, {0x00,0x44,0x7D,0x40,0x00},
    {0x20,0x40,0x44,0x3D,0x00}, {0x00,0x7F,0x10,0x28,0x44},
    {0x00,0x41,0x7F,0x40,0x00}, {0x7C,0x04,0x18,0x04,0x78},
    {0x7C,0x08,0x04,0x04,0x78}, {0x38,0x44,0x44,0x44,0x38},
    {0x7C,0x14,0x14,0x14,0x08}, {0x08,0x14,0x14,0x18,0x7C},
    {0x7C,0x08,0x04,0x04,0x08}, {0x48,0x54,0x54,0x54,0x20},
    {0x04,0x3F,0x44,0x40,0x20}, {0x3C,0x40,0x40,0x20,0x7C},
    {0x1C,0x20,0x40,0x20,0x1C}, {0x3C,0x40,0x30,0x40,0x3C},
    {0x44,0x28,0x10,0x28,0x44}, {0x0C,0x50,0x50,0x50,0x3C},
    {0x44,0x64,0x54,0x4C,0x44},
};

static void oled_draw_text(uint8_t page, const char *text)
{
    uint8_t buf[OLED_WIDTH];
    uint8_t cursor = 0U;
    memset(buf, 0, sizeof(buf));

    while (*text && cursor < (OLED_WIDTH - 5U)) {
        char c = *text++;
        if (c < ' ' || c > 'z') c = ' ';
        const uint8_t *g = font5x8[(uint8_t)(c - ' ')];
        for (uint8_t i = 0U; i < 5U; i++) {
            buf[cursor++] = g[i];
        }
        buf[cursor++] = 0x00;
    }

    oled_set_page(page);
    oled_write(OLED_CTRL_DATA, buf, OLED_WIDTH);
}

static void oled_put_scaled_column(
    uint8_t *top, uint8_t *bottom, uint8_t x, uint8_t glyph_col)
{
    uint8_t top_col = 0U;
    uint8_t bottom_col = 0U;

    for (uint8_t bit = 0U; bit < 8U; bit++) {
        if ((glyph_col & (1U << bit)) != 0U) {
            const uint8_t y0 = (uint8_t) (bit * 2U);
            const uint8_t y1 = (uint8_t) (y0 + 1U);

            if (y0 < 8U) {
                top_col |= (uint8_t) (1U << y0);
            } else {
                bottom_col |= (uint8_t) (1U << (y0 - 8U));
            }
            if (y1 < 8U) {
                top_col |= (uint8_t) (1U << y1);
            } else {
                bottom_col |= (uint8_t) (1U << (y1 - 8U));
            }
        }
    }

    if (x < OLED_WIDTH) {
        top[x] = top_col;
        bottom[x] = bottom_col;
    }
    if ((uint8_t) (x + 1U) < OLED_WIDTH) {
        top[x + 1U] = top_col;
        bottom[x + 1U] = bottom_col;
    }
}

static void oled_draw_text_2x(uint8_t page, const char *text)
{
    uint8_t top[OLED_WIDTH];
    uint8_t bottom[OLED_WIDTH];
    uint8_t cursor = 0U;

    memset(top, 0, sizeof(top));
    memset(bottom, 0, sizeof(bottom));

    while (*text && cursor < (OLED_WIDTH - 12U)) {
        char c = *text++;
        if (c < ' ' || c > 'z') {
            c = ' ';
        }

        const uint8_t *g = font5x8[(uint8_t) (c - ' ')];
        for (uint8_t i = 0U; i < 5U; i++) {
            oled_put_scaled_column(top, bottom, cursor, g[i]);
            cursor = (uint8_t) (cursor + 2U);
        }
        cursor = (uint8_t) (cursor + 2U);
    }

    oled_set_page(page);
    oled_write(OLED_CTRL_DATA, top, OLED_WIDTH);
    oled_set_page((uint8_t) (page + 1U));
    oled_write(OLED_CTRL_DATA, bottom, OLED_WIDTH);
}

static const char *oled_state_text(uint8_t state)
{
    switch (state) {
        case 1U:
            return "RUN";
        case 2U:
            return "STOP";
        default:
            return "IDLE";
    }
}

static const char *oled_phase_text(uint8_t phase)
{
    switch (phase) {
        case 1U:
            return "HOLD";
        case 2U:
            return "DONE";
        default:
            return "TRK";
    }
}

void oled_show_mode(uint8_t mode, uint8_t state, uint8_t phase, uint8_t current_loop, uint8_t total_loops)
{
    char label[10];

    if (mode < 1U || mode > 6U) {
        mode = 0U;
    }

    snprintf(label, sizeof(label), "MODE %u", (unsigned) mode);
    oled_show_task(label, state, phase, current_loop, total_loops);
}

void oled_show_task(const char *task, uint8_t state, uint8_t phase, uint8_t current_loop, uint8_t total_loops)
{
    char line1[22], line2[22];

    if (current_loop == 0U) {
        current_loop = 1U;
    }
    if (total_loops == 0U) {
        total_loops = 1U;
    }
    if ((task == NULL) || (task[0] == '\0')) {
        task = "B1";
    }

    snprintf(line1, sizeof(line1), "%s %s L%u/%u",
        oled_state_text(state),
        oled_phase_text(phase),
        (unsigned) current_loop,
        (unsigned) total_loops);
    snprintf(line2, sizeof(line2), "%s", task);

    oled_draw_text(0U, line1);
    oled_draw_text_2x(2U, line2);
}

void oled_show_waiting(void)
{
    oled_draw_text(0U, "SYSTEM");
    oled_draw_text_2x(2U, "WAIT");
}
