#ifndef CAR_APP_H_
#define CAR_APP_H_

#include "app_types.h"

#define CAR_APP_LOG_PREFIX "CARLOG" /* 调试日志行前缀。改了会影响 parse_car_log.py 和串口侧日志过滤规则。 */

typedef enum {
    CAR_APP_PROFILE_SAFE = 0,
    CAR_APP_PROFILE_RACE,
    CAR_APP_PROFILE_COUNT
} car_app_profile_id_t;

typedef struct {
    uint32_t button_mask;
    bool has_line_sample;
    line_sensor_sample_t line_sample;
    encoder_sample_t encoder_state;
    imu_state_t imu_state;
} car_app_input_t;

typedef struct {
    uint32_t tick_count;
    uint32_t time_ms;
    car_app_profile_id_t profile_id;
    const char *profile_name;
    uint8_t mode;
    uint8_t k230_mode;
    vision_status_t vision_state;
    uint8_t state;
    uint8_t phase;
    uint32_t button_mask;
    uint32_t pressed_button_mask;
    uint8_t route_index;
    uint8_t route_total;
    uint8_t current_loop;
    uint8_t total_loops;
    char last_node;
    char leg_start_node;
    char leg_end_node;
    uint8_t leg_type;
    uint8_t leg_line_tracked;
    int16_t leg_heading_start_deg_x10;
    int16_t leg_heading_end_deg_x10;
    uint16_t leg_length_mm;
    int32_t leg_progress_count;
    int32_t leg_target_count;
    int16_t heading_target_deg_x10;
    int16_t heading_error_deg_x10;
    int16_t relative_yaw_deg_x10;
    int16_t gyro_relative_yaw_deg_x10;
    int16_t yaw_zero_deg_x10;
    uint8_t route2_bc_exit_candidate_valid;
    int16_t route2_bc_exit_candidate_ryaw_x10;
    int32_t route2_bc_exit_candidate_lcnt;
    uint8_t open_line_confirm_ticks;
    uint8_t arc_entry_active;
    uint32_t node_event_count;
    uint32_t hold_ms_remaining;
    bool line_ok;
    uint8_t line_active_mask;
    uint8_t line_raw_mask;
    uint8_t line_active_count;
    uint8_t line_max_index;
    uint8_t line_max_value;
    int16_t line_error;
    int16_t left_speed_pps;
    int16_t right_speed_pps;
    int16_t straight_term_pps;
    int16_t turn_term_pps;
    int16_t straight_bias_pps;
    int16_t left_target_pps;
    int16_t right_target_pps;
    int16_t left_pwm;
    int16_t right_pwm;
    float roll_deg;
    float pitch_deg;
    float yaw_deg;
    float gyro_z_dps;
    bool led_on;
    bool beep_pending;
    uint16_t beep_frequency_hz;
    uint16_t beep_duration_ms;
    gimbal_state_t gimbal_state;
} car_app_snapshot_t;

void car_app_init(void);
void car_app_set_profile(car_app_profile_id_t profile_id);
car_app_profile_id_t car_app_get_profile(void);
const char *car_app_get_profile_name(car_app_profile_id_t profile_id);
bool car_app_handle_param_command(const char *line);
bool car_app_handle_control_command(const char *line);
void car_app_step(const car_app_input_t *input);
void car_app_tick(void);
void car_app_get_snapshot(car_app_snapshot_t *snapshot);
size_t car_app_format_log_line(
    char *buffer, size_t capacity, const car_app_snapshot_t *snapshot);

#endif /* CAR_APP_H_ */
