#ifndef K230_PROTOCOL_H_
#define K230_PROTOCOL_H_

#include "app_types.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef enum {
    K230_MODE_STOP = 0,
    K230_MODE_AIM,
    K230_MODE_ECG
} k230_mode_t;

void k230_protocol_init(void);
void k230_protocol_feed(const uint8_t *buffer, size_t length);
bool k230_protocol_set_mode(k230_mode_t mode);
bool k230_protocol_send_command(const char *line);
void k230_protocol_get_vision_status(vision_status_t *status);

#endif /* K230_PROTOCOL_H_ */
