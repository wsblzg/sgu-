#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "board.h"
#include "car_app.h"
#include "gimbal_servo.h"
#include "k230_protocol.h"

#define K230_LINE_CAPACITY 96U           /* K230 单行协议缓冲容量。调大可接更长命令但占 RAM；调小省 RAM 但长行会被截断。 */
#define K230_FORWARD_PREFIX "K230,"      /* 调试串口转发给 K230 的命令前缀。改了会影响外部命令格式。 */
#define K230_FORWARD_PREFIX_LENGTH 5U    /* K230, 前缀长度。必须和 K230_FORWARD_PREFIX 同步，不单独调。 */
#define K230_COMMAND_ECHO_ENABLED 0U     /* 串口命令回显开关。设 0 时不回显 CMD/ERR，只保留 PARAM/CAR 响应。 */
#define K230_MODE_RESEND_TICKS APP_CONTROL_HZ /* K230 模式命令保活周期。防止模式切换瞬间丢包后 K230 长时间停在旧模式。 */

static char g_line[K230_LINE_CAPACITY];
static size_t g_line_length;
static bool g_has_last_mode;
static k230_mode_t g_last_mode;
static uint16_t g_mode_resend_ticks;
static vision_status_t g_vision_status;

static void echo_received_line(const char *prefix, const char *line)
{
    if (!K230_COMMAND_ECHO_ENABLED) {
        return;
    }

    if ((prefix == NULL) || (line == NULL)) {
        return;
    }

    board_debug_write(prefix);
    board_debug_write(line);
    board_debug_write("\r\n");
}

static bool parse_i32(const char **cursor, int32_t *value)
{
    char *endptr;
    long parsed;

    if ((cursor == NULL) || (*cursor == NULL) || (value == NULL)) {
        return false;
    }

    parsed = strtol(*cursor, &endptr, 10);
    if (endptr == *cursor) {
        return false;
    }

    *value = (int32_t) parsed;
    *cursor = endptr;
    return true;
}

static bool consume_comma(const char **cursor)
{
    if ((cursor == NULL) || (*cursor == NULL) || (**cursor != ',')) {
        return false;
    }

    (*cursor)++;
    return true;
}

static bool parse_vision_status_name(
    const char *token,
    size_t token_length,
    vision_status_code_t *status)
{
    if ((token == NULL) || (status == NULL)) {
        return false;
    }

    if ((token_length == 4U) && (strncmp(token, "IDLE", 4U) == 0)) {
        *status = VISION_STATUS_IDLE;
        return true;
    }

    if ((token_length == 8U) && (strncmp(token, "TRACKING", 8U) == 0)) {
        *status = VISION_STATUS_TRACKING;
        return true;
    }

    if ((token_length == 6U) && (strncmp(token, "LOCKED", 6U) == 0)) {
        *status = VISION_STATUS_LOCKED;
        return true;
    }

    if ((token_length == 4U) && (strncmp(token, "LOST", 4U) == 0)) {
        *status = VISION_STATUS_LOST;
        return true;
    }

    return false;
}

static void k230_handle_line(const char *line)
{
    const char *cursor;
    const char *status_end;
    int32_t first;
    int32_t second;
    int32_t third;
    int32_t values[12];
    uint8_t value_index;
    vision_status_code_t vision_status_code;
    bool handled = false;

    echo_received_line("CMD,", line);

    if (strncmp(line, K230_FORWARD_PREFIX, K230_FORWARD_PREFIX_LENGTH) == 0) {
        (void) k230_protocol_send_command(line + K230_FORWARD_PREFIX_LENGTH);
        handled = true;
        goto done;
    }

    if (strncmp(line, "PARAM,", 6U) == 0) {
        (void) car_app_handle_param_command(line);
        handled = true;
        goto done;
    }

    if (strncmp(line, "CAR,", 4U) == 0) {
        (void) car_app_handle_control_command(line);
        handled = true;
        goto done;
    }

    if (strncmp(line, "GIMBAL,", 7U) == 0) {
        cursor = line + 7U;
        if (parse_i32(&cursor, &first) &&
            consume_comma(&cursor) &&
            parse_i32(&cursor, &second)) {
            gimbal_servo_set_target(first, second);
        }
        handled = true;
        goto done;
    }

    if (strncmp(line, "GIMBALA,", 8U) == 0) {
        cursor = line + 8U;
        if (parse_i32(&cursor, &first) &&
            consume_comma(&cursor) &&
            parse_i32(&cursor, &second)) {
            gimbal_servo_set_angle(first, second);
        }
        handled = true;
        goto done;
    }

    if (strncmp(line, "GIMBALD,", 8U) == 0) {
        cursor = line + 8U;
        if (parse_i32(&cursor, &first) &&
            consume_comma(&cursor) &&
            parse_i32(&cursor, &second)) {
            gimbal_servo_offset((int16_t) first, (int16_t) second);
        }
        handled = true;
        goto done;
    }

    if (strcmp(line, "GIMBALC") == 0) {
        gimbal_servo_center();
        handled = true;
        goto done;
    }

    if (strncmp(line, "GIMBALE,", 8U) == 0) {
        cursor = line + 8U;
        if (parse_i32(&cursor, &first)) {
            gimbal_servo_set_enabled(first != 0);
        }
        handled = true;
        goto done;
    }

    if (strncmp(line, "VSTAT,", 6U) == 0) {
        cursor = line + 6U;
        status_end = strchr(cursor, ',');
        if (status_end == NULL) {
            handled = true;
            goto done;
        }

        if (!parse_vision_status_name(
                cursor,
                (size_t) (status_end - cursor),
                &vision_status_code)) {
            handled = true;
            goto done;
        }

        cursor = status_end + 1;
        if (parse_i32(&cursor, &first) &&
            consume_comma(&cursor) &&
            parse_i32(&cursor, &second)) {
            g_vision_status.online = true;
            g_vision_status.status = vision_status_code;
            g_vision_status.err_x = (int16_t) first;
            g_vision_status.err_y = (int16_t) second;
            g_vision_status.frame_valid =
                (vision_status_code == VISION_STATUS_TRACKING) ||
                (vision_status_code == VISION_STATUS_LOCKED);
            g_vision_status.laser_valid = g_vision_status.frame_valid;
            g_vision_status.update_count++;
            g_vision_status.target_update_count++;
        }
        handled = true;
        goto done;
    }

    if (strncmp(line, "VDIAG,", 6U) == 0) {
        cursor = line + 6U;
        for (value_index = 0U; value_index < 12U; ++value_index) {
            if (!parse_i32(&cursor, &values[value_index])) {
                handled = true;
                goto done;
            }
            if ((value_index < 11U) && !consume_comma(&cursor)) {
                handled = true;
                goto done;
            }
        }

        g_vision_status.online = true;
        g_vision_status.frame_valid = values[0] != 0;
        g_vision_status.laser_valid = values[1] != 0;
        if (g_vision_status.frame_valid) {
            const int32_t fx = values[6];
            const int32_t fy = values[7];
            const int32_t fw = values[8];
            const int32_t fh = values[9];
            g_vision_status.frame_center_x = (int16_t) (fx + (fw / 2));
            g_vision_status.frame_center_y = (int16_t) (fy + (fh / 2));
            g_vision_status.frame_width = (uint16_t) ((fw > 0) ? fw : 0);
            g_vision_status.frame_height = (uint16_t) ((fh > 0) ? fh : 0);
            g_vision_status.frame_score = 95U;
        } else {
            g_vision_status.frame_score = 0U;
        }
        if (g_vision_status.laser_valid) {
            g_vision_status.laser_center_x = (int16_t) values[10];
            g_vision_status.laser_center_y = (int16_t) values[11];
        }
        g_vision_status.update_count++;
        g_vision_status.target_update_count++;
        handled = true;
        goto done;
    }

    if (strncmp(line, "TCENTER,", 8U) == 0) {
        cursor = line + 8U;
        if (parse_i32(&cursor, &first) &&
            consume_comma(&cursor) &&
            parse_i32(&cursor, &second) &&
            consume_comma(&cursor) &&
            parse_i32(&cursor, &third)) {
            g_vision_status.online = true;
            g_vision_status.frame_valid = third > 0;
            g_vision_status.frame_center_x = (int16_t) first;
            g_vision_status.frame_center_y = (int16_t) second;
            g_vision_status.frame_score = (uint8_t) ((third < 0) ? 0 : ((third > 100) ? 100 : third));
            g_vision_status.update_count++;
            g_vision_status.target_update_count++;
        }
        handled = true;
        goto done;
    }

done:
    if (!handled) {
        echo_received_line("ERR,UNKNOWN_CMD,", line);
    }
}

static const char *k230_mode_text(k230_mode_t mode)
{
    switch (mode) {
        case K230_MODE_AIM:
            return "AIM";
        case K230_MODE_ECG:
            return "ECG";
        case K230_MODE_STOP:
        default:
            return "STOP";
    }
}

void k230_protocol_init(void)
{
    memset(g_line, 0, sizeof(g_line));
    g_line_length = 0U;
    g_has_last_mode = false;
    g_last_mode = K230_MODE_STOP;
    g_mode_resend_ticks = 0U;
    memset(&g_vision_status, 0, sizeof(g_vision_status));
    g_vision_status.status = VISION_STATUS_IDLE;
}

void k230_protocol_feed(const uint8_t *buffer, size_t length)
{
    size_t index;

    if (buffer == NULL) {
        return;
    }

    for (index = 0U; index < length; ++index) {
        const char ch = (char) buffer[index];

        if ((ch == '\r') || (ch == '\n')) {
            if (g_line_length > 0U) {
                g_line[g_line_length] = '\0';
                k230_handle_line(g_line);
                g_line_length = 0U;
            }
            continue;
        }

        if (g_line_length < (K230_LINE_CAPACITY - 1U)) {
            g_line[g_line_length++] = ch;
        } else {
            g_line_length = 0U;
        }
    }
}

bool k230_protocol_set_mode(k230_mode_t mode)
{
    const char *mode_text;
    char buffer[16];

    if (g_has_last_mode && (g_last_mode == mode)) {
        if (g_mode_resend_ticks > 0U) {
            g_mode_resend_ticks--;
            return false;
        }
    } else {
        g_mode_resend_ticks = 0U;
    }

    mode_text = k230_mode_text(mode);
    (void) snprintf(buffer, sizeof(buffer), "MODE,%s", mode_text);
    (void) k230_protocol_send_command(buffer);

    g_last_mode = mode;
    g_has_last_mode = true;
    g_mode_resend_ticks = K230_MODE_RESEND_TICKS;
    return true;
}

bool k230_protocol_send_command(const char *line)
{
    if ((line == NULL) || (line[0] == '\0')) {
        return false;
    }

    board_debug_write(line);
    board_debug_write("\r\n");
    return true;
}

void k230_protocol_get_vision_status(vision_status_t *status)
{
    if (status == NULL) {
        return;
    }

    *status = g_vision_status;
}
