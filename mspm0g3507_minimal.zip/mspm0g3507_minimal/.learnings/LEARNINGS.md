﻿## [LRN-20260518-001] correction

**Logged**: 2026-05-18T00:00:00+08:00
**Priority**: high
**Status**: pending
**Area**: architecture

### Summary
K230 must remain vision-only; MSPM0 owns gimbal control and PID.

### Details
User corrected an implementation that added AIM gimbal PID and GIMBALD output to K230. The intended architecture is K230 detects frame/laser and reports VSTAT/VDIAG over UART, while MSPM0 consumes visual errors and drives the PCA9685 gimbal with PID/PD. Do not put control loops in K230 for the final vehicle architecture.

### Suggested Action
For future K230/MSPM0 changes, keep visual detection and threshold UI on K230, and place servo/motor control loops, PID state, direction flags, and actuation commands on MSPM0.

### Metadata
- Source: user_feedback
- Related Files: C:\Users\DAS\AppData\Local\Temp\k230_mtp_work\main.py; D:\TI\Projects\mspm0\mspm0g3507_minimal\car_app.c
- Tags: k230, mspm0, uart, gimbal, pid, architecture
