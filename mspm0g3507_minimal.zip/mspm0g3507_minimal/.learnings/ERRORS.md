## [ERR-20260519-001] dslite_flash_jlink_dll

**Logged**: 2026-05-19T00:00:00+08:00
**Priority**: medium
**Status**: pending
**Area**: infra

### Summary
DSLite flash failed because the J-Link DLL could not be opened.

### Error
```text
error: CORTEX_M0P: Error connecting to the target: ERROR in JLINKARM_Open: Failed to open DLL
Failed: Operation was aborted on 'CORTEX_M0P'
```

### Context
- Command attempted: `D:\TI\CCS_Theia\ccs\ccs_base\DebugServer\bin\DSLite.exe flash --config=D:\TI\Projects\mspm0\mspm0g3507_minimal\targetConfigs\MSPM0G3507.ccxml --flash --verify --run D:\TI\Projects\mspm0\mspm0g3507_minimal\Debug\mspm0g3507_minimal.out`
- Build had already passed with CCS Theia `gmake.exe`.
- Failure is at probe/J-Link DLL loading, before target flashing.

### Suggested Fix
Install or repair SEGGER J-Link runtime, verify the CCXML probe type matches the connected debugger, or switch the target configuration to the actual connected probe. Then rerun DSLite flash.

### Metadata
- Reproducible: yes
- Related Files: D:\TI\Projects\mspm0\mspm0g3507_minimal\targetConfigs\MSPM0G3507.ccxml

---
